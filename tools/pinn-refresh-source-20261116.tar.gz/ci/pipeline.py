#!/usr/bin/env python3
"""Bounded, checked image primitives for the HackberryPi PINN conversion jobs.

No host disks are accepted. Sources are immutable published image files; output
contains per-partition payloads, never a whole-disk image to be written by PINN.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import subprocess
import threading
import time
import urllib.parse
import urllib.request

REPOSITORY = "DZT970525/Operating-System-for-HackberryPi"
RELEASE_TAG = "pinn-multiboot-hackberrypi-2026-11-16"
RELEASE_BASE = f"https://github.com/{REPOSITORY}/releases/download/{RELEASE_TAG}/"
PART_BYTES = 149_000_000
BUFFER_BYTES = 1_048_576
NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,220}\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for data in iter(lambda: source.read(BUFFER_BYTES), b""):
            digest.update(data)
    return digest.hexdigest()


def regular_file(path):
    path = Path(path)
    need(not path.is_symlink() and path.is_file(), f"Regular file required: {path}")
    return path


def safe_name(name):
    need(isinstance(name, str) and NAME.fullmatch(name), "Unsafe asset name")
    return name


def source_url(url):
    parsed = urllib.parse.urlsplit(url)
    need(parsed.scheme == "https" and parsed.netloc == "github.com", "HTTPS GitHub source required")
    need(parsed.path.startswith(f"/{REPOSITORY}/releases/download/"), "Source outside fixed repository")
    need(not parsed.query and not parsed.fragment, "Unexpected source URL parameters")
    return url


class DownloadRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        host = urllib.parse.urlsplit(newurl).hostname or ""
        need(urllib.parse.urlsplit(newurl).scheme == "https", "Non-HTTPS download redirect")
        need(host == "github.com" or host.endswith(".githubusercontent.com")
             or host.endswith(".github.com") or host.endswith(".amazonaws.com")
             or host.endswith(".blob.core.windows.net"), "Unexpected download redirect host")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download_asset(row, directory):
    name = safe_name(row["name"])
    size = row["bytes"]
    digest = row["sha256"]
    need(isinstance(size, int) and 0 < size <= 2_147_483_648, "Invalid source asset length")
    need(SHA.fullmatch(digest), "Invalid source asset SHA256")
    url = source_url(row["url"])
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    final = directory / name
    if final.exists():
        need(regular_file(final).stat().st_size == size and sha256_file(final) == digest,
             "Existing source cache does not match pinned source")
        return final
    partial = directory / (name + ".partial")
    need(not partial.is_symlink(), "Unexpected source-cache symlink")
    opener = urllib.request.build_opener(DownloadRedirect())
    for attempt in range(4):
        h = hashlib.sha256()
        written = 0
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "HackberryPi-PINN-builder/1"})
            with opener.open(request, timeout=40) as response, open(partial, "wb") as output:
                need(response.status == 200, "Unexpected source HTTP status")
                while data := response.read(BUFFER_BYTES):
                    written += len(data)
                    need(written <= size, "Source exceeds pinned asset length")
                    h.update(data)
                    output.write(data)
                output.flush()
                os.fsync(output.fileno())
            need(written == size and h.hexdigest() == digest, "Downloaded source checksum mismatch")
            partial.replace(final)
            return final
        except Exception:
            partial.unlink(missing_ok=True)
            if attempt == 3:
                raise
            time.sleep(3 * (attempt + 1))
    raise AssertionError("unreachable")


def assemble_source(spec, directory):
    """Verify each immutable asset, then the complete compressed byte stream."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    need(SHA.fullmatch(spec["sha256"]), "Missing complete compressed SHA256")
    final = directory / "source.img.xz"
    partial = directory / "source.img.xz.partial"
    need(not final.exists() and not partial.exists(), "Source assembly path already exists")
    h = hashlib.sha256()
    count = 0
    with open(partial, "xb") as output:
        for row in spec["assets"]:
            piece = download_asset(row, directory / "downloads")
            with piece.open("rb") as source:
                for data in iter(lambda: source.read(BUFFER_BYTES), b""):
                    h.update(data)
                    count += len(data)
                    need(count <= spec["bytes"], "Compressed source exceeds expected length")
                    output.write(data)
            # Only this job's verified inbound cache; the assembled source is kept.
            piece.unlink()
        output.flush()
        os.fsync(output.fileno())
    need(count == spec["bytes"] and h.hexdigest() == spec["sha256"], "Complete source checksum mismatch")
    partial.replace(final)
    return final


def decompress_source(source, output, expected_bytes, expected_sha256):
    need(SHA.fullmatch(expected_sha256) and expected_bytes > 0, "Missing expanded source identity")
    regular_file(source)
    output = Path(output)
    need(not output.exists(), "Expanded output already exists")
    h = hashlib.sha256()
    count = 0
    zero = bytes(BUFFER_BYTES)
    with lzma.open(source, "rb") as stream, output.open("xb") as destination:
        while data := stream.read(BUFFER_BYTES):
            count += len(data)
            need(count <= expected_bytes, "Expanded source exceeds declared image size")
            h.update(data)
            if data == zero[:len(data)]:
                destination.seek(len(data), os.SEEK_CUR)
            else:
                destination.write(data)
        destination.truncate(count)
        destination.flush()
        os.fsync(destination.fileno())
    need(count == expected_bytes and h.hexdigest() == expected_sha256, "Expanded source identity mismatch")
    return output


def partition_table(image):
    image = regular_file(image).resolve()
    data = json.loads(subprocess.check_output(["sfdisk", "--json", str(image)], text=True))
    table = data["partitiontable"]
    sector_size = table.get("sectorsize", 512)
    need(sector_size == 512 and table["label"] in ("dos", "gpt"), "Unsupported image partition layout")
    partitions = {}
    for row in table["partitions"]:
        number = int(re.search(r"(\d+)$", row["node"]).group(1))
        offset, length = row["start"] * sector_size, row["size"] * sector_size
        need(offset > 0 and length > 0 and offset + length <= image.stat().st_size,
             "Partition falls outside verified source image")
        partitions[number] = {**row, "number": number, "offset": offset, "bytes": length}
    return {"label": table["label"], "id": table.get("id"), "partitions": partitions}


def compress_region(image, offset, length, output_dir, prefix, part_bytes=PART_BYTES):
    """Compress an exact image partition, in bounded memory, into byte parts."""
    image = regular_file(image)
    need(offset >= 0 and length > 0 and offset + length <= image.stat().st_size,
         "Invalid source byte region")
    safe_name(prefix)
    need(0 < part_bytes <= PART_BYTES, "Invalid transport part size")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    need(not list(output_dir.glob(prefix + ".part*")), "Output payload already exists")
    raw_hash = hashlib.sha256()
    compressed_hash = hashlib.sha256()
    error = []
    compressor = subprocess.Popen(["xz", "-3", "-T2", "--check=crc64", "--memlimit-compress=768MiB", "-c"],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE)

    def feed():
        try:
            with image.open("rb") as source:
                source.seek(offset)
                remaining = length
                while remaining:
                    block = source.read(min(BUFFER_BYTES, remaining))
                    need(block, "Short source partition read")
                    raw_hash.update(block)
                    compressor.stdin.write(block)
                    remaining -= len(block)
        except BaseException as exc:
            error.append(exc)
        finally:
            compressor.stdin.close()

    feeder = threading.Thread(target=feed, daemon=True)
    feeder.start()
    parts = []
    number = 1
    current = None
    size = 0
    piece_hash = None
    total = 0
    try:
        while block := compressor.stdout.read(BUFFER_BYTES):
            compressed_hash.update(block)
            total += len(block)
            while block:
                if current is None:
                    name = safe_name(f"{prefix}.part{number:02d}")
                    current = (output_dir / name).open("xb")
                    piece_hash = hashlib.sha256()
                    size = 0
                count = min(len(block), part_bytes - size)
                current.write(block[:count])
                piece_hash.update(block[:count])
                size += count
                block = block[count:]
                if size == part_bytes:
                    current.close()
                    parts.append({"name": name, "bytes": size, "sha256": piece_hash.hexdigest(),
                                  "url": RELEASE_BASE + name})
                    current = None
                    number += 1
        if current is not None:
            current.close()
            parts.append({"name": name, "bytes": size, "sha256": piece_hash.hexdigest(),
                          "url": RELEASE_BASE + name})
        feeder.join(timeout=30)
        need(not feeder.is_alive(), "Source feeder did not finish")
        need(compressor.wait(timeout=30) == 0 and not error, "Partition compression failed")
    finally:
        if current is not None and not current.closed:
            current.close()
        if compressor.poll() is None:
            compressor.kill()
            compressor.wait()
    result = {"codec": "xz", "raw_bytes": length, "raw_sha256": raw_hash.hexdigest(),
              "compressed_bytes": total, "compressed_sha256": compressed_hash.hexdigest(), "parts": parts}
    verify_payload(result, output_dir)
    return result


def verify_payload(payload, directory):
    """Verify every part, the XZ checks, and the full decompressed partition."""
    names = []
    compressed = hashlib.sha256()
    for part in payload["parts"]:
        path = regular_file(Path(directory) / safe_name(part["name"]))
        need(path.stat().st_size == part["bytes"] and sha256_file(path) == part["sha256"],
             "Payload piece checksum mismatch")
        names.append(str(path))
        with path.open("rb") as source:
            for block in iter(lambda: source.read(BUFFER_BYTES), b""):
                compressed.update(block)
    need(compressed.hexdigest() == payload["compressed_sha256"], "Payload concatenation checksum mismatch")
    producer = subprocess.Popen(["cat", "--", *names], stdout=subprocess.PIPE)
    decoder = subprocess.Popen(["xz", "-dc", "--memlimit-decompress=512MiB"],
                               stdin=producer.stdout, stdout=subprocess.PIPE)
    producer.stdout.close()
    h = hashlib.sha256()
    count = 0
    try:
        while block := decoder.stdout.read(BUFFER_BYTES):
            count += len(block)
            need(count <= payload["raw_bytes"], "Payload decoded beyond source partition")
            h.update(block)
        need(decoder.wait(timeout=30) == 0 and producer.wait(timeout=30) == 0, "Payload XZ decode failed")
        need(count == payload["raw_bytes"] and h.hexdigest() == payload["raw_sha256"],
             "Decoded partition differs from verified source region")
    finally:
        for process in (decoder, producer):
            if process.poll() is None:
                process.kill()
                process.wait()


def fixture():
    import tempfile
    import unittest

    class ImageFixture(unittest.TestCase):
        def test_partition_transport_and_tamper(self):
            with tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                prefix = b"not-the-partition" * 31
                expected = bytes(range(256)) * 6000 + os.urandom(8192)
                image = base / "source.img"
                image.write_bytes(prefix + expected + b"not-the-partition-end")
                payload = compress_region(image, len(prefix), len(expected), base / "parts", "fixture.img.xz", 1733)
                self.assertGreater(len(payload["parts"]), 1)
                self.assertEqual(payload["raw_sha256"], hashlib.sha256(expected).hexdigest())
                first = base / "parts" / payload["parts"][0]["name"]
                first.write_bytes(b"changed" + first.read_bytes()[7:])
                with self.assertRaisesRegex(ValueError, "checksum mismatch"):
                    verify_payload(payload, base / "parts")

        def test_reject_unsafe_regions_and_sources(self):
            with tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / "source.img"
                path.write_bytes(bytes(512))
                for offset, length in ((-1, 1), (0, 0), (500, 20)):
                    with self.assertRaises(ValueError):
                        compress_region(path, offset, length, Path(temporary) / "bad", "bad")
                link = Path(temporary) / "link"
                link.symlink_to(path)
                with self.assertRaises(ValueError):
                    compress_region(link, 0, 5, Path(temporary) / "bad", "bad")
            for url in ("http://github.com/x", "https://example.com/image", "https://github.com/other/repo/releases/download/x/y"):
                with self.assertRaises(ValueError):
                    source_url(url)

        def test_expanded_identity_and_boundary(self):
            with tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                expected = bytes(BUFFER_BYTES) + b"exact-image-data" + bytes(19)
                source = base / "source.xz"
                source.write_bytes(lzma.compress(expected))
                output = decompress_source(source, base / "image", len(expected), hashlib.sha256(expected).hexdigest())
                self.assertEqual(output.read_bytes(), expected)
                with self.assertRaisesRegex(ValueError, "exceeds"):
                    decompress_source(source, base / "short", len(expected) - 1, hashlib.sha256(expected).hexdigest())

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ImageFixture)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    need(result.wasSuccessful(), "Image transport fixture failed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["fixture"])
    args = parser.parse_args()
    if args.command == "fixture":
        fixture()
