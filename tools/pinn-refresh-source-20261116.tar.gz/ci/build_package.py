#!/usr/bin/env python3
"""Convert a pinned public image into one native PINN multiboot package.

Run only on a disposable GitHub-hosted runner in a private mount namespace.
Source disk images and their filesystems remain read-only. The installer only
receives individual partition streams plus an audited relocation hook.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

from pipeline import (REPOSITORY, RELEASE_TAG, RELEASE_BASE, assemble_source,
                      decompress_source, partition_table, compress_region,
                      regular_file, need, sha256_file, safe_name)

BASE = Path(__file__).resolve().parents[1]
OS_IDS = {"ubuntu", "fedora", "arch", "dietpi", "buildroot", "twisteros", "lineageos", "fydeos"}
MIB = 1024 * 1024
WORK_ROOT = Path("/mnt/hackberrypi-pinn-ci")


def inside_source(relative):
    candidate = Path(relative)
    need(not candidate.is_absolute(), "Adapter paths must be repository-relative")
    path = (BASE / candidate).resolve(strict=True)
    need(path.is_relative_to(BASE), "Adapter escapes source tree")
    return path


def import_module(relative, name):
    path = inside_source(relative)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def ci_guard():
    need(os.geteuid() == 0, "Private conversion namespace needs root")
    need(os.environ.get("GITHUB_ACTIONS") == "true", "This full-image build is CI-only")
    need(os.environ.get("GITHUB_REPOSITORY") == REPOSITORY, "Unexpected CI repository")
    need(os.environ.get("RUNNER_ENVIRONMENT") == "github-hosted", "Disposable GitHub-hosted runner required")
    need(os.environ.get("GITHUB_EVENT_NAME") == "workflow_dispatch", "Explicit manual build required")
    need(Path("/proc/self/ns/mnt").stat().st_ino != Path("/proc/1/ns/mnt").stat().st_ino,
         "A private mount namespace is required")


def load_plan(os_id):
    locations = [BASE / "linux-adapters/plans" / (os_id + ".json"),
                 BASE / "android-fydeos-research/plans" / (os_id + ".json")]
    existing = [path for path in locations if path.is_file()]
    need(len(existing) == 1, "One reviewed conversion plan required")
    plan = json.loads(existing[0].read_text())
    need(plan.get("post_install_ready") is True, "OS-specific adapter is not yet ready")
    need(plan.get("schema") == 1 and plan["os_id"].lower() == os_id, "Unexpected plan schema/OS")
    regular_file(inside_source(plan["post_install_file"]))
    need(1 <= plan["boot_source_partition"] <= 128, "Invalid source boot partition")
    raw = plan["raw_partitions"]
    need([row["slot"] for row in raw] == list(range(2, len(raw) + 2)), "Non-contiguous PINN slots")
    need(1 <= len(raw) <= 15, "Unsupported raw partition count")
    need(len({row["source_partition"] for row in raw}) == len(raw), "Duplicate source partition")
    need(plan["boot_source_partition"] not in {row["source_partition"] for row in raw}, "Boot/raw source overlap")
    return plan


@contextmanager
def source_boot(image, source_partition, target):
    """Attach only a regular verified image file, and expose only its FAT read-only."""
    image = regular_file(image).resolve()
    need(image.is_relative_to(WORK_ROOT), "Source image must be in disposable CI work area")
    target = Path(target)
    target.mkdir()
    loop = subprocess.check_output(["losetup", "--find", "--show", "--read-only", "--partscan", str(image)],
                                   text=True).strip()
    need(loop.startswith("/dev/loop") and loop[9:].isdigit(), "Unexpected loop device")
    mounted = False
    try:
        device = Path(loop + "p" + str(source_partition))
        for _ in range(100):
            if device.exists():
                break
            time.sleep(0.1)
        need(device.exists(), "Source partition node not available")
        need(subprocess.check_output(["blockdev", "--getro", loop], text=True).strip() == "1", "Source loop not read-only")
        subprocess.run(["mount", "-t", "vfat", "-o", "ro,nodev,nosuid,noexec", str(device), str(target)], check=True)
        mounted = True
        yield target, loop
    finally:
        if mounted:
            subprocess.run(["umount", str(target)], check=True)
        subprocess.run(["losetup", "--detach", loop], check=True)


def file_record(path):
    path = regular_file(path)
    return {"name": safe_name(path.name), "bytes": path.stat().st_size,
            "sha256": sha256_file(path), "url": RELEASE_BASE + path.name}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def make_boot_tar(boot, output):
    """Retain filesystem content and attributes, with stable archive ownership."""
    with output.open("xb") as destination:
        process = subprocess.Popen(["tar", "--sort=name", "--numeric-owner", "--owner=0", "--group=0",
                                    "--acls", "--xattrs", "--xattrs-include=*", "--selinux",
                                    "-C", str(boot), "-cf", "-", "."], stdout=subprocess.PIPE)
        compressor = subprocess.Popen(["xz", "-3", "-T2", "--check=crc64", "-c"],
                                      stdin=process.stdout, stdout=destination)
        process.stdout.close()
        need(compressor.wait() == 0 and process.wait() == 0, "Boot archive creation failed")
        destination.flush()
        os.fsync(destination.fileno())
    # Verify the actual compressed archive, without extracting or executing it.
    with lzma_archive(output) as archive:
        members = archive.getmembers()
        names = {member.name.removeprefix("./") for member in members}
        need({"config.txt", "pinn/payload.json", "pinn/partition_setup.sh", "pinn/post-install.sh"} <= names,
             "Boot archive is missing its required installer files")
        need(all(not member.name.startswith("/") and ".." not in Path(member.name).parts for member in members),
             "Unsafe boot archive member")
    need(output.stat().st_size < 2_147_483_648, "Boot archive exceeds GitHub release attachment limit")


def lzma_archive(path):
    return tarfile.open(path, "r:xz")


def make_stub(path):
    with path.open("xb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressor:
            compressor.write(bytes(16384))


def prepare_boot(plan, source, boot):
    (boot / "pinn").mkdir(exist_ok=True)
    post = inside_source(plan["post_install_file"]).read_bytes()
    if "boot_prepare_module" in plan:
        if source["family"] == "LineageOS":
            dts = inside_source("android-fydeos-research/android-pinn-overlay.dts")
            subprocess.run(["dtc", "-@", "-I", "dts", "-O", "dtb", "-o",
                            str(dts.with_name("android-pinn.dtbo")), str(dts)], check=True)
        module = import_module(plan["boot_prepare_module"], "os_boot_prepare")
        result = getattr(module, plan.get("boot_prepare_function", "prepare_boot"))(source["family"], boot)
        required = result.get("source_hash_required")
        need(not required or required == source["source"]["sha256"], "Boot transformer belongs to another image")
        need((boot / "pinn/post-install.sh").read_bytes() == post, "OS boot preparation changed the reviewed hook")
    transform = plan.get("required_boot_transform")
    if transform:
        report_path = boot / "pinn/boot-transform-report.json"
        replacements = {"{boot_dir}": str(boot), "{report_path}": str(report_path)}
        arguments = [replacements.get(value, value) for value in transform["args"]]
        subprocess.run([sys.executable, str(inside_source(transform["script"])), *arguments], check=True)
        report = json.loads(report_path.read_text())
        need(report.get("passed") is True and report.get("boot_transform_completed") is True,
             "OS early-boot transform did not finish")
        need(report["source_sha256"] == transform["expected_source_archive_sha256"]
             and report["unchanged_entries_sha256"] == transform["expected_unchanged_entries_sha256"]
             and report["entries"] == transform["expected_entry_count"], "OS early-boot transform proof differs")
        marker = boot / transform["marker"]
        need(marker.read_text().strip() == transform["marker_value"], "OS early-boot transform marker missing")
    return post


def source_preflight(plan, source, boot, loop, work):
    """Resolve source-supplied Fyde runtime and scaling files without executing it."""
    if "preflight_module" not in plan:
        return None
    mounted = []
    paths = {}
    try:
        for role in ("root", "state"):
            number = plan[f"preflight_{role}_source_partition"]
            rows = [row for row in plan["raw_partitions"] if row["source_partition"] == number]
            need(len(rows) == 1 and rows[0]["filesystem"] in ("ext2", "ext4"), "Invalid source preflight filesystem")
            filesystem = rows[0]["filesystem"]
            target = work / ("preflight-" + role)
            target.mkdir()
            options = "ro,nodev,nosuid,noexec" + (",noload" if filesystem == "ext4" else "")
            subprocess.run(["mount", "-t", filesystem, "-o", options, loop + "p" + str(number), str(target)], check=True)
            mounted.append(target)
            paths[role] = target
        module = import_module(plan["preflight_module"], "source_preflight")
        report = getattr(module, plan.get("preflight_function", "preflight"))(
            source["family"], paths["root"], paths["state"], boot)
        need(report.get("passed") is True, "Read-only source runtime preflight failed")
        hook = regular_file(boot / "pinn/post-install.sh")
        need(sha256_file(hook) == report["post_hook_sha256"], "Runtime-bound hook differs from preflight receipt")
        return hook.read_bytes()
    finally:
        for target in reversed(mounted):
            subprocess.run(["umount", str(target)], check=True)


def build(os_id):
    ci_guard()
    need(os_id in OS_IDS, "Unsupported OS")
    plan = load_plan(os_id)
    source = json.loads((BASE / "ci/sources" / (os_id + ".json")).read_text())
    need(source["os_id"] == os_id, "Pinned source OS differs")
    need(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 ._-]{0,79}", source["os_name"]), "Unsafe native PINN OS folder name")
    required_hash = plan.get("source_hash_required")
    need(not required_hash or required_hash == source["source"]["sha256"], "Plan/source identity differs")
    work = WORK_ROOT / os_id
    need(not work.exists(), "Refusing to reuse an incomplete image conversion workspace")
    work.mkdir(parents=True)
    output = work / "out"
    output.mkdir()
    need(shutil.disk_usage(work).free >= source["source"]["extract_size"] + source["source"]["bytes"] + 4 * 1024**3,
         "Insufficient disposable runner space for verified conversion")
    print(f"{os_id}: downloading and verifying pinned source", flush=True)
    compressed = assemble_source(source["source"], work / "source")
    print(f"{os_id}: source download verified; decoding complete image", flush=True)
    image = decompress_source(compressed, work / "source.img", source["source"]["extract_size"],
                              source["source"]["extract_sha256"])
    compressed.unlink()
    table = partition_table(image)
    boot_source = table["partitions"][plan["boot_source_partition"]]
    boot = work / "boot"
    print(f"{os_id}: raw image verified; preparing native boot adapter", flush=True)
    with source_boot(image, plan["boot_source_partition"], work / "mount") as (mounted, loop):
        if source["family"] == "LineageOS":
            vendors = [row for row in plan["raw_partitions"] if row["label"].endswith("_vendor")]
            need(len(vendors) == 1, "One Android vendor source required")
            subprocess.run([sys.executable, str(inside_source("android-fydeos-research/test-hooks.py")),
                            "--source-boot", str(mounted), "--source-vendor",
                            loop + "p" + str(vendors[0]["source_partition"])], check=True, cwd=BASE)
        shutil.copytree(mounted, boot, symlinks=True)
        post_script = prepare_boot(plan, source, boot)
        bound = source_preflight(plan, source, boot, loop, work)
        if bound is not None:
            post_script = bound
    need((boot / "config.txt").is_file(), "Native FAT boot payload missing config.txt")
    payload = {"schema": 1, "os_id": os_id, "os_name": source["os_name"],
               "source": source["source"], "post_install": plan.get("post_install_config", {}), "partitions": []}
    partitions = []
    stubs = []
    boot_nominal = max(plan["boot_nominal_mib"], math.ceil(boot_source["bytes"] / MIB))
    boot_label = plan.get("boot_label", "hb" + os_id[:5] + "boot")
    need(len(boot_label.encode("ascii")) <= 11, "FAT volume label too long")
    partitions.append({"label": boot_label, "filesystem_type": "fat", "partition_size_nominal": boot_nominal,
                       "want_maximised": False, "mkfs_options": "-F 32"})
    for row in plan["raw_partitions"]:
        region = table["partitions"][row["source_partition"]]
        expected_sectors = row.get("source_sectors")
        need(not expected_sectors or expected_sectors * 512 == region["bytes"], "Source partition layout changed")
        prefix = safe_name(f"{os_id}-slot{row['slot']}.img.xz")
        print(f"{os_id}: compressing and verifying partition slot {row['slot']} ({region['bytes']} bytes)", flush=True)
        encoded = compress_region(image, region["offset"], region["bytes"], output, prefix)
        payload["partitions"].append({**encoded, "slot": row["slot"], "label": row["label"],
                                       "filesystem": row["filesystem"]})
        stub = output / f"{os_id}-slot{row['slot']}-stub.img.gz"
        make_stub(stub)
        record = file_record(stub)
        stubs.append(record)
        nominal = math.ceil(region["bytes"] / MIB) + row.get("nominal_extra_mib", 0)
        partitions.append({"label": row["label"], "filesystem_type": "raw", "partition_size_nominal": nominal,
                           "want_maximised": bool(row["want_maximised"]), "uncompressed_tarball_size": 1,
                           "sha256sum": record["sha256"]})
    generator = import_module("linux-adapters/generate_payload.py", "receiver_generator")
    generated = generator.render(payload, post_script)
    installer = boot / "pinn"
    installer.mkdir(exist_ok=True)
    for name, content in generated.items():
        safe_name(name)
        path = installer / name
        if path.exists() and name == "post-install.sh":
            need(regular_file(path).read_bytes() == content, "Prepared post-install hook changed")
        else:
            path.write_bytes(content)
        path.chmod(0o755 if name.endswith(".sh") else 0o644)
    setup = output / (os_id + "-partition_setup.sh")
    setup.write_bytes(generated["partition_setup.sh"])
    setup.chmod(0o755)
    boot_archive = output / (os_id + "-boot.tar.xz")
    make_boot_tar(boot, boot_archive)
    boot_record = file_record(boot_archive)
    total_boot_bytes = sum(path.stat().st_size for path in boot.rglob("*") if path.is_file())
    partitions[0].update(uncompressed_tarball_size=max(1, math.ceil(total_boot_bytes / MIB)),
                         sha256sum=boot_record["sha256"])
    nominal_size = sum(row["partition_size_nominal"] for row in partitions)
    download_size = boot_record["bytes"] + sum(row["bytes"] for row in stubs)
    download_size += sum(row["compressed_bytes"] for row in payload["partitions"])
    features = "900 workspace, Display Scale, screen/touch and battery"
    if os_id != "fydeos":
        features += ", with Neofetch"
    description = (source["release_title"] + ". PINN multiboot preview; " + features + ". "
                   "Online Install downloads the partition data.")
    if os_id in ("fydeos", "lineageos"):
        description += " Upgrade through PINN; native whole-disk recovery/OTA is disabled."
    info = {"name": source["os_name"], "description": description, "release_date": "2026-11-16",
            "version": source["source_release"] + "+pinn-20261116", "supported_models": ["Compute Module 5"],
            "nominal_size": nominal_size, "group": "General", "download_size": download_size,
            "supports_usb_boot": False, "supports_usb_root": False, "supports_backup": False,
            "use_partuuid": False, "sha256sum": sha256_file(setup), "online_install_only": True,
            "url": f"https://github.com/{REPOSITORY}/releases/tag/{RELEASE_TAG}"}
    info_path = output / (os_id + "-os.json")
    partitions_path = output / (os_id + "-partitions.json")
    write_json(info_path, info)
    write_json(partitions_path, {"partitions": partitions})
    assets = [file_record(path) for path in sorted(output.iterdir()) if path.is_file()]
    feed = {"os_name": info["name"], "description": description, "release_date": "2026-11-16",
            "supported_models": ["Compute Module 5"], "nominal_size": nominal_size, "group": "General",
            "download_size": download_size, "supports_usb_boot": False, "supports_usb_root": False,
            "use_partuuid": False, "online_install_only": True,
            "icon": source["icon"], "os_info": RELEASE_BASE + info_path.name,
            "partitions_info": RELEASE_BASE + partitions_path.name, "partition_setup": RELEASE_BASE + setup.name,
            "tarballs": [boot_record["url"], *[row["url"] for row in stubs]]}
    result = {"schema": 1, "passed": True, "os_id": os_id, "source": source,
              "source_partition_table": table, "payload": payload, "assets": assets,
              "feed_entry": feed, "all_partition_full_xz_to_raw_hash_checks_passed": True,
              "nonboot_filesystem_attributes_preserved_by_raw_transport": True,
              "source_image_mounted_readonly_private_namespace": True,
              "adapter_source_commit": os.environ.get("GITHUB_SHA"),
              "workflow_run": os.environ.get("GITHUB_RUN_ID"),
              "final_multiboot_physical_boot_tested": False}
    write_json(output / (os_id + "-PINN-package.json"), result)
    image.unlink()
    print(json.dumps({"passed": True, "os_id": os_id, "assets": len(assets) + 1,
                      "download_bytes": download_size, "nominal_mib": nominal_size,
                      "output_directory": str(output)}, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("os_id", choices=sorted(OS_IDS))
    args = parser.parse_args()
    build(args.os_id)
