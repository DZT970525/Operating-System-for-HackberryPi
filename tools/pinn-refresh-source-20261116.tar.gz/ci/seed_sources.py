#!/usr/bin/env python3
"""Freeze only already-published, checksum-audited source identities for CI."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
WORK = BASE.parent
FAMILIES = ("Ubuntu", "Fedora", "Arch", "DietPi", "Buildroot", "TwisterOS", "LineageOS", "FydeOS")
PINN_NAMES = {"Ubuntu": "Ubuntu for HackberryPi", "Fedora": "Fedora Remix for HackberryPi",
              "Arch": "Arch Linux ARM for HackberryPi", "DietPi": "DietPi for HackberryPi",
              "Buildroot": "Buildroot for HackberryPi", "TwisterOS": "Twister OS for HackberryPi",
              "LineageOS": "LineageOS for HackberryPi", "FydeOS": "FydeOS for HackberryPi"}


def seed():
    audit = json.loads((BASE / "catalog-audit.json").read_text())
    catalog = json.loads((BASE / "public-snapshot/os_list_imager.json").read_text())
    by_url = {row["url"]: row for row in catalog["os_list"] if "url" in row}
    sources = {}
    for entry in audit["standalone"]:
        family = entry["family"]
        if family not in FAMILIES:
            continue
        assets = [{k: row[k] for k in ("name", "bytes", "sha256", "url")} for row in entry["assets"]]
        assert assets and all(row["state"] == "uploaded" for row in entry["assets"])
        if len(assets) == 1 and assets[0]["url"] in by_url:
            row = by_url[assets[0]["url"]]
            icon = row["icon"]
            assert assets[0]["bytes"] == row["image_download_size"]
            assert assets[0]["sha256"] == row["image_download_sha256"]
            identity = {"bytes": row["image_download_size"], "sha256": row["image_download_sha256"],
                        "extract_size": row["extract_size"], "extract_sha256": row["extract_sha256"]}
        else:
            icon = ("https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/"
                    + family + "/" + family + "_HackberryPi.png")
            local = WORK / {"TwisterOS": "publish-twister", "Ubuntu": "publish-ubuntu"}[family] / "compressed-image.json"
            image = json.loads(local.read_text())
            identity = {k: image[k] for k in ("bytes", "sha256", "extract_size", "extract_sha256")}
            assert identity["sha256"] == entry["checksum_file"]["complete_compressed_image_sha256"]
            sums = (BASE / Path(entry["checksum_file"]["local"]).name).read_text()
            proof_path = WORK / ({"TwisterOS": "publish-twister/docs-stage/final/release-assets/image-verification.json",
                                  "Ubuntu": "publish-ubuntu/docs-stage/fallback/final/Ubuntu/image-verification.json"}[family])
            proof_bytes = proof_path.read_bytes()
            assert hashlib.sha256(proof_bytes).hexdigest() + "  image-verification.json" in sums
            proof = json.loads(proof_bytes)
            assert proof["complete_decompressed_stream_verified"] is True
            if family == "TwisterOS":
                assert proof["expanded_image_sha256"] == identity["extract_sha256"]
                assert proof["compressed_image_sha256"] == identity["sha256"]
            else:
                assert all(proof["image"][key] == value for key, value in identity.items())
        assert sum(row["bytes"] for row in assets) == identity["bytes"]
        sources[family.lower()] = {"schema": 1, "os_id": family.lower(), "family": family, "icon": icon,
            "os_name": PINN_NAMES[family], "release_title": entry["name"], "source_release": entry["tag"],
            "source_repository_commit": audit["repository_commit"],
            "source": {**identity, "assets": assets}, "source_format": "standalone-disk-image"}
    assert set(sources) == {family.lower() for family in FAMILIES}
    output = HERE / "sources"
    output.mkdir(exist_ok=True)
    receipt = {}
    for os_id, row in sources.items():
        path = output / (os_id + ".json")
        content = (json.dumps(row, indent=2) + "\n").encode()
        path.write_bytes(content)
        receipt[path.name] = {"sha256": hashlib.sha256(content).hexdigest(),
                              "source_bytes": row["source"]["bytes"],
                              "source_raw_bytes": row["source"]["extract_size"]}
    (HERE / "source-seed-report.json").write_text(json.dumps({"passed": True,
        "fixed_public_repository_commit": audit["repository_commit"], "sources": receipt,
        "remote_calls": 0, "source_card_accessed": False, "native_pinn_packages_not_yet_claimed_ready": True}, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    seed()
