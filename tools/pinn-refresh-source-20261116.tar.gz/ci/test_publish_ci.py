#!/usr/bin/env python3
"""Offline publisher fixtures. No gh command, network or block device is used."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import publish_ci as pub

COMMIT='a'*40


class FakeGitHub:
    def __init__(self, assets=None, draft=True):
        self.data={'id':123,'tag_name':pub.RELEASE_TAG,'draft':draft,'prerelease':True,
                   'body':pub.candidate_body()}
        self.rows={} if assets is None else copy.deepcopy(assets)
        self.deleted=[];self.uploaded=[]
        self.patches=[]
    def release(self): return copy.deepcopy(self.data)
    def assets(self, release): return copy.deepcopy(self.rows)
    def delete_asset(self, release, asset): self.deleted.append(asset['name']);self.rows.pop(asset['name'])
    def upload(self,path):
        row=pub.record(path);self.uploaded.append(row['name'])
        self.rows[row['name']]={'id':400+len(self.rows),'name':row['name'],'state':'uploaded',
          'size':row['bytes'],'digest':'sha256:'+row['sha256'],'browser_download_url':row['url']}
    def require_uncreated_tag(self): return None
    def api(self,path,method='GET',body=None,**kwargs):
        self.patches.append((path,method,body));self.data.update(body or {});return self.release()


class AssetFixtures(unittest.TestCase):
    def test_exact_existing_is_reused(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'ubuntu-fixture.part01';path.write_bytes(b'fixture')
            row=pub.record(path);api=FakeGitHub();api.upload(path);api.uploaded=[]
            self.assertEqual(pub.ensure_asset(api,path,row,os_id='ubuntu'),'exact-existing')
            self.assertEqual(api.uploaded,[]);self.assertEqual(api.deleted,[])

    def test_only_owned_same_filename_is_replaced(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'ubuntu-fixture.part01';path.write_bytes(b'new-data')
            api=FakeGitHub({'ubuntu-fixture.part01':{'id':4,'name':path.name,'state':'starter','size':0},
                'unrelated-user-file.txt':{'id':9,'name':'unrelated-user-file.txt'}})
            pub.ensure_asset(api,path,pub.record(path),os_id='ubuntu')
            self.assertEqual(api.deleted,[path.name]);self.assertIn('unrelated-user-file.txt',api.rows)

    def test_public_release_and_unowned_names_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'ubuntu-fixture.part01';path.write_bytes(b'x')
            with self.assertRaises(ValueError):pub.ensure_asset(FakeGitHub(draft=False),path,pub.record(path),os_id='ubuntu')
            other=Path(directory)/'other-user-file';other.write_bytes(b'x')
            with self.assertRaises(ValueError):pub.ensure_asset(FakeGitHub(),other,pub.record(other),os_id='ubuntu')

    def test_ci_guard_prevents_any_local_gh_execution(self):
        with patch.dict(os.environ,{},clear=True),patch('subprocess.run',side_effect=AssertionError('must not run gh')):
            with self.assertRaises(ValueError):pub.GitHub()

    def test_prepare_updates_only_untagged_private_draft_target(self):
        api=FakeGitHub();api.data['target_commitish']='f'*40
        with patch.dict(os.environ,{'GITHUB_SHA':COMMIT}):result=pub.prepare(api)
        self.assertTrue(result['draft']);self.assertEqual(api.data['target_commitish'],COMMIT)
        self.assertEqual(api.patches[0][1],'PATCH');self.assertTrue(api.patches[0][2]['draft'])


class MetadataFixtures(unittest.TestCase):
    def package(self):
        source={'schema':1,'os_id':'ubuntu','os_name':'Ubuntu disposable fixture',
                'source':{'sha256':'b'*64,'extract_sha256':'c'*64,'bytes':50,'extract_size':8192}}
        names=['ubuntu-boot.tar.xz','ubuntu-os.json','ubuntu-partitions.json',
               'ubuntu-partition_setup.sh','ubuntu-slot2-stub.img.gz','ubuntu-slot2.img.xz.part01']
        assets=[{'name':name,'bytes':12,'sha256':hashlib.sha256(name.encode()).hexdigest(),
                 'url':pub.RELEASE_BASE+name} for name in names]
        payload={'schema':1,'os_id':'ubuntu','os_name':source['os_name'],'source':source['source'],
             'partitions':[{'slot':2,'label':'hpu_root','raw_bytes':4096,'raw_sha256':'d'*64,'compressed_sha256':'e'*64,
                            'compressed_bytes':12,'parts':[assets[-1]]}]}
        feed={'os_name':source['os_name'],'supported_models':['Compute Module 5'],'group':'General',
              'supports_usb_boot':False,'supports_usb_root':False,'nominal_size':512,
              'use_partuuid':False,'online_install_only':True,
              'download_size':36,'os_info':pub.RELEASE_BASE+'ubuntu-os.json',
              'partitions_info':pub.RELEASE_BASE+'ubuntu-partitions.json',
              'partition_setup':pub.RELEASE_BASE+'ubuntu-partition_setup.sh',
              'tarballs':[pub.RELEASE_BASE+names[0],pub.RELEASE_BASE+names[4]]}
        package={'schema':1,'passed':True,'os_id':'ubuntu','source':source,'adapter_source_commit':COMMIT,
                'all_partition_full_xz_to_raw_hash_checks_passed':True,
                'nonboot_filesystem_attributes_preserved_by_raw_transport':True,
                'source_image_mounted_readonly_private_namespace':True,
                'final_multiboot_physical_boot_tested':False,'assets':assets,'payload':payload,'feed_entry':feed}
        return package,source

    def test_measured_metadata_contract_passes(self):
        package,source=self.package();self.assertEqual(len(pub.validate_package(package,'ubuntu',source,COMMIT)),6)

    def test_native_setup_checksum_raw_layout_and_online_flag(self):
        package,source=self.package();assets=pub.validate_package(package,'ubuntu',source,COMMIT)
        info={'name':source['os_name'],'supported_models':['Compute Module 5'],'use_partuuid':False,
              'online_install_only':True,'sha256sum':assets['ubuntu-partition_setup.sh']['sha256'],
              'supports_usb_boot':False,'supports_usb_root':False,'nominal_size':512,'download_size':36}
        partitions={'partitions':[{'label':'hpu_boot','filesystem_type':'fat','partition_size_nominal':511,
                'sha256sum':assets['ubuntu-boot.tar.xz']['sha256']},
                {'label':'hpu_root','filesystem_type':'raw','partition_size_nominal':1,
                 'sha256sum':assets['ubuntu-slot2-stub.img.gz']['sha256']}]}
        pub.validate_native_metadata(info,partitions,package,assets)
        for field,value in [('sha256sum','f'*64),('online_install_only',False),('use_partuuid',True)]:
            broken=dict(info);broken[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):pub.validate_native_metadata(broken,partitions,package,assets)

    def test_source_cross_release_and_fake_boot_claim_refused(self):
        for mode in ['source','url','physical','full-image-tarball','usb','commit']:
            package,source=self.package()
            if mode=='source':package['source']=copy.deepcopy(source);package['source']['source']['sha256']='f'*64
            if mode=='url':package['assets'][0]['url']='https://example.com/other'
            if mode=='physical':package['final_multiboot_physical_boot_tested']=True
            if mode=='full-image-tarball':package['feed_entry']['tarballs'][-1]=pub.RELEASE_BASE+'ubuntu-whole-disk.img.xz'
            if mode=='usb':package['feed_entry']['supports_usb_root']=True
            if mode=='commit':package['adapter_source_commit']='f'*40
            with self.subTest(mode=mode),self.assertRaises(ValueError):pub.validate_package(package,'ubuntu',source,COMMIT)


class LegacyFixtures(unittest.TestCase):
    def test_actual_four_pins_urls_and_wrapper_sha(self):
        with tempfile.TemporaryDirectory() as directory:
            entries,files=pub.build_legacy(Path(directory))
            pins=json.loads((pub.BASE/'ci/legacy-pins.json').read_text())
            self.assertEqual(len(entries),4);self.assertEqual(len(files),12)
            for os_id,entry in entries.items():
                self.assertEqual(entry['tarballs'],pins[os_id]['tarballs'])
                info=json.loads((Path(directory)/(os_id+'-legacy-os.json')).read_text())
                setup=Path(directory)/(os_id+'-legacy-partition_setup.sh')
                self.assertEqual(info['sha256sum'],pub.sha256_file(setup))
                self.assertFalse(info['supports_usb_boot']);self.assertFalse(info['supports_usb_root'])
                self.assertEqual(info['online_install_only'],os_id!='manjaro')
                self.assertEqual(entry['online_install_only'],os_id!='manjaro')
                subprocess.run(['/bin/sh','-n',str(setup)],check=True)

    def test_original_runs_child_preserving_script_path_then_adds_minor64(self):
        original=b'#!/bin/sh\nprintf "%s\\n" "$0" > "$WRAPPER_FIXTURE_LOG"\nexit 0\n'
        data=pub.render_legacy_wrapper('rpios',original,hashlib.sha256(original).hexdigest())
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);boot=root/'boot';boot.mkdir()
            script=root/'rpios-legacy-partition_setup.sh';script.write_bytes(data)
            cmd=boot/'cmdline.txt';cmd.write_text('root=PARTUUID=12345678-07 rootwait mmcblk.perdev_minors=32\n')
            log=root/'original-script-path'
            env=dict(os.environ,PINN_BOOT_MOUNT=str(boot),WRAPPER_FIXTURE_LOG=str(log))
            subprocess.run(['/bin/sh',str(script)],env=env,check=True,capture_output=True,timeout=10)
            self.assertEqual(log.read_text().strip(),str(script))
            self.assertEqual(cmd.read_text().count('mmcblk.perdev_minors=64'),1)
            self.assertIn('root=PARTUUID=12345678-07',cmd.read_text())
        with self.assertRaises(ValueError):pub.render_legacy_wrapper('rpios',original,'f'*64)


if __name__=='__main__':unittest.main(verbosity=2)
