#!/usr/bin/env python3
"""Fixed-repository, fixed-draft-only PINN candidate asset publication.

No remote operation is reachable without explicit GitHub-hosted workflow guards
and GH_TOKEN from the CI environment. This program never publishes a release,
forces a tag, commits to main, or modifies another release.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile
import time

from pipeline import REPOSITORY, RELEASE_TAG, RELEASE_BASE, need, regular_file, safe_name, sha256_file

BASE = Path(__file__).resolve().parents[1]
WORK_ROOT = Path('/mnt/hackberrypi-pinn-ci')
OS_IDS = ('ubuntu', 'fedora', 'arch', 'dietpi', 'buildroot', 'twisteros', 'lineageos', 'fydeos')
LEGACY = {'rpios': 'RPiOS', 'kali': 'Kali', 'omarchy': 'Omarchy', 'manjaro': 'Manjaro'}
ORDER = ('rpios', 'ubuntu', 'kali', 'fydeos', 'omarchy', 'manjaro', 'fedora', 'arch', 'dietpi', 'buildroot', 'lineageos', 'twisteros')
BEGIN = '<!-- BEGIN hackberrypi-pinn-candidate-v1 -->'
END = '<!-- END hackberrypi-pinn-candidate-v1 -->'
TITLE = 'HackberryPi CM5 PINN Multiboot — 12 OS catalog (candidate)'
SOURCE_ARCHIVE = 'HackberryPi-PINN-Adapters-Source-20261116.tar.xz'
EVIDENCE_ARCHIVE = 'HackberryPi-PINN-Catalog-Evidence-20261116.tar.xz'
GLOBAL_NAMES = {'os_list_v3.json', 'repo_list.json', 'SHA256SUMS', 'PINN-MULTIBOOT-VERIFICATION.json',
                'PINN-MULTIBOOT-SOURCES.json', SOURCE_ARCHIVE, EVIDENCE_ARCHIVE}
GLOBAL_NAMES |= {f'{name}-legacy-{suffix}' for name in LEGACY for suffix in ('partition_setup.sh', 'os.json', 'partitions.json')}
SHA = re.compile('[0-9a-f]{64}\\Z')
MAX_METADATA = 2 * 1024**2
MAX_RELEASE_PAGES = 20


def ci_guard():
    need(os.environ.get('GITHUB_ACTIONS') == 'true', 'Publication is CI-only')
    need(os.environ.get('GITHUB_REPOSITORY') == REPOSITORY, 'Unexpected publication repository')
    need(os.environ.get('RUNNER_ENVIRONMENT') == 'github-hosted', 'Disposable GitHub-hosted runner required')
    need(os.environ.get('GITHUB_EVENT_NAME') == 'workflow_dispatch', 'Explicit workflow dispatch required')
    need(re.fullmatch('[0-9a-f]{40}', os.environ.get('GITHUB_SHA', '')), 'Pinned adapter commit missing')
    need(bool(os.environ.get('GH_TOKEN')), 'GH_TOKEN must come from the approved CI environment')


def record(path):
    path = regular_file(path)
    return {'name': safe_name(path.name), 'bytes': path.stat().st_size,
            'sha256': sha256_file(path), 'url': RELEASE_BASE + path.name}


def validate_record(row, prefix=None):
    name = safe_name(row['name'])
    need(prefix is None or name.startswith(prefix + '-'), 'Asset is outside this OS-owned prefix')
    need(type(row['bytes']) is int and 0 < row['bytes'] < 2_147_483_648, 'Invalid attachment size')
    need(SHA.fullmatch(row['sha256']), 'Invalid attachment SHA256')
    need(row['url'] == RELEASE_BASE + name, 'Attachment belongs to another release')
    return row


def validate_package(package, os_id, source, commit):
    need(os_id in OS_IDS and package.get('os_id') == os_id and package.get('schema') == 1,
         'Wrong package identity')
    need(package.get('passed') is True and package.get('source') == source, 'Package/source proof differs')
    need(source.get('schema') == 1 and source.get('os_id') == os_id and
         SHA.fullmatch(source['source']['sha256']) and SHA.fullmatch(source['source']['extract_sha256']),
         'Pinned complete source image identity is missing')
    need(package.get('adapter_source_commit') == commit, 'Package uses another adapter source commit')
    for key in ('all_partition_full_xz_to_raw_hash_checks_passed',
                'nonboot_filesystem_attributes_preserved_by_raw_transport',
                'source_image_mounted_readonly_private_namespace'):
        need(package.get(key) is True, 'Required conversion proof is missing: ' + key)
    need(package.get('final_multiboot_physical_boot_tested') is False, 'Do not invent a physical boot result')
    assets = {}
    for row in package['assets']:
        validate_record(row, os_id)
        need(row['name'] not in assets, 'Duplicate package attachment')
        assets[row['name']] = row
    required = {os_id + suffix for suffix in ('-boot.tar.xz', '-os.json', '-partitions.json', '-partition_setup.sh')}
    need(required <= assets.keys(), 'Required native PINN metadata/boot attachments missing')
    payload = package['payload']
    need(payload['schema'] == 1 and payload['os_id'] == os_id and payload['os_name'] == source['os_name'] and payload['source'] == source['source'],
         'Payload/source identity differs')
    parts = payload['partitions']
    need([x['slot'] for x in parts] == list(range(2, len(parts)+2)), 'Invalid payload slot allocation')
    for part in parts:
        need(SHA.fullmatch(part['raw_sha256']) and SHA.fullmatch(part['compressed_sha256']), 'Missing full stream checksums')
        need(type(part['raw_bytes']) is int and part['raw_bytes'] > 0 and part['raw_bytes'] % 512 == 0,
             'Invalid raw partition length')
        need(sum(x['bytes'] for x in part['parts']) == part['compressed_bytes'], 'Incomplete compressed stream')
        for item in part['parts']:
            validate_record(item, os_id)
            need(item['bytes'] <= 149000000 and assets.get(item['name']) == item, 'Payload chunk proof differs')
    feed = package['feed_entry']
    need(feed['os_name'] == source['os_name'], 'Catalog title belongs to another source')
    need(feed['supported_models'] == ['Compute Module 5'] and feed['group'] == 'General', 'Wrong device/category')
    need(feed['supports_usb_boot'] is False and feed['supports_usb_root'] is False, 'Only CM5 SD installation is claimed')
    need(feed.get('online_install_only') is True, 'Raw payload packages require an explicit online-install flag')
    need(feed.get('use_partuuid') is False, 'Raw placeholder metadata must disable UUID lookup')
    need(feed['os_info'] == RELEASE_BASE + os_id + '-os.json' and
         feed['partitions_info'] == RELEASE_BASE + os_id + '-partitions.json' and
         feed['partition_setup'] == RELEASE_BASE + os_id + '-partition_setup.sh', 'Feed metadata URL differs')
    expected_tarballs = [RELEASE_BASE + os_id + '-boot.tar.xz'] + [
        RELEASE_BASE + f"{os_id}-slot{x['slot']}-stub.img.gz" for x in parts]
    need(feed['tarballs'] == expected_tarballs, 'Native PINN tarball/stub ordering differs')
    need(all(url.removeprefix(RELEASE_BASE) in assets for url in feed['tarballs']), 'Feed references missing native attachment')
    download = sum(assets[url.removeprefix(RELEASE_BASE)]['bytes'] for url in feed['tarballs'])
    download += sum(x['compressed_bytes'] for x in parts)
    need(feed['download_size'] == download and feed['nominal_size'] > 0, 'Feed sizes differ from actual packages')
    return assets


def server_match(asset, expected):
    return (asset.get('state') == 'uploaded' and asset.get('size') == expected['bytes'] and
            asset.get('digest') == 'sha256:' + expected['sha256'] and
            asset.get('browser_download_url') == expected['url'])


def validate_native_metadata(info, partition_info, package, assets):
    feed=package['feed_entry'];os_id=package['os_id'];payload=package['payload']['partitions']
    need(info['name']==feed['os_name'] and info['supported_models']==['Compute Module 5'], 'OS metadata identity differs')
    need(info.get('use_partuuid') is False and info.get('online_install_only') is True,
         'OS metadata must declare raw placeholders and online installation')
    need(info['sha256sum']==assets[os_id+'-partition_setup.sh']['sha256'], 'os.json setup-script checksum differs')
    need(info['supports_usb_boot'] is False and info['supports_usb_root'] is False, 'OS metadata claims unsupported USB installation')
    rows=partition_info['partitions']
    need(len(rows)==len(payload)+1 and rows[0]['filesystem_type']=='fat', 'Native PINN first FAT/raw layout differs')
    need(len(rows[0]['label'].encode('ascii'))<=11, 'FAT label exceeds its filesystem limit')
    for row,url in zip(rows,feed['tarballs']):
        need(row['sha256sum']==assets[url.removeprefix(RELEASE_BASE)]['sha256'], 'Native tarball/stub checksum differs')
        need(type(row['partition_size_nominal']) is int and row['partition_size_nominal']>0, 'Invalid partition allocation')
    for row,part in zip(rows[1:],payload):
        need(row['filesystem_type']=='raw' and row['label']==part['label'], 'Nonboot raw placeholder metadata differs')
        need(row['partition_size_nominal']*1024**2>=part['raw_bytes'], 'PINN nominal partition cannot hold raw payload')
    need(sum(row['partition_size_nominal'] for row in rows)==feed['nominal_size']==info['nominal_size'], 'Native nominal allocation differs')
    need(info['download_size']==feed['download_size'], 'OS metadata download size differs')


def owned_release(release):
    identity = ({key:release.get(key) for key in ('id','tag_name','draft','prerelease','target_commitish')}
                if isinstance(release,dict) else {'type':type(release).__name__})
    need(isinstance(release,dict) and release.get('tag_name') == RELEASE_TAG,
         'Wrong candidate release: '+json.dumps(identity,ensure_ascii=True)[:500])
    need(release.get('draft') is True and release.get('prerelease') is True, 'Refusing any public/noncandidate release')
    need(BEGIN in release.get('body', '') and END in release.get('body', ''), 'Draft is not owned by this fixed workflow')
    need(type(release.get('id')) is int and release['id'] > 0, 'Invalid release id')
    return release


class GhError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message); self.status = status


class GitHub:
    def __init__(self):
        ci_guard()
        self._release_id = None
        self.env = dict(os.environ, GH_REPO=REPOSITORY, GH_HOST='github.com',
                        GH_PROMPT_DISABLED='1', GH_NO_UPDATE_NOTIFIER='1')

    def run(self, args, *, json_result=False, output=None):
        # Arguments are structured, never interpolated into a shell command.
        result = subprocess.run(['gh', *args], env=self.env, stdout=subprocess.PIPE if output is None else output,
                                stderr=subprocess.PIPE, check=False)
        if result.returncode:
            text = result.stderr.decode(errors='replace').replace(self.env['GH_TOKEN'], '[redacted]')
            status = re.search(r'HTTP (\d{3})', text)
            raise GhError('Fixed PINN draft operation failed: ' + text[:600], int(status[1]) if status else None)
        if json_result:
            need(len(result.stdout) <= 8*MAX_METADATA, 'Unexpected API metadata size')
            return json.loads(result.stdout)
        return result.stdout

    def api(self, path, *, method='GET', body=None, paginate=False):
        need(path.startswith(f'repos/{REPOSITORY}/releases'), 'API path outside fixed release family')
        args = ['api', path, '--method', method, '-H', 'Accept: application/vnd.github+json']
        if paginate: args += ['--paginate', '--slurp']
        if body is None: return self.run(args, json_result=method != 'DELETE')
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json') as payload:
            json.dump(body, payload); payload.flush()
            return self.run(args + ['--input', payload.name], json_result=True)

    def release(self):
        # Cache only the identity, never the mutable draft/ownership state.
        # Every subsequent call freshly checks that exact numeric release.
        release_id = getattr(self, '_release_id', None)
        if release_id is not None:
            release = owned_release(self.api(f'repos/{REPOSITORY}/releases/{release_id}'))
            need(release['id'] == release_id, 'Candidate release id changed')
            return release
        def remember(release):
            if release is not None:
                owned_release(release)
                self._release_id = release['id']
            return release
        try: return remember(self.api(f'repos/{REPOSITORY}/releases/tags/{RELEASE_TAG}'))
        except GhError as error:
            if error.status != 404: raise
        # An untagged draft is deliberately invisible to the by-tag endpoint.
        # Authenticated list-releases includes drafts for this CI write token.
        # Complete a bounded scan before trusting absence or uniqueness; never
        # choose the first of ambiguous same-tag drafts or a published release.
        matches = []
        for page in range(1, MAX_RELEASE_PAGES + 1):
            rows = self.api(f'repos/{REPOSITORY}/releases?per_page=100&page={page}')
            need(isinstance(rows, list) and len(rows) <= 100, 'Invalid release-list response')
            need(all(isinstance(row, dict) for row in rows), 'Invalid release-list entry')
            matches.extend(row for row in rows if row.get('tag_name') == RELEASE_TAG)
            need(len(matches) <= 1, 'Ambiguous duplicate candidate releases')
            if len(rows) < 100:
                return remember(matches[0] if matches else None)
        raise ValueError('Release-list scan limit reached; refusing an incomplete candidate lookup')

    def require_uncreated_tag(self):
        # A private release draft normally has no Git tag yet. Never move or
        # overwrite a preexisting ref, even if its name matches this task.
        try:
            self.run(['api', f'repos/{REPOSITORY}/git/ref/tags/{RELEASE_TAG}', '--method', 'GET'], json_result=True)
        except GhError as error:
            if error.status == 404: return
            raise
        raise ValueError('An existing Git tag is refused; this draft-only workflow never moves tags')

    def assets(self, release):
        pages = self.api(f'repos/{REPOSITORY}/releases/{release["id"]}/assets?per_page=100', paginate=True)
        rows = [item for page in pages for item in page]
        need(len({x['name'] for x in rows}) == len(rows), 'Duplicate server attachment names')
        return {x['name']: x for x in rows}

    def delete_asset(self, release, asset):
        need(type(asset['id']) is int and asset['id'] > 0, 'Invalid attachment id')
        self.api(f'repos/{REPOSITORY}/releases/assets/{asset["id"]}', method='DELETE')

    def upload(self, path):
        # Bind binary transfer to the validated draft ID, independently of Git
        # tag resolution. Do not trust an arbitrary upload_url supplied by JSON.
        release = owned_release(self.release())
        path = regular_file(path)
        name = safe_name(path.name)
        return self.run(['api', f'https://uploads.github.com/repos/{REPOSITORY}/releases/{release["id"]}/assets?name={name}',
                         '--method', 'POST', '-H', 'Accept: application/vnd.github+json',
                         '-H', 'Content-Type: application/octet-stream',
                         '-H', f'Content-Length: {path.stat().st_size}', '--input', str(path)], json_result=True)

    def download_metadata(self, asset, directory):
        need(asset['state'] == 'uploaded' and 0 < asset['size'] <= MAX_METADATA, 'Small uploaded metadata required')
        need(asset['browser_download_url'] == RELEASE_BASE + safe_name(asset['name']), 'Wrong metadata download release')
        need(type(asset.get('id')) is int and asset['id'] > 0, 'Invalid metadata asset id')
        release = owned_release(self.release())
        current = self.assets(release).get(asset['name'])
        need(current == asset, 'Metadata asset is no longer attached to the fixed candidate draft')
        path = Path(directory)/asset['name']
        created = False
        try:
            with path.open('xb') as output:
                created = True
                self.run(['api', f'repos/{REPOSITORY}/releases/assets/{asset["id"]}', '--method', 'GET',
                          '-H', 'Accept: application/octet-stream'], output=output)
            need(path.stat().st_size <= MAX_METADATA, 'Downloaded metadata exceeds its bound')
            path = regular_file(path)
            expected = record(path)
            need(server_match(asset, expected), 'Downloaded metadata differs from GitHub server digest')
            return path
        except BaseException:
            # Only remove this call's fresh partial file. Exclusive-open errors
            # preserve all preexisting files, including symlinks.
            if created: path.unlink(missing_ok=True)
            raise


def ensure_asset(api, path, expected, *, os_id=None):
    validate_record(expected, os_id)
    if os_id is None: need(expected['name'] in GLOBAL_NAMES, 'Unowned global filename')
    need(record(path) == expected, 'Local attachment changed before upload')
    release = owned_release(api.release())
    assets = api.assets(release)
    old = assets.get(expected['name'])
    if old and server_match(old, expected): return 'exact-existing'
    if old:
        # Only an exact same owned filename in this exact still-private draft.
        # Unrelated assets and all other releases are never deleted.
        fresh = owned_release(api.release())
        need(fresh['id'] == release['id'], 'Candidate release changed before replacement')
        api.delete_asset(fresh, old)
    # upload() independently refreshes private ownership immediately before the
    # ID-bound POST. Its response already contains GitHub's measured digest;
    # use that instead of unconditionally doing another GET + asset-list round.
    uploaded = api.upload(path)
    need(isinstance(uploaded, dict), 'Invalid asset upload response')
    if server_match(uploaded, expected): return 'uploaded-and-server-verified'
    for attempt in range(8):
        current = api.assets(owned_release(api.release())).get(expected['name'])
        if current and server_match(current, expected): return 'uploaded-and-server-verified'
        if attempt < 7: time.sleep(3)
    raise RuntimeError('GitHub did not confirm exact uploaded SHA256: ' + expected['name'])


def candidate_body(names=None):
    text = ('# HackberryPi CM5 native PINN multiboot candidate\n\n'
            'This private draft combines eight newly converted PINN packages with four existing native packages. '
            'Each installer writes only PINN-allocated partitions; whole-disk image files are not PINN tarballs.\n\n'
            '**Physical PINN installation and multiboot have not yet been boot-tested.** '
            'Standalone owner acceptance and offline conversion checks are recorded separately. '
            'Only HackberryPi Compute Module 5 SD-card installation is advertised; USB boot/root and new raw-package backup restoration are not claimed.\n')
    if names: text += '\nSystems: ' + ', '.join(names) + '.\n\nThe complete checksums, measured conversion proofs and adapter sources are attached.\n'
    return BEGIN + '\n' + text + END


def update_owned_draft(api, release, *, name=None, body=None):
    """Preserve the pending tag explicitly, then verify the stored draft by ID.

    GitHub's draft PATCH can replace an omitted pending tag with a synthetic
    untagged-* value. Never depend on partial-update defaults or its response
    representation for the identity of the existing private candidate.
    """
    owned_release(release)
    release_id = release['id']
    updated_body = release['body'] if body is None else body
    need(isinstance(updated_body,str) and BEGIN in updated_body and END in updated_body,
         'Updated draft must preserve this workflow ownership marker')
    api.api(f'repos/{REPOSITORY}/releases/{release_id}', method='PATCH', body={
        'tag_name': RELEASE_TAG, 'target_commitish': os.environ['GITHUB_SHA'],
        'name': (release.get('name') or TITLE) if name is None else name,
        'body': updated_body,
        'draft': True, 'prerelease': True})
    stored = owned_release(api.api(f'repos/{REPOSITORY}/releases/{release_id}'))
    need(stored['id'] == release_id, 'Updated draft numeric identity differs')
    need(stored.get('target_commitish') == os.environ['GITHUB_SHA'], 'Updated draft target differs from adapter source commit')
    return stored


def prepare(api):
    api.require_uncreated_tag()
    release = api.release()
    if release is None:
        release = api.api(f'repos/{REPOSITORY}/releases', method='POST', body={
            'tag_name': RELEASE_TAG, 'target_commitish': os.environ['GITHUB_SHA'],
            'name': TITLE, 'body': candidate_body(), 'draft': True, 'prerelease': True})
    owned_release(release)
    if release.get('target_commitish') != os.environ['GITHUB_SHA']:
        # This updates only an untagged private draft's future target. The GET
        # above proved there is no ref to force or alter.
        release = update_owned_draft(api, release)
    need(release.get('target_commitish') == os.environ['GITHUB_SHA'], 'Prepared draft target differs from adapter source commit')
    return {'passed': True, 'draft': True, 'release_id': release['id'], 'tag': RELEASE_TAG}


def upload_os(api, os_id, output_dir=None):
    need(os_id in OS_IDS, 'Unknown OS id')
    directory = WORK_ROOT/os_id/'out'
    need(output_dir is None or Path(output_dir).resolve() == directory, 'Output override must be the fixed OS CI directory')
    need(directory.resolve() == directory and directory.is_dir() and not directory.is_symlink(), 'Wrong CI output directory')
    manifest = regular_file(directory/(os_id+'-PINN-package.json'))
    need(manifest.stat().st_size <= MAX_METADATA, 'Oversized package metadata')
    package = json.loads(manifest.read_text())
    source = json.loads((BASE/'ci/sources'/(os_id+'.json')).read_text())
    assets = validate_package(package, os_id, source, os.environ['GITHUB_SHA'])
    validate_native_metadata(json.loads((directory/(os_id+'-os.json')).read_text()),
                             json.loads((directory/(os_id+'-partitions.json')).read_text()),package,assets)
    expected = {**assets, manifest.name: record(manifest)}
    actual = {p.name for p in directory.iterdir()}
    need(actual == expected.keys(), 'CI output contains unlisted files/directories')
    for name, row in expected.items(): need(record(directory/name) == row, 'Local output checksum differs: '+name)
    statuses = {name: ensure_asset(api, directory/name, row, os_id=os_id) for name,row in expected.items()}
    fresh = owned_release(api.release()); server = api.assets(fresh)
    for name,row in expected.items():
        need(name in server and server_match(server[name],row), 'Final OS server verification differs: '+name)
    return {'passed': True, 'os_id': os_id, 'assets': statuses, 'draft_only': True}


def render_legacy_wrapper(os_id, original, expected_sha):
    need(os_id in LEGACY and hashlib.sha256(original).hexdigest() == expected_sha, 'Legacy original adapter differs')
    header = '#!/bin/sh\n'
    if b'#supports_backup' in original: header += '#supports_backup in PINN\n'
    encoded = base64.b64encode(original).decode()
    return (header + 'set -eu\numask 022\n'
        + 'temporary=$(mktemp /tmp/hbpinn-legacy.XXXXXX)\n'
        + "trap 'rm -f \"$temporary\"' EXIT HUP INT TERM\n"
        + "printf '%s' '" + encoded + "' | base64 -d > \"$temporary\"\n"
        + 'got=$(sha256sum "$temporary"); [ "${got%% *}" = '+expected_sha+' ] || exit 41\n'
        # Pass the wrapper path as child $0 so original package_dir remains valid.
        + '/bin/sh -c "$(cat "$temporary")" "$0"\n'
        + 'boot=${PINN_BOOT_MOUNT:-$(pwd -P)}\n'
        + 'list=$(mktemp /tmp/hbpinn-legacy-cmdlines.XXXXXX)\n'
        + "trap 'rm -f \"$temporary\" \"$list\"' EXIT HUP INT TERM\n"
        + 'find "$boot" -type f -name cmdline.txt > "$list"\n[ -s "$list" ] || exit 42\n'
        + 'while IFS= read -r file; do\n'
        + ' [ -f "$file" ] && [ ! -L "$file" ] || exit 43\n'
        + ' staged=$(mktemp "$file.pinn.XXXXXX")\n'
        + " awk 'BEGIN{roots=0;minors=0;lines=0;out=\"\"} NF{lines++;for(i=1;i<=NF;i++){token=$i;if(token~/^root=/)roots++;if(token~/^mmcblk.perdev_minors=/){token=\"mmcblk.perdev_minors=64\";minors++}out=out (out==\"\"?\"\":\" \") token}} END{if(lines!=1||roots!=1||minors>1)exit 44;if(!minors)out=out \" mmcblk.perdev_minors=64\";print out}' \"$file\" > \"$staged\" || { rm -f \"$staged\"; exit 44; }\n"
        + ' cat "$staged" > "$file"; rm -f "$staged"\ndone < "$list"\nsync\n').encode()


def build_legacy(directory):
    snapshot = BASE/'public-snapshot'
    baseline = json.loads((snapshot/'os_list_v3.json').read_text())['os_list']
    pins = json.loads((BASE/'ci/legacy-pins.json').read_text())
    entries, files = {}, {}
    for os_id, folder in LEGACY.items():
        old = next(x for x in baseline if '/'+folder+'/os.json' in x['os_info'])
        original = regular_file(snapshot/folder/'partition_setup.sh').read_bytes()
        online = any(row['url'] not in pins[os_id]['tarballs'] for row in pins[os_id]['payload_assets'])
        wrapper = directory/(os_id+'-legacy-partition_setup.sh')
        wrapper.write_bytes(render_legacy_wrapper(os_id, original, pins[os_id]['setup_sha256']))
        info_bytes = (snapshot/folder/'os.json').read_bytes()
        need(hashlib.sha256(info_bytes).hexdigest() == pins[os_id]['os_sha256'], 'Legacy OS metadata differs')
        info = json.loads(info_bytes)
        info.update(supported_models=['Compute Module 5'], supports_usb_boot=False, supports_usb_root=False,
                    sha256sum=hashlib.sha256(wrapper.read_bytes()).hexdigest(), online_install_only=online)
        info_path = directory/(os_id+'-legacy-os.json')
        info_path.write_text(json.dumps(info, indent=2)+'\n')
        part_path = directory/(os_id+'-legacy-partitions.json')
        data = (snapshot/folder/'partitions.json').read_bytes()
        need(hashlib.sha256(data).hexdigest() == pins[os_id]['partitions_sha256'], 'Legacy partitions differ')
        part_path.write_bytes(data)
        entry = dict(old, supported_models=['Compute Module 5'], supports_usb_boot=False, supports_usb_root=False,
                     online_install_only=online,
                     os_info=RELEASE_BASE+info_path.name, partitions_info=RELEASE_BASE+part_path.name,
                     partition_setup=RELEASE_BASE+wrapper.name)
        need(entry['tarballs'] == pins[os_id]['tarballs'], 'Legacy archive URLs changed')
        entries[os_id] = entry
        for path in (wrapper,info_path,part_path): files[path.name] = record(path)
    return entries, files


def make_archive(path, members):
    need(not path.exists(), 'Fresh source archive required')
    with tarfile.open(path, 'w:xz', preset=3) as archive:
        for name, source in sorted(members.items()):
            need(not name.startswith('/') and '..' not in Path(name).parts, 'Unsafe source archive path')
            data = regular_file(source).read_bytes()
            info = tarfile.TarInfo(name); info.size=len(data); info.uid=info.gid=0; info.mtime=0
            info.mode=0o755 if source.suffix in ('.py','.sh') else 0o644
            archive.addfile(info,io.BytesIO(data))


def source_members():
    result = {}
    for folder in ('ci','linux-adapters','android-fydeos-research'):
        for path in (BASE/folder).rglob('*'):
            if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts: continue
            if path.suffix not in ('.py','.sh','.json','.txt','.dts','.public','.init'): continue
            need(path.stat().st_size <= MAX_METADATA, 'Unexpected large adapter source file')
            result[path.relative_to(BASE).as_posix()] = path
    need(result, 'Adapter source archive cannot be empty')
    return result


def finalize(api):
    release = owned_release(api.release()); server = api.assets(release)
    need(release.get('target_commitish')==os.environ['GITHUB_SHA'], 'Draft target differs from adapter source commit')
    directory = Path(tempfile.mkdtemp(prefix='hackberrypi-pinn-finalize-', dir=os.environ.get('RUNNER_TEMP')))
    packages, expected = {}, {}
    for os_id in OS_IDS:
        name = os_id+'-PINN-package.json'
        need(name in server, 'Missing OS conversion metadata: '+name)
        path = api.download_metadata(server[name], directory)
        package = json.loads(path.read_text())
        source = json.loads((BASE/'ci/sources'/(os_id+'.json')).read_text())
        records = validate_package(package,os_id,source,os.environ['GITHUB_SHA'])
        records[name] = record(path)
        for key,row in records.items(): need(key in server and server_match(server[key],row),'Unverified server attachment: '+key)
        info_path=api.download_metadata(server[os_id+'-os.json'],directory)
        parts_path=api.download_metadata(server[os_id+'-partitions.json'],directory)
        validate_native_metadata(json.loads(info_path.read_text()),json.loads(parts_path.read_text()),package,records)
        expected.update(records); packages[os_id]=package
    legacy, generated = build_legacy(directory)
    entries = {**legacy, **{key:value['feed_entry'] for key,value in packages.items()}}
    need(set(entries) == set(ORDER) and len({x['os_name'] for x in entries.values()}) == 12, 'Incomplete/duplicate combined OS catalog')
    feed = {'os_list':[entries[key] for key in ORDER]}
    (directory/'os_list_v3.json').write_text(json.dumps(feed,indent=2)+'\n')
    (directory/'repo_list.json').write_text(json.dumps({'repo_list':[{'name':'HackberryPi CM5 PINN Multiboot',
        'url':RELEASE_BASE+'os_list_v3.json'}]},indent=2)+'\n')
    sources={'schema':1,'repository':REPOSITORY,'release_tag':RELEASE_TAG,
             'adapter_commit':os.environ['GITHUB_SHA'],'new_sources':{key:value['source'] for key,value in packages.items()},
             'legacy_sources':json.loads((BASE/'ci/legacy-pins.json').read_text()),
             'upstream_licenses_and_kernel_sources':'Retained in each referenced original public OS source release; no kernel binary is rebuilt by this conversion.'}
    (directory/'PINN-MULTIBOOT-SOURCES.json').write_text(json.dumps(sources,indent=2)+'\n')
    make_archive(directory/SOURCE_ARCHIVE,source_members())
    evidence={path.name:path for path in directory.glob('*.json')}
    for path in (BASE/'public-snapshot').rglob('*'):
        if path.is_file() and not path.is_symlink(): evidence['public-snapshot/'+path.relative_to(BASE/'public-snapshot').as_posix()]=path
    evidence['PINN-MULTIBOOT-SOURCES.json']=directory/'PINN-MULTIBOOT-SOURCES.json'
    make_archive(directory/EVIDENCE_ARCHIVE,evidence)
    verification={'schema':1,'passed_offline_and_server_metadata_checks':True,'candidate_draft_only':True,
        'repository':REPOSITORY,'tag':RELEASE_TAG,'adapter_commit':os.environ['GITHUB_SHA'],
        'systems':list(ORDER),'new_converted_packages':list(OS_IDS),'legacy_tarball_urls_preserved':True,
        'all_required_payload_assets_uploaded_and_server_sha256_verified':sorted(expected),
        'source_image_identity_references_verified':True,'whole_disk_images_advertised_as_pinn_tarballs':False,
        'supported_models':['Compute Module 5'],'supports_usb_boot':False,'supports_usb_root':False,
        'physical_pinn_installation_boot_tested':False,'physical_multiboot_tested':False,
        'kernel_binaries_rebuilt':False,'completed_unix':time.time()}
    (directory/'PINN-MULTIBOOT-VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
    for name in GLOBAL_NAMES-{'SHA256SUMS'}:
        path=directory/name;need(path.is_file(),'Missing generated global artifact: '+name);generated[name]=record(path)
    checksum_rows={**expected,**generated}
    (directory/'SHA256SUMS').write_text(''.join(row['sha256']+'  '+name+'\n' for name,row in sorted(checksum_rows.items())))
    generated['SHA256SUMS']=record(directory/'SHA256SUMS')
    for name,row in generated.items(): ensure_asset(api,directory/name,row)
    fresh=owned_release(api.release());all_server=api.assets(fresh)
    for name,row in {**expected,**generated}.items(): need(name in all_server and server_match(all_server[name],row),'Final candidate server verification differs: '+name)
    body=fresh['body'];start=body.index(BEGIN);end=body.index(END,start)+len(END)
    body=body[:start]+candidate_body([entries[key]['os_name'] for key in ORDER])+body[end:]
    need(fresh.get('target_commitish') == os.environ['GITHUB_SHA'], 'Draft target changed during final verification')
    update_owned_draft(api, fresh, name=TITLE, body=body)
    result={'passed':True,'draft_only':True,'release_id':fresh['id'],'tag':RELEASE_TAG,
            'systems':12,'required_assets':len(expected)+len(generated),'finalize_directory':str(directory),
            'published':False,'main_branch_changed':False,'physical_multiboot_tested':False}
    (directory/'candidate-finalize-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','upload','finalize'))
    parser.add_argument('os_id',nargs='?')
    parser.add_argument('--os-id',dest='os_id_flag')
    parser.add_argument('--output-dir',type=Path)
    args=parser.parse_args();ci_guard();api=GitHub()
    if args.mode=='prepare':
        need(args.os_id is None and args.os_id_flag is None and args.output_dir is None,'Unexpected OS/output argument');result=prepare(api)
    elif args.mode=='upload':
        need(not(args.os_id and args.os_id_flag),'Specify only one OS argument')
        result=upload_os(api,args.os_id_flag or args.os_id,args.output_dir)
    else:
        need(args.os_id is None and args.os_id_flag is None and args.output_dir is None,'Unexpected OS/output argument');result=finalize(api)
    if os.environ.get('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'],'a') as output:
            output.write('release_tag='+RELEASE_TAG+'\n')
            if 'finalize_directory' in result: output.write('finalize_directory='+result['finalize_directory']+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__': main()
