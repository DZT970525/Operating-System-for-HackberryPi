# Operating Systems for HackberryPi

Customized ARM64 systems for **HackberryPi CM5**, with separate download sources for **PINN** and **Raspberry Pi Imager**.

| System | Documentation | Default login |
| --- | --- | --- |
| Twister OS 3.1.0 Xfce for HackberryPi | [Twister OS](TwisterOS/README.md) · [Imager](Imager/TwisterOS.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| LineageOS 24.0 / Android 17 for HackberryPi | [LineageOS](LineageOS/README.md) · [Imager](Imager/LineageOS.md) | Android first-run setup; choose your own optional screen lock |
| RPiOS — Raspberry Pi OS for HackberryPi | [RPiOS](RPiOS/README.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| Ubuntu 24.04.5 LTS GNOME for HackberryPi | [Ubuntu](Ubuntu/README.md) · [Imager](Imager/Ubuntu.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| Kali Linux 2026.3 for HackberryPi | [PINN](Kali/README.md) · [Imager](Imager/Kali.md) | Username `kali`, password `kali` — both lowercase; use `sudo` for administrator commands |
| Fyde OS for HackBerry Pi (FydeOS 23.0) | [PINN](FydeOS/README.md) · [Imager](Imager/FydeOS.md) | Native first-run setup with your own account and any required vendor license |
| Omarchy 4.5.0 for HackberryPi | [Omarchy](Omarchy/README.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| Manjaro ARM Xfce for HackberryPi | [Manjaro](Manjaro/README.md) · [Imager](Imager/Manjaro.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| Fedora Remix 45 Xfce for HackberryPi | [Fedora](Fedora/README.md) · [Imager](Imager/Fedora.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| Arch Linux ARM Xfce for HackberryPi | [Arch](Arch/README.md) · [Imager](Imager/Arch.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| DietPi Xfce for HackberryPi | [DietPi](DietPi/README.md) · [Imager](Imager/DietPi.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |
| Buildroot Openbox for HackberryPi | [Buildroot](Buildroot/README.md) · [Imager](Imager/Buildroot.md) | Username `pi`, password `pi` — both lowercase; use `sudo` for administrator commands |

Change the Twister OS, RPiOS, Ubuntu, Kali, Omarchy, Manjaro, Fedora Remix, Arch Linux ARM, DietPi or Buildroot default password after first login. Saved application logins, network credentials and personal histories are excluded from the published copies.

## PINN download source

Use a PINN build with CM5 and HackberryPi display support. Add this to the existing single line in `recovery.cmdline`:

```
alt_image_source=https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_v3.json
```

The five existing PINN systems appear in **General**. Twister OS, LineageOS, Ubuntu, Fedora Remix, Arch Linux ARM, DietPi and Buildroot are provided separately as standalone Raspberry Pi Imager images; they are not in the PINN feed. The old Ubuntu PINN preview has been withdrawn; `Ubuntu/os_list_v3.json` remains a valid empty catalog. Use the root combined feed above for the other PINN systems. `repo_list.json` points to the combined catalog.

Packages and checksums are under [Releases](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases). Read each system's installation notes before downloading. PINN packages contain filesystem archives and supplemental application archives. Read each release's notes for standalone image availability; PINN filesystem archives cannot be flashed as a whole disk image. Keep the network connected throughout online installation.

The customized Kali and sanitized Omarchy standalone systems have been boot-tested by the owner. The installed Manjaro configuration and repaired networking have also been tested and accepted by the owner; its factory-image validation status is recorded in the Manjaro release notes. All five PINN packages remain previews until installation and multiboot have been tested through PINN on the device. Kali needs at least 20.5 GiB and Omarchy at least **16.25 GiB**, plus PINN and other systems. Fyde OS needs at least 12.2 GiB and supports SD installation only. Its four-partition PINN edition disables native whole-disk OTA and Powerwash; reset or upgrade by reinstalling through PINN. Read the RPiOS notes for its minimum storage allocation of **8.5 GiB** and the Omarchy notes for its Btrfs setup requirements. Manjaro needs at least **8704 MiB**; see its [PINN notes](Manjaro/README.md).

## Raspberry Pi Imager download source

Install one system directly on an SD card with [Raspberry Pi Imager](https://www.raspberrypi.com/software/). The two methods below produce or download a **complete disk image**, including its partition layout.

| System | Download method | Installation notes |
| --- | --- | --- |
| Twister OS 3.1.0 Xfce for HackberryPi | Automatic download-and-merge tool: [Download helper ZIP](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/twisteros-displayscale-hackberrypi-2026-11-16/TwisterOS-Imager-Download-Tools-20261116.zip) | [Twister OS](Imager/TwisterOS.md) |
| LineageOS 24.0 / Android 17 for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/lineageos-displayscale-hackberrypi-2026-11-16/LineageOS-24.0-Android17-HackberryPi-CM5-DisplayScale-Neofetch-20261116.img.xz) | [LineageOS](Imager/LineageOS.md) |
| RPiOS — Raspberry Pi OS for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/rpios-hackberrypi-2026-11-09/RPiOS-HackberryPi-CM5-20261109.img.xz) | [RPiOS](RPiOS/README.md) |
| Ubuntu 24.04.5 LTS GNOME for HackberryPi | Automatic download-and-merge tool: [Download helper ZIP](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/ubuntu-displayscale-hackberrypi-2026-11-13/Ubuntu-Imager-Download-Tools-20261113.zip) | [Ubuntu](Imager/Ubuntu.md) |
| Kali Linux 2026.3 for HackberryPi | Automatic download-and-merge tool: [Download helper ZIP](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/kali-displayscale-hackberrypi-2026-11-10/Kali-Imager-Download-Tools-20261110.zip) | [Kali](Imager/Kali.md) |
| FydeOS 23.0 for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/fydeos-imager-hackberrypi-2026-11-10/FydeOS-23.0-HackberryPi-CM5-DisplayScale-20261110.img.xz) | [FydeOS](Imager/FydeOS.md) |
| Omarchy 4.5.0 for HackberryPi | Automatic download-and-merge tool ZIP: [Download helper ZIP](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/omarchy-imager-hackberrypi-2026-11-09/Omarchy-Imager-Download-Tools-20261109.zip) | [Omarchy](Imager/Omarchy.md) |
| Manjaro ARM Xfce for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/manjaro-displayscale-hackberrypi-2026-11-10/Manjaro-ARM-Xfce-HackberryPi-CM5-DisplayScale-20261110.img.xz) | [Manjaro](Imager/Manjaro.md) |
| Fedora Remix 45 Xfce for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/fedora-displayscale-hackberrypi-2026-11-11/Fedora-45-Xfce-HackberryPi-CM5-DisplayScale-20261111.img.xz) | [Fedora](Imager/Fedora.md) |
| Arch Linux ARM Xfce for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/archlinux-displayscale-hackberrypi-2026-11-12/ArchLinux-ARM-Xfce-HackberryPi-CM5-DisplayScale-Neofetch-20261112.img.xz) | [Arch](Imager/Arch.md) |
| DietPi Xfce for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/dietpi-displayscale-hackberrypi-2026-11-13/DietPi-Trixie-Xfce-HackberryPi-CM5-DisplayScale-Neofetch-20261113.img.xz) | [DietPi](Imager/DietPi.md) |
| Buildroot Openbox for HackberryPi | [Imager online catalog](https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json) or [complete `.img.xz`](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/buildroot-displayscale-hackberrypi-2026-11-15/Buildroot-2026.08.1-Openbox-HackberryPi-CM5-DisplayScale-Neofetch-20261115.img.xz) | [Buildroot](Imager/Buildroot.md) |

**The online catalog contains LineageOS, RPiOS, FydeOS, Manjaro, Fedora Remix, Arch Linux ARM, DietPi and Buildroot.** Twister OS, Ubuntu, Kali and Omarchy use their download-and-merge helpers followed by **Use custom**; they are not online JSON entries.

### Twister OS: automatic download and merge

Use the [automatic download-and-merge helper ZIP](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/twisteros-displayscale-hackberrypi-2026-11-16/TwisterOS-Imager-Download-Tools-20261116.zip) to download **16 parts**, verify them and create the complete **`TwisterOS-3.1.0-Xfce-HackberryPi-CM5-DisplayScale-Neofetch-20261116.img.xz`**. Then select that file through **Use custom** in Raspberry Pi Imager. Windows, macOS and Linux launchers are included; interrupted downloads can resume. Manual decompression and manual merge commands are not needed.

Log in with **pi / pi**. The default workspace is **900 × 900**, with the English **Display Scale (480–1080)** app on the native **720 × 720** panel. Screen/touch, USB Host, MAX17048 battery, Neofetch and native Wi-Fi/Bluetooth/volume controls are included. All 15 theme choices now set the DPI screen's matching wallpaper. Read the [installation guide](Imager/TwisterOS.md). This is a standalone release.

### LineageOS: online download or complete image

Choose **LineageOS 24.0 / Android 17 for HackberryPi** in the Imager catalog, or [download the complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/lineageos-displayscale-hackberrypi-2026-11-16/LineageOS-24.0-Android17-HackberryPi-CM5-DisplayScale-Neofetch-20261116.img.xz) and select it with **Use custom**. Use an **8 GB or larger SD card** and wait for writing and verification; no manual decompression or merge is needed.

Complete Android’s own setup wizard; no Linux `pi / pi` login is configured. The default logical workspace is **900 × 900**, with the English **Display Scale (480–1080)** app on the native **720 × 720** panel. Screen/touch, USB 2.0 Host, MAX17048 battery capacity, top Quick Settings Wi-Fi/Bluetooth/Volume, official Firefox and genuine Neofetch in Termux are included. The configured source was owner-tested; the sanitized factory image awaits a separate physical first-run test. This is an **unofficial noncommercial** adaptation of [KonstaKANG’s LineageOS build](https://konstakang.com/devices/rpi5/LineageOS24/), with component-specific licenses and matching sources retained. Read the [installation guide](Imager/LineageOS.md) for first-start preparation, compact storage, browser updates and validation. This release is standalone only.

### LineageOS, RPiOS, FydeOS, Manjaro, Fedora Remix, Arch Linux ARM, DietPi and Buildroot: online download in Imager

1. Open Raspberry Pi Imager and choose **App Options → Content Repository → Edit**.
2. Select **Use custom URL** and paste:

   ```
   https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_imager.json
   ```

3. Choose **Apply & Restart**.
4. Select **HackberryPi CM5**, choose **RPiOS**, **FydeOS**, **Manjaro ARM Xfce**, **Fedora Remix 45 Xfce for HackberryPi**, **Arch Linux ARM Xfce for HackberryPi**, **DietPi Xfce for HackberryPi** or **Buildroot Openbox for HackberryPi**, and select your SD card. Continue writing and verification; Imager downloads the complete image automatically.

Alternatively, download a complete compressed image from the table and select it with **Use custom** in Imager. Read the [FydeOS installation notes](Imager/FydeOS.md) for its first-run setup and Display Scale controls.

### Ubuntu: automatic download and merge

Use the [download helper ZIP](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/ubuntu-displayscale-hackberrypi-2026-11-13/Ubuntu-Imager-Download-Tools-20261113.zip) to fetch and automatically merge **6 parts**, then choose the completed **`Ubuntu-24.04.5-GNOME-HackberryPi-CM5-DisplayScale-Neofetch-20261113.img.xz`** through **Use custom** in Raspberry Pi Imager. Windows, macOS and Linux launchers are included; interrupted downloads can resume. Use a computer folder with **at least 7 GB free** and a **16 GB or larger SD card**. Read the [step-by-step guide](Imager/Ubuntu.md).

Log in with **pi / pi**. Native GNOME 46 Wayland, default **900 × 900** workspace, English **Display Scale (480–1080)**, the native **720 × 720** panel/touch, MAX17048 battery, USB 2.0 Host and Neofetch 7.1.0 are retained. The existing top-right menu includes **Wi-Fi Settings** and **Bluetooth Settings**. Automatic idle screen transitions are disabled; manual locking remains available. This standalone release replaces the old Ubuntu PINN preview; Ubuntu is not added to the online JSON catalog.

### Manjaro: online download or complete image

Choose **Manjaro ARM Xfce for HackberryPi** in the Imager catalog, or [download the complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/manjaro-displayscale-hackberrypi-2026-11-10/Manjaro-ARM-Xfce-HackberryPi-CM5-DisplayScale-20261110.img.xz) and select it with **Use custom**. Use a **16 GB or larger SD card** and let writing and verification finish.

Log in with **pi / pi**. The default workspace is **900 × 900**; the English **Display Scale** desktop app provides **480–1080** scaling on the native **720 × 720** screen. Automatic screensaver, blanking, DPMS, idle dimming and idle suspend are disabled by default on AC and battery; manual locking and login authentication remain available. Read the [Manjaro installation guide](Imager/Manjaro.md) for first-boot package-trust initialization, tested hardware, network setup and upstream software notes.

### Fedora Remix: online download or complete image

Choose **Fedora Remix 45 Xfce for HackberryPi** in the Imager catalog, or [download the complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/fedora-displayscale-hackberrypi-2026-11-11/Fedora-45-Xfce-HackberryPi-CM5-DisplayScale-20261111.img.xz) and select it with **Use custom**. Use a **16 GB or larger SD card** and wait for writing and verification.

Log in with **pi / pi**. The default workspace is **900 × 900** with an English **Display Scale** app for **480–1080** on the native **720 × 720** panel. Touch, MAX17048 battery support, Bluetooth controls and screen-idle defaults are included; SELinux remains enforcing. This is a community **Fedora Remix** with modified Fedora software; unmodified Fedora is available from [the Fedora Project](https://fedoraproject.org/). Read the [installation guide](Imager/Fedora.md), including the final-image validation status and hardware-kernel maintenance notes. Fedora is standalone only in this release.

### Arch Linux ARM: online download or complete image

Choose **Arch Linux ARM Xfce for HackberryPi** in the Imager catalog, or [download the complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/archlinux-displayscale-hackberrypi-2026-11-12/ArchLinux-ARM-Xfce-HackberryPi-CM5-DisplayScale-Neofetch-20261112.img.xz) and select it with **Use custom**. Use a **16 GB or larger SD card** and wait for writing and verification; no manual merge or decompression is needed.

Log in with **pi / pi**. The default workspace is **900 × 900** with the English **Display Scale** desktop app for **480–1080** on the native **720 × 720** panel. Screen/touch, MAX17048 battery support, Wi-Fi/Bluetooth controls and original **Neofetch 7.1.0** are included. Automatic idle display transitions are disabled; manual locking remains available. This is the Arch Linux ARM community distribution with native CM5 integration. The configured source was accepted for publication; its physical boot was not independently confirmed during preparation. Read the [installation guide](Imager/Arch.md), including first-start preparation and the final-image validation status. Arch is standalone only in this release; the final sanitized image awaits separate physical first-boot testing.

### DietPi: online download or complete image

Choose **DietPi Xfce for HackberryPi** in the Imager catalog, or [download the complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/dietpi-displayscale-hackberrypi-2026-11-13/DietPi-Trixie-Xfce-HackberryPi-CM5-DisplayScale-Neofetch-20261113.img.xz) and select it with **Use custom**. Use a **16 GB or larger SD card** and wait for writing and verification; manual decompression and merging are not needed.

Log in with **pi / pi**. DietPi v10.8.2 / Debian 13 Trixie comes with **Xfce/X11 preinstalled**, default **900 × 900** workspace, English **Display Scale (480–1080)**, native **720 × 720** display/touch, USB 2.0 Host, MAX17048 battery and genuine Neofetch 7.1.0. The top-right panel provides Wi-Fi, Bluetooth and volume controls. Automatic idle display transitions are disabled; manual locking remains available. Read the [installation guide](Imager/DietPi.md), including privacy and final-image validation status. This DietPi release is standalone only; the existing PINN feed is unchanged.

### Buildroot: online download or complete image

Choose **Buildroot Openbox for HackberryPi** in the Imager catalog, or [download the complete image](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/buildroot-displayscale-hackberrypi-2026-11-15/Buildroot-2026.08.1-Openbox-HackberryPi-CM5-DisplayScale-Neofetch-20261115.img.xz) and select it with **Use custom**. Use a **16 GB or larger SD card** and wait for writing and verification; manual decompression and merging are not needed.

Log in with **pi / pi**. The preinstalled Openbox/X11 desktop provides a default **900 × 900** workspace, English **Display Scale (480–1080)** launcher at the desktop's bottom-right, screen/touch, MAX17048 battery, USB 2.0 Host and genuine Neofetch 7.1.0. The top-right shell offers Wi-Fi, Bluetooth and sound entry points. This is Buildroot 2026.08.1 userspace with the matching Raspberry Pi/Armbian 6.18.44 BSP; it has no distribution package manager. The owner accepted the configured source; the repackaged sanitized image awaits separate physical first-boot testing. Read the [installation guide](Imager/Buildroot.md), including validation and maintenance notes. Buildroot is standalone only in this release.

### Kali: automatic download and merge

1. [Download **Kali-Imager-Download-Tools-20261110.zip**](https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/kali-displayscale-hackberrypi-2026-11-10/Kali-Imager-Download-Tools-20261110.zip) and extract it into a computer folder with **at least 11 GB free**. The disk must support files larger than 4 GB.
2. Run the launcher in that extracted folder:
   - Windows: double-click `download-kali.cmd`.
   - macOS: open `download-kali.command`.
   - Linux: run `sh ./download-kali.sh`.
3. Wait for all **37 parts** to download, pass their SHA-256 checks, and merge. Interrupted downloads can resume by running the same launcher again.
4. Open [Raspberry Pi Imager](https://www.raspberrypi.com/software/), choose **Use custom**, and select the completed file directly:

   ```
   Kali-2026.3-HackberryPi-CM5-DisplayScale-20261110.img.xz
   ```

5. Select the intended **32 GB or larger SD card**, confirm writing, and let verification finish. Manual decompression is not needed. Insert the card in HackberryPi CM5 and boot.

Log in with **kali / kali**. The default workspace is **900 × 900**; open **Display Scale** on the desktop to choose **480–1080**. Read the [Kali installation notes](Imager/Kali.md).

### Omarchy: automatic download and merge

1. Download and extract **Omarchy-Imager-Download-Tools-20261109.zip** into a computer folder with **about 11 GB of free working space**. The disk must support files larger than 4 GB.
2. Run the launcher for your computer as a normal user; the download helper needs no administrator rights:
   - Windows: double-click `download-omarchy.cmd`.
   - macOS: open `download-omarchy.command`.
   - Linux: run `sh ./download-omarchy.sh` from that extracted folder.
3. Let the helper download **10 parts**, verify their SHA-256 values, and merge them. It verifies the completed compressed image before reporting success. The output appears in the same folder:

   ```
   Omarchy-4.5.0-HackberryPi-CM5-20261109.img.gz
   ```

4. In Raspberry Pi Imager choose **Use custom** and select that **`.img.gz` file directly**. Manual decompression is not needed.
5. Select a **16 GB or larger SD card**, confirm writing and let verification finish. Insert the card in HackberryPi CM5 and boot.

The helper prepares a local image file; SD-card selection and writing take place in Imager. The `hbr_*.tar.gz` and `hbo_*.tar.gz` PINN filesystem archives belong to the PINN method and are not whole-disk images for **Use custom**.

The FydeOS source card with Display Scale was tested and accepted by the owner; the sanitized standalone release image awaits a separate physical flash and first-run test. The rebuilt RPiOS image still awaits a physical boot test. The Omarchy helper reconstructs the same sanitized standalone image that the owner boot-tested. Read each release's current validation status before installing; the PINN installation and multiboot preview limits above remain separate.
