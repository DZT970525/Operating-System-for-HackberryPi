#!/usr/bin/env python3
"""Static Fyde preflight fixtures, no block devices, mounts or ARM execution."""
from pathlib import Path
import hashlib
import json
import runpy
import shutil
import struct
import subprocess
import tempfile
import time

BASE=Path(__file__).resolve().parent
API=runpy.run_path(str(BASE/'build-preparation.py'),run_name='test_import')

def elf():
    value=bytearray(64);value[:7]=b'\x7fELF\x02\x01\x01'
    struct.pack_into('<HHI',value,16,2,183,1)
    struct.pack_into('<HHH',value,52,64,56,0)
    return bytes(value)

def fails(call, text):
    try: call()
    except ValueError as error:
        assert text in str(error),(text,str(error))
    else:raise AssertionError('Expected source preflight refusal')

def main():
    with tempfile.TemporaryDirectory(prefix='preflight-fixture-',dir=BASE) as folder:
        fixture=Path(folder);root=fixture/'ROOT';state=fixture/'STATE';boot=fixture/'BOOT'
        (root/'usr/sbin').mkdir(parents=True);(root/'usr/local').mkdir()
        (state/'dev_image').mkdir(parents=True);boot.mkdir()
        (boot/'config.txt').write_text('# fixture')
        # Native ChromiumOS exports both installed-media and removable-media
        # namespaces. Their repeated names are intentional, not ambiguity.
        native=(BASE/'fixture-data/fydeos-partition-vars.public.json').read_bytes()
        assert hashlib.sha256(native).hexdigest()=='4dc544fdd7c16487cf72f1ddbe59a1c0e21315c5becd71e379c03448038bb6fe'
        d=json.loads(native)
        dictionary=root/'usr/sbin/partition_vars.json'
        dictionary.write_text(json.dumps(d))
        (root/'usr/sbin/write_gpt.sh').write_text('# native dictionary fixture')
        binding=json.loads((BASE/'fydeos-scale-binding.json').read_text())
        for relative,row in binding['critical_files'].items():
            destination=root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
            source=BASE/'fixture-data/scale-root'/relative
            data=source.read_bytes()
            assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
            destination.write_bytes(data)
        API['prepare_boot']('FydeOS',boot)
        call=lambda: API['preflight']('FydeOS',root,state,boot)
        before=(boot/'pinn/post-install.sh').read_bytes()
        fails(call,'No source-supplied Python')
        assert (boot/'pinn/post-install.sh').read_bytes()==before
        for namespace in d:
            broken=json.loads(json.dumps(d));del broken[namespace]
            dictionary.write_text(json.dumps(broken))
            fails(call,'Missing native Fyde partition namespace: '+namespace)
            broken=json.loads(json.dumps(d));del broken[namespace]['PARTITION_NUM_STATE']
            dictionary.write_text(json.dumps(broken))
            fails(call,'Native Fyde partition layout differs: '+namespace+'.PARTITION_NUM_STATE')
            broken=json.loads(json.dumps(d));broken[namespace]['PARTITION_NUM_STATE']='2'
            dictionary.write_text(json.dumps(broken))
            fails(call,'Native Fyde partition layout differs: '+namespace+'.PARTITION_NUM_STATE')
            broken=json.loads(json.dumps(d));broken[namespace]['FS_FORMAT_ROOT_A']='ext4'
            dictionary.write_text(json.dumps(broken))
            fails(call,'Published RAW Fyde root must remain ext2: '+namespace)
        dictionary.write_text(json.dumps(d))
        assert (boot/'pinn/post-install.sh').read_bytes()==before
        runtime=state/'dev_image/bin/python3.11'
        runtime.parent.mkdir();runtime.write_bytes(elf());runtime.chmod(0o755)
        library=state/'dev_image/lib/python3.11'
        for name in ['http/server.py','socket.py','socketserver.py','xml/etree/ElementTree.py',
                     'http/__init__.py','xml/__init__.py','xml/etree/__init__.py']:
            p=library/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# static fixture')
        extensions=library/'lib-dynload';extensions.mkdir()
        for name in ['_socket','select','pyexpat']:
            (extensions/(name+'.cpython-311-aarch64-linux-gnu.so')).write_bytes(elf())
        result=call()
        assert result['passed'] and result['python_runtime']['path']=='/usr/local/bin/python3.11'
        assert result['critical_scale_files_verified']==7
        assert result['native_partition_namespaces_verified']==['load_base_vars','load_partition_vars']
        assert result['python_runtime']['runtime_execution_verified'] is False
        hook=(boot/'pinn/post-install.sh').read_text()
        assert '/usr/bin/python3.11' not in hook
        assert '/usr/local/bin/python3.11' in hook
        assert 'hbf_runtime.tar.gz' not in hook
        assert call()['passed'], 'Repeated preflight must be idempotent'
        API['prepare_boot']('FydeOS',boot)
        socket=extensions/'_socket.cpython-311-aarch64-linux-gnu.so'
        saved=socket.read_bytes();socket.unlink()
        fails(call,'No source-supplied Python')
        socket.write_bytes(saved)
        scale=root/'usr/share/hackberry-shelf-helper/display-scale.js'
        scale.write_bytes(scale.read_bytes()+b'\n// changed')
        fails(call,'Display Scale1.2 file differs')
        # Absolute interpreter symlinks are resolved in source virtual space,
        # not the host /usr/local path.
        (root/'usr/bin').mkdir()
        (root/'usr/bin/python3.11').symlink_to('/usr/local/bin/python3.11')
        assert API['_python_runtime'](root,state)['path']=='/usr/bin/python3.11'
        # Production source places a genuine sourceless stdlib SquashFS at
        # /usr/lib/python3.11.squash, mounted by a later native VNC job. A
        # tiny SquashFS fixture exercises that layout and the earlier PINN
        # responder mount; no target Python bytecode or ELF is executed.
        scale.write_bytes((BASE/'fixture-data/scale-root/usr/share/hackberry-shelf-helper/display-scale.js').read_bytes())
        library.rename(fixture/'plain-library-hidden')
        squashed=fixture/'squash-tree';squashed.mkdir()
        bytecode=json.loads((BASE/'fixture-data/cpython311-sourceless-header-fixture.json').read_text())
        bytecode=bytes.fromhex(bytecode['hex'])
        for name in ['http/server','socket','socketserver','xml/etree/ElementTree',
                     'http/__init__','xml/__init__','xml/etree/__init__']:
            target=squashed/(name+'.pyc');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bytecode)
        (squashed/'lib-dynload').mkdir()
        for name in ['_socket','select','pyexpat']:
            (squashed/'lib-dynload'/(name+'.cpython-311-aarch64-linux-gnu.so')).write_bytes(elf())
        (root/'usr/lib/python3.11').mkdir(parents=True)
        (root/'etc/init').mkdir(parents=True)
        for name in ['fydeos-vnc-wsproxy.conf','fydeos-vncd.conf']:
            shutil.copyfile(BASE/'fixture-data'/(name+'.public'),root/'etc/init'/name)
        archive=root/'usr/lib/python3.11.squash'
        def pack():
            archive.unlink(missing_ok=True)
            subprocess.run(['mksquashfs',str(squashed),str(archive),'-noappend','-no-xattrs',
                            '-processors','1','-comp','gzip','-no-progress'],
                           check=True,capture_output=True)
        pack();API['prepare_boot']('FydeOS',boot)
        result=call()
        assert result['python_runtime']['stdlib']=='/usr/lib/python3.11'
        assert {row['kind'] for row in result['python_runtime']['stdlib_evidence']['modules'].values()}=={'sourceless-pyc'}
        assert result['python_runtime']['native_squashfs_stdlib']['responder_prestart_mount_required']
        hook=(boot/'pinn/post-install.sh').read_text()
        assert hook.index('mount -t squashfs -o loop,ro,nodev,nosuid')<hook.index('exec /usr/bin/python3.11 /usr/share/hackberry-pinn/no-update-server.py')
        assert 'env PYTHONPATH=/usr/lib/python3.11:/usr/lib/python3.11/lib-dynload' in hook
        assert call()['passed']
        missing=squashed/'lib-dynload/_socket.cpython-311-aarch64-linux-gnu.so'
        saved=missing.read_bytes();missing.unlink();pack()
        fails(call,'No source-supplied Python')
        missing.write_bytes(saved)
        malformed=squashed/'socket.pyc';saved=malformed.read_bytes();malformed.write_bytes(b'BAD!'+saved[4:]);pack()
        fails(call,'No source-supplied Python')
        malformed.write_bytes(saved);pack()
        wire=root/'etc/init/fydeos-vnc-wsproxy.conf';wire.write_text(wire.read_text().replace('mp=/usr/lib/python3.11','mp=/wrong-target'))
        fails(call,'Native Python SquashFS mount wiring differs')
    report={'passed':True,'missing_runtime_refused_before_hook_mutation':True,
      'source_STATE_dev_image_fallback_resolved':True,
      'absolute_source_symlinks_resolved_without_host_root_access':True,
      'aarch64_elf_class_and_stdlib_extensions_checked':True,
      'selected_existing_runtime_bound_into_staged_hook':True,
      'seven_actual_Display_Scale1_2_files_checked':True,
      'both_real_native_partition_namespaces_checked':True,
      'exact_published_native_dictionary_fixture_checked':True,
      'missing_namespace_or_key_refused':True,
      'disagreeing_native_partition_numbers_refused':True,
      'non_ext2_format_refused_in_either_namespace':True,
      'native_squashfs_stdlib_and_sourceless_pyc_inspected':True,
      'squashfs_elf_extensions_still_required':True,
      'malformed_sourceless_pyc_refused':True,
      'native_mount_wiring_and_responder_prestart_order_checked':True,
      'missing_socket_extension_refused':True,'changed_scale_payload_refused':True,
      'idempotent':True,'new_runtime_downloaded':False,
      'runtime_execution_verified':False,'block_devices_accessed':False,
      'completed_unix':time.time()}
    (BASE/'preflight-fixture-report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
