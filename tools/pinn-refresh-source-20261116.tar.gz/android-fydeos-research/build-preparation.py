#!/usr/bin/env python3
"""Helpers for the parent's server-side source image -> PINN package build.

Functions only mutate an explicitly supplied staging boot directory, never a
whole disk. The common builder handles raw payload hashing/compression/splitting.
"""
from pathlib import Path
import hashlib
import json
import shutil
import os
import posixpath
import re
import struct

BASE = Path(__file__).resolve().parent
PROFILES = {
 'LineageOS': {
  'source_compressed_sha256': 'a6c16d9bb6bb7c25d9e6265fe1611690cad36088f50b7e0353a084432229667d',
  'post_install': 'lineage',
  'boot_source_partition': 1,
  'slots': [
   {'slot': 1, 'source_partition': 1, 'label': 'hbl_boot', 'filesystem': 'fat', 'nominal_mib': 128, 'want_maximised': False},
   {'slot': 2, 'source_partition': 5, 'label': 'hbl_system', 'filesystem': 'ext4', 'nominal_mib': 3072, 'want_maximised': False},
   {'slot': 3, 'source_partition': 6, 'label': 'hbl_vendor', 'filesystem': 'ext4', 'nominal_mib': 384, 'want_maximised': False},
   {'slot': 4, 'source_partition': 7, 'label': 'hbl_metadata', 'filesystem': 'ext4', 'nominal_mib': 16, 'want_maximised': False},
   {'slot': 5, 'source_partition': 3, 'label': 'hbl_data', 'filesystem': 'ext4', 'nominal_mib': 3072, 'want_maximised': True},
  ],
  'source_layout_note': 'Five real filesystems; source DOS p2 is ONLY an extended container, never a sixth payload.',
 },
 'FydeOS': {
  'source_compressed_sha256': '201e6ffa4a5d9507537d7dfebfd662433ad385784535fe0046ba91e8a79f9028',
  'post_install': 'fydeos',
  'boot_source_partition': 12,
  'slots': [
   {'slot': 1, 'source_partition': 12, 'label': 'hbf_boot', 'filesystem': 'fat', 'nominal_mib': 128, 'want_maximised': False},
   {'slot': 2, 'source_partition': 3, 'label': 'hbf_root', 'filesystem': 'ext2', 'nominal_mib': 3072, 'want_maximised': False},
   {'slot': 3, 'source_partition': 1, 'label': 'hbf_state', 'filesystem': 'ext4', 'nominal_mib': 4096, 'want_maximised': True},
   {'slot': 4, 'source_partition': 8, 'label': 'hbf_oem', 'filesystem': 'ext4', 'nominal_mib': 16, 'want_maximised': False},
  ],
  'source_layout_note': 'Native 12-partition GPT standalone becomes FAT+ROOT-A+STATE+OEM MBR PINN edition; native A/B rollback, whole-disk installation, Powerwash and OTA unavailable.',
 }
}

def profile(os_id):
    return json.loads(json.dumps(PROFILES[os_id]))

def prepare_boot(os_id, boot_directory):
    """Install only OS-specific posthook/DTBO; caller creates common receiver."""
    if os_id not in PROFILES:
        raise ValueError('Unknown profile')
    boot = Path(boot_directory).resolve(strict=True)
    if not boot.is_dir() or not (boot/'config.txt').is_file():
        raise ValueError('Explicit staged FAT boot directory required')
    destination = boot/'pinn'
    destination.mkdir(exist_ok=True)
    hook = BASE/('post-install-lineage.sh' if os_id=='LineageOS' else 'post-install-fydeos.sh')
    shutil.copyfile(hook, destination/'post-install.sh')
    (destination/'post-install.sh').chmod(0o755)
    if os_id=='LineageOS':
        overlay=BASE/'android-pinn.dtbo'
        if not overlay.is_file():
            raise ValueError('Compile bundled android-pinn-overlay.dts with dtc -@ before packaging')
        (boot/'overlays').mkdir(exist_ok=True)
        shutil.copyfile(overlay, boot/'overlays/android-pinn.dtbo')
        shutil.copyfile(BASE/'android-pinn-overlay.dts', destination/'android-pinn-overlay.dts')
    notes = (
      'PINN multiboot edition. This installer allocates separate partitions and '
      'preserves the published screen, battery and display-scale integration. '
      'Native whole-disk OTA/recovery/Powerwash and automatic partition-table '
      'growth are disabled; reinstall or upgrade through PINN. Offline '
      'conversion/relocation checks do not establish a physical boot test.\n'
    )
    (destination/'MULTIBOOT-NOTICE.txt').write_text(notes)
    return {
      'os_id': os_id, 'post_install': {'type':PROFILES[os_id]['post_install']},
      'hook_sha256':hashlib.sha256((destination/'post-install.sh').read_bytes()).hexdigest(),
      'supports_backup':False,
      'source_hash_required':PROFILES[os_id]['source_compressed_sha256'],
    }

def _virtual_file(root, state, virtual):
    """Resolve symlinks inside the SOURCE image, never against the host root.

    FydeOS mounts STATE/dev_image at /usr/local. Both spellings map to STATE
    here, without making any bind mount or changing either read-only source.
    """
    root=Path(root).resolve(strict=True); state=Path(state).resolve(strict=True)
    virtual=posixpath.normpath('/'+virtual.lstrip('/'))
    def physical(value):
        if value=='/usr/local' or value.startswith('/usr/local/'):
            return state/'dev_image'/value.removeprefix('/usr/local').lstrip('/')
        if value=='/mnt/stateful_partition' or value.startswith('/mnt/stateful_partition/'):
            return state/value.removeprefix('/mnt/stateful_partition').lstrip('/')
        return root/value.lstrip('/')
    for _ in range(41):
        pieces=[p for p in virtual.split('/') if p]; current=''
        for index,piece in enumerate(pieces):
            current+='/'+piece
            path=physical(current)
            if path.is_symlink():
                target=os.readlink(path)
                virtual=posixpath.normpath(posixpath.join(
                  '/' if target.startswith('/') else posixpath.dirname(current),
                  target, *pieces[index+1:]))
                break
        else:
            path=physical(virtual)
            if not path.is_file():
                raise FileNotFoundError(virtual)
            return path, virtual
    raise ValueError('Source-image symlink loop')

def _elf64_aarch64(path):
    with Path(path).open('rb') as source:
        header=source.read(64)
        if len(header)<64 or header[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',header,18)[0]!=183:
            raise ValueError('Python/runtime module is not an AArch64 ELF64 file')
        phoff=struct.unpack_from('<Q',header,32)[0]
        phsize,phnum=struct.unpack_from('<HH',header,54)
        if phnum>1024 or (phnum and phsize<56):
            raise ValueError('Invalid ELF program header table')
        interpreter=None
        for n in range(phnum):
            source.seek(phoff+n*phsize); p=source.read(56)
            if len(p)!=56:raise ValueError('Truncated ELF program header')
            if struct.unpack_from('<I',p)[0]==3:
                offset,length=struct.unpack_from('<QQ',p,8)[0],struct.unpack_from('<Q',p,32)[0]
                if not 1<length<4096:raise ValueError('Invalid ELF interpreter length')
                source.seek(offset); value=source.read(length)
                if not value.endswith(b'\0'):raise ValueError('Invalid ELF interpreter string')
                interpreter=value[:-1].decode('ascii')
        return interpreter

def _python_runtime(root, state):
    reasons=[]
    candidates=['/usr/bin/python3.11','/usr/bin/python3',
                '/usr/local/bin/python3.11','/usr/local/bin/python3']
    pure=['http/server.py','socket.py','socketserver.py','xml/etree/ElementTree.py']
    for candidate in candidates:
        try:
            binary,resolved=_virtual_file(root,state,candidate)
            if not binary.stat().st_mode&0o111:raise ValueError('Interpreter is not executable')
            interp=_elf64_aarch64(binary)
            if interp:
                loader,_=_virtual_file(root,state,interp)
                _elf64_aarch64(loader)
            match=re.search(r'python(3[.][0-9]+)',posixpath.basename(resolved))
            if not match:raise ValueError('Cannot bind interpreter to a Python minor version')
            version=match.group(1)
            library_candidates=[
              posixpath.normpath(posixpath.join(posixpath.dirname(resolved),'../lib/python'+version)),
              '/usr/lib/python'+version,'/usr/lib64/python'+version,
              '/usr/local/lib/python'+version,'/usr/local/lib64/python'+version]
            found=None
            for library in dict.fromkeys(library_candidates):
                try:
                    members={part:_virtual_file(root,state,library+'/'+part)[0] for part in pure}
                    # These stdlib C extension modules are needed for the
                    # loopback HTTP listener and XML parsing. No old runtime is
                    # downloaded to satisfy missing dependencies.
                    directory,_=_virtual_file(root,state,library+'/socket.py')
                    extensions=directory.parent/'lib-dynload'
                    for stem in ['_socket','select','pyexpat']:
                        files=list(extensions.glob(stem+'.*.so'))+list(extensions.glob(stem+'.so'))
                        if not files:raise ValueError('Missing Python extension '+stem)
                        _elf64_aarch64(files[0])
                    found=(library,members);break
                except (FileNotFoundError,ValueError):
                    continue
            if not found:raise ValueError('Missing matching HTTP/socket/XML Python stdlib')
            return {'path':candidate,'resolved_virtual_path':resolved,'version':version,
              'elf_interpreter':interp,'stdlib':found[0],
              'interpreter_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
              'static_source_resolution_verified':True,'runtime_execution_verified':False}
        except (FileNotFoundError,ValueError,OSError) as error:
            reasons.append(candidate+': '+str(error))
    raise ValueError('No source-supplied Python bridge runtime: '+'; '.join(reasons))

def preflight(os_id, root_directory, state_directory, boot_directory):
    """Inspect RO Fyde ROOT+STATE, then bind the staged hook's Python path.

    Call AFTER prepare_boot has placed the reviewed hook at boot/pinn/post-install.sh,
    BEFORE common payload generation binds its SHA256. Pass the adjusted bytes
    to that generator, and do not overwrite the hook with the original template.
    This is static ELF/stdlib resolution, not an emulated/runtime boot test.
    """
    if os_id!='FydeOS':
        return {'os_id':os_id,'needed':False}
    root=Path(root_directory).resolve(strict=True)
    state=Path(state_directory).resolve(strict=True)
    boot=Path(boot_directory).resolve(strict=True)
    if not root.is_dir() or not state.is_dir() or root==state:
        raise ValueError('Separate source ROOT and STATE directories required')
    if not (root/'usr/local').exists() and not (root/'usr/local').is_symlink():
        raise ValueError('Missing native /usr/local STATE/dev_image bind target')
    dictionary=json.loads((root/'usr/sbin/partition_vars.json').read_text())
    # ChromiumOS deliberately exports the same partition numbers in two
    # namespaces: installed media and removable installation media. Native
    # startup consumes load_partition_vars; chromeos-install consumes
    # load_base_vars. Repeated keys ACROSS those maps are not duplicate fields.
    # Validate each consumer's actual namespace, including the exact source
    # layout which our posthook relocates in BOTH dictionaries.
    source_numbers={'PARTITION_NUM_STATE':'1','PARTITION_NUM_ROOT_A':'3',
                    'PARTITION_NUM_OEM':'8','PARTITION_NUM_EFI_SYSTEM':'12'}
    native_maps=['load_base_vars','load_partition_vars']
    if not isinstance(dictionary,dict):
        raise ValueError('Native Fyde partition dictionary must be an object')
    for name in native_maps:
        values=dictionary.get(name)
        if not isinstance(values,dict):
            raise ValueError('Missing native Fyde partition namespace: '+name)
        for key,expected in source_numbers.items():
            if values.get(key)!=expected:
                raise ValueError('Native Fyde partition layout differs: '+name+'.'+key)
        if values.get('FS_FORMAT_ROOT_A')!='ext2':
            raise ValueError('Published RAW Fyde root must remain ext2: '+name)
    if not (root/'usr/sbin/write_gpt.sh').is_file():
        raise ValueError('Missing native Fyde partition script')
    binding=json.loads((BASE/'fydeos-scale-binding.json').read_text())
    for relative,row in binding['critical_files'].items():
        path,_=_virtual_file(root,state,'/'+relative)
        data=path.read_bytes()
        if len(data)!=row['size'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
            raise ValueError('Published Display Scale1.2 file differs: '+relative)
    extension=json.loads((root/'usr/share/hackberry-shelf-helper/manifest.json').read_text())
    if extension['version']!='1.2.0' or extension['background']['service_worker']!='display-scale-background-v2.js':
        raise ValueError('Display Scale1.2 active worker binding differs')
    runtime=_python_runtime(root,state)
    hook=boot/'pinn/post-install.sh'
    if not hook.is_file() or hook.is_symlink():
        raise ValueError('Prepared regular post-install hook required')
    content=hook.read_text()
    if 'hbf_apps.tar.gz' in content or 'hbf_runtime.tar.gz' in content:
        raise ValueError('Legacy runtime/application downloads must not be reintroduced')
    replacement=runtime['path']
    if not re.fullmatch(r'/usr/(?:local/)?bin/python3(?:[.][0-9]+)?',replacement):
        raise ValueError('Unexpected source interpreter path')
    template=(BASE/'post-install-fydeos.sh').read_text()
    if content not in (template,template.replace('/usr/bin/python3.11',replacement)):
        raise ValueError('Unreviewed Python bridge template')
    content=content.replace('/usr/bin/python3.11',replacement)
    hook.write_text(content);hook.chmod(0o755)
    report={'passed':True,'os_id':os_id,'python_runtime':runtime,
      'display_scale_version':'1.2.0','critical_scale_files_verified':len(binding['critical_files']),
      'native_partition_namespaces_verified':native_maps,
      'native_source_partition_numbers_verified':source_numbers,
      'legacy_runtime_downloaded':False,'readonly_source_files_modified':False,
      'post_hook_python_path_bound':replacement,
      'post_hook_sha256':hashlib.sha256(hook.read_bytes()).hexdigest(),
      'physical_boot_tested':False}
    (boot/'pinn/fydeos-preflight.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-boot', nargs=2, metavar=('FAMILY','DIRECTORY'))
    args=parser.parse_args()
    if args.prepare_boot:
        print(json.dumps(prepare_boot(*args.prepare_boot),indent=2))
    else:
        print(json.dumps(PROFILES, indent=2))
