#!/usr/bin/env python3
"""Stage a RAW-preserving FydeOS posthook from the older project adapter.

This edits ONLY the candidate staging directory. It never opens a block device.
The old per-app supplement downloads are deliberately not included.
"""
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parents[1] / 'publish-omarchy/repo/FydeOS/partition_setup.sh'
source = SOURCE.read_text()
prefix = source.split('if [ "${HB_PINN_TEST:-0}" = 1 ]; then return 0; fi')[0]
assert 'PAYLOADS' not in prefix and 'patch_root()' in prefix
prefix = prefix.replace('#supports_backup in PINN\n', '')
prefix = prefix.replace('# FydeOS four-partition preview; no raw GPT writes.',
    '# Latest FydeOS23 RAW-preserving four-partition PINN posthook.\n'
    '# Candidate. Common receiver already verified/wrote ROOT/STATE/OEM.\n'
    '# No legacy application supplement is downloaded by this adapter.')
prefix = prefix.replace('rootfstype=ext4', 'rootfstype=ext2')
prefix = prefix.replace('/"FS_FORMAT_ROOT_A": "ext4"', '/"FS_FORMAT_ROOT_A": "ext2"')
prefix = prefix.replace('FS_FORMAT_ROOT_A=\\"ext4\\"', 'FS_FORMAT_ROOT_A=\\"ext2\\"')
prefix = prefix.replace('/FS_FORMAT_ROOT_A="ext4"', '/FS_FORMAT_ROOT_A="ext2"')
prefix = prefix.replace('FS_FORMAT_ROOT_A="ext2"/', 'FS_FORMAT_ROOT_A="ext[24]"/')
prefix = prefix.replace(r"/\text4\tro\t0 0", r"/\text2\tro\t0 0")
prefix = prefix.replace('*"ext2"/"FS_FORMAT_ROOT_A"', '*"ext[24]"/"FS_FORMAT_ROOT_A"')
prefix = prefix.replace('FS_FORMAT_ROOT_A=\\"ext2\\"/FS_FORMAT_ROOT_A',
                        'FS_FORMAT_ROOT_A=\\"ext[24]\\"/FS_FORMAT_ROOT_A')
prefix = prefix.replace('/FS_FORMAT_ROOT_A="ext[24]"/g', '/FS_FORMAT_ROOT_A="ext2"/g')
assert 'rootfstype=ext4' not in prefix
assert '"FS_FORMAT_ROOT_A": "ext4"' not in prefix
assert '/FS_FORMAT_ROOT_A="ext4"' not in prefix
assert r'/\text4\tro\t0 0' not in prefix
# The native production stdlib is mounted by a later VNC job. Ensure this
# earlier responder performs the same guarded read-only mount before Python.
runtime_mount = r'''env PYTHONPATH=/usr/lib/python3.11:/usr/lib/python3.11/lib-dynload
pre-start script
 # The native VNC job mounts this same source-supplied sourceless stdlib,
 # but starts after system-services. The update responder must mount it first.
 sq=/usr/lib/python3.11.squash
 mp=/usr/lib/python3.11
 if [ -f "${sq}" ] && ! mountpoint -q "${mp}" \
     && [ -z "$(ls -A "${mp}" 2>/dev/null)" ]; then
  mount -t squashfs -o loop,ro,nodev,nosuid "${sq}" "${mp}"
 fi
end script
'''
needle='respawn limit 3 60\nexec /usr/bin/python3.11'
assert prefix.count(needle)==1
prefix=prefix.replace(needle,'respawn limit 3 60\n'+runtime_mount+'exec /usr/bin/python3.11')
needle='pre-start script\n start hackberry-pinn-update-server'
assert prefix.count(needle)==1
prefix=prefix.replace(needle,'pre-start script\n export PYTHONPATH=/usr/lib/python3.11:/usr/lib/python3.11/lib-dynload\n start hackberry-pinn-update-server')
suffix = r'''
fyde_die() { echo "FydeOS PINN: $*" >&2; exit 1; }
fyde_fsck() {
 rc=0; e2fsck -f -p "$1" || rc=$?
 [ "$rc" -le 1 ] || fyde_die "Filesystem check failed: $1 ($rc)"
}
fyde_partuuid() {
 case "$1" in PARTUUID=*) value=$1;; '') fyde_die "PINN did not supply a partition-table identity";; *) value="PARTUUID=$1";; esac
 printf '%s\n' "$value" | grep -Eq '^PARTUUID=[A-Fa-f0-9-]+$' || fyde_die "Invalid partition identity"
 printf '%s\n' "$value"
}
if [ "${HB_PINN_FUNCTIONS_ONLY:-0}" = 1 ]; then
 return 0 2>/dev/null || exit 0
fi
[ "$(id -u)" = 0 ] || fyde_die "Must run in PINN as root"
: "${part1:?}" "${part2:?}" "${part3:?}" "${part4:?}" "${partuuid1:?}" "${partuuid2:?}" "${PINN_BOOT_MOUNT:?}"
boot=$PINN_BOOT_MOUNT
[ "$(pwd -P)" = "$boot" ] || fyde_die "Boot working directory mismatch"
parent=
seen=' '
for p in "$part1" "$part2" "$part3" "$part4"; do
 printf '%s\n' "$p" | grep -Eq '^/dev/(mmcblk[0-9]+p[0-9]+|sd[a-z]+[0-9]+|nvme[0-9]+n[0-9]+p[0-9]+)$' || fyde_die "Invalid partition path"
 [ -b "$p" ] || fyde_die "Not a block partition"
 n=$(basename "$p")
 [ -f "/sys/class/block/$n/partition" ] || fyde_die "Whole-drive device refused"
 [ "$(cat "/sys/class/block/$n/partition")" -ge 6 ] || fyde_die "PINN recovery/settings partition refused"
 actual_parent=$(dirname "$(readlink -f "/sys/class/block/$n")")
 [ -n "$parent" ] || parent=$actual_parent
 [ "$parent" = "$actual_parent" ] || fyde_die "Cross-drive installation refused"
 case "$seen" in *" $n "*) fyde_die "Duplicate partition";; esac
 seen="$seen$n "
done
awk -v p="$part1" -v m="$boot" '$1==p && $2==m {found=1} END {exit !found}' /proc/mounts || fyde_die "Boot mount identity mismatch"
for p in "$part2" "$part3" "$part4"; do
 if awk -v p="$p" '$1==p {found=1} END {exit !found}' /proc/mounts; then fyde_die "Raw partition already mounted"; fi
 fyde_fsck "$p"
done
# Only enlarge STATE inside PINN's already allocated part3.
resize2fs "$part3" || fyde_die "Cannot grow allocated STATE filesystem"
fyde_fsck "$part3"
bn=$(part_number "$part1"); rn=$(part_number "$part2")
sn=$(part_number "$part3"); on=$(part_number "$part4")
root_id=$(fyde_partuuid "$partuuid2")
boot_id=$(fyde_partuuid "$partuuid1")
scratch=$(mktemp -d /tmp/hb-fydeos-pinn.XXXXXX)
root="$scratch/root"
mounted=0
cleanup() {
 if [ "$mounted" = 1 ]; then umount "$root" || return 1; fi
 rm -rf "$scratch"
}
trap 'rc=$?; trap - EXIT HUP INT TERM; cleanup || rc=1; exit "$rc"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir "$root"
mount -t ext2 -o rw,nosuid,nodev "$part2" "$root" || fyde_die "Cannot mount actual RAW ext2 root"
mounted=1
[ -f "$root/usr/sbin/partition_vars.json" ] && [ -f "$root/usr/sbin/write_gpt.sh" ] || fyde_die "Missing native FydeOS partition dictionaries"
for key in STATE ROOT_A OEM EFI_SYSTEM; do
 grep -q "\"PARTITION_NUM_$key\"" "$root/usr/sbin/partition_vars.json" || fyde_die "Missing native partition key: $key"
done
patch_root "$root" "$boot" "$root_id" "$boot_id" "$bn" "$rn" "$sn" "$on"
# Boot-confirmation has no A/B GPT slot here. Preserve its caller contract
# while preventing GPT flag updates on the MBR multiboot disk.
for rel in usr/sbin/chromeos-setgoodkernel usr/bin/chromeos-setgoodkernel; do
 file="$root/$rel"
 if [ -f "$file" ]; then
  [ -f "$file.pinn-disabled" ] || cp -p "$file" "$file.pinn-disabled"
  printf '%s\n' '#!/bin/sh' '# PINN single-active-slot edition: no GPT flags to mark.' 'exit 0' > "$file"
  chmod 0755 "$file"
 fi
done
awk 'NR==1 {
 for(i=1;i<=NF;i++) if($i !~ /^mmcblk[.]perdev_minors=/) printf "%s ",$i
 print "mmcblk.perdev_minors=64"; next
} NF {exit 23}' "$boot/cmdline.txt" > "$boot/cmdline.txt.pinn-new" || fyde_die "Unexpected cmdline"
mv "$boot/cmdline.txt.pinn-new" "$boot/cmdline.txt"
printf '%s\n' "boot=$part1" "root=$part2" "state=$part3" "oem=$part4" \
 > "$root/usr/share/hackberry-pinn/partition-map"
sync
umount "$root" || fyde_die "Cannot unmount own root partition"
mounted=0
fyde_fsck "$part2"
trap - EXIT HUP INT TERM
rm -rf "$scratch"
echo "FydeOS PINN relocation complete; native whole-disk OTA/Powerwash disabled."
'''
(BASE / 'post-install-fydeos.sh').write_text(prefix + suffix)
print(BASE / 'post-install-fydeos.sh')
