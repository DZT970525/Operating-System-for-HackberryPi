#!/usr/bin/env python3
"""Meaningful offline tests on OWNED FIXTURES, no block devices or mounts."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import tempfile
import time
import argparse

BASE=Path(__file__).resolve().parent
LINEAGE=BASE/'post-install-lineage.sh'
FYDE=BASE/'post-install-fydeos.sh'

def run(argv, **kwargs):
    return subprocess.run(argv,check=True,text=True,capture_output=True,**kwargs)

def functions(hook, command, success=True):
    body='HB_PINN_FUNCTIONS_ONLY=1; export HB_PINN_FUNCTIONS_ONLY; . '+shlex.quote(str(hook))+'; '+command
    p=subprocess.run(['bash','-c',body],text=True,capture_output=True)
    if success and p.returncode:
        raise RuntimeError(p.stderr+p.stdout)
    if not success and not p.returncode:
        raise AssertionError('Expected refusal')
    return p

def entries(blob):
    p=0; result={}
    while True:
        h=blob[p:p+110]
        assert h[:6] in (b'070701',b'070702')
        v=[int(h[6+i*8:14+i*8],16) for i in range(13)]
        size,namesize=v[6],v[11]
        name=blob[p+110:p+110+namesize-1].decode()
        p=(p+110+namesize+3)&~3
        value=blob[p:p+size]
        p=(p+size+3)&~3
        if name=='TRAILER!!!': break
        while name.startswith('./'): name=name[2:]
        if name=='': name='.'
        # Preserve ownership, mode, device nodes and all file/symlink contents.
        result[name]={'mode':v[1],'uid':v[2],'gid':v[3],
                      'rdevmajor':v[9],'rdevminor':v[10],
                      'data':value}
    return result

FSTAB=('# Android fstab fixture\n'
       '/dev/block/by-name/userdata /data ext4 nodev,noatime,nosuid,errors=panic wait,check,formattable,quota\n'
       '/devices/platform/axi/*.usb/usb* auto auto defaults voldmanaged=usb:auto\n')

def synthetic_cpio():
    archive=bytearray()
    members=[
      ('fstab.rpi5',0o100644,FSTAB.encode()),
      ('init',0o100750,b'fixture init binary bytes only, never executed'),
      ('metadata',0o40755,b''),
      ('dev',0o40755,b''),
      ('system',0o40755,b''),
      ('bin',0o40755,b''),
      ('bin/sh',0o120777,b'/system/bin/sh'),
      ('TRAILER!!!',0,b'')]
    for number,(name,mode,data) in enumerate(members,1):
        name=name.encode()+b'\0'
        fields=[number,mode,os.getuid(),os.getgid(),1,1600000000,len(data),0,0,0,0,len(name),0]
        archive+=b'070701'+b''.join(f'{value:08x}'.encode() for value in fields)+name
        archive+=bytes((-len(archive))%4)
        archive+=data;archive+=bytes((-len(archive))%4)
    return gzip.compress(bytes(archive),mtime=0)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-boot',type=Path)
    parser.add_argument('--source-vendor',type=Path)
    options=parser.parse_args()
    if options.source_boot or options.source_vendor:
        assert options.source_boot and options.source_vendor, 'Both real-source paths required'
        assert os.geteuid()==0, 'Use root only for the real-source ownership preservation case'
    fixture=Path(tempfile.mkdtemp(prefix='owned-fixtures-',dir=BASE))
    try:
        boot=fixture/'boot'; vendor=fixture/'vendor'; scratch=fixture/'scratch'
        boot.mkdir(); scratch.mkdir()
        (boot/'overlays').mkdir()
        if options.source_boot:
            for name in ['config.txt','config_user.txt','cmdline.txt','ramdisk.img']:
                shutil.copyfile(options.source_boot/name,boot/name)
        else:
            (boot/'config.txt').write_text('kernel=Image\ninitramfs ramdisk.img followkernel\ndtoverlay=android-sdcard\ninclude config_user.txt\n')
            (boot/'config_user.txt').write_text('[all]\ndtoverlay=hackberrypicm5-lineage\ndtoverlay=dwc2,dr_mode=host\n')
            (boot/'cmdline.txt').write_text('console=ttyAMA10,115200 androidboot.hardware=rpi5 androidboot.selinux=permissive\n')
            (boot/'ramdisk.img').write_bytes(synthetic_cpio())
        shutil.copyfile(BASE/'android-pinn.dtbo',boot/'overlays/android-pinn.dtbo')
        (boot/'ramdisk-recovery.img').write_bytes(b'fixture recovery only')
        (vendor/'etc/init').mkdir(parents=True); (vendor/'bin').mkdir()
        original=(run(['debugfs','-R','cat /etc/fstab.rpi5',str(options.source_vendor)]).stdout
                  if options.source_vendor else FSTAB)
        (vendor/'etc/fstab.rpi5').write_text(original)
        (vendor/'bin/rpi-recovery.sh').write_text('#!/vendor/bin/sh\n# fixture\nexit 0\n')
        old=entries(gzip.decompress((boot/'ramdisk.img').read_bytes()))
        functions(LINEAGE,'hb_patch_ramdisk '+ ' '.join(map(shlex.quote,[str(boot),'/dev/block/mmcblk0p40',str(scratch)])))
        new=entries(gzip.decompress((boot/'ramdisk.img').read_bytes()))
        assert set(old)==set(new), {'missing':sorted(set(old)-set(new)), 'added':sorted(set(new)-set(old))}
        for name in old:
            if name=='fstab.rpi5':
                for key in old[name]:
                    if key!='data': assert old[name][key]==new[name][key],(name,key)
                assert b'/dev/block/mmcblk0p40' in new[name]['data']
                assert b'/dev/block/by-name/userdata' not in new[name]['data']
            else: assert old[name]==new[name],name
        args=[str(boot),'/dev/block/mmcblk0p36','/dev/block/mmcblk0p37',
              '/dev/block/mmcblk0p38','/dev/block/mmcblk0p39']
        functions(LINEAGE,'hb_patch_android_config '+' '.join(map(shlex.quote,args)))
        functions(LINEAGE,'hb_patch_android_config '+' '.join(map(shlex.quote,args)))
        config=(boot/'config.txt').read_text()+(boot/'config_user.txt').read_text()
        assert 'dtoverlay=android-sdcard' not in config
        assert config.count('dtoverlay=android-pinn\n')==1
        for field in ['boot_dev','system_dev','vendor_dev','metadata_dev']:
            assert config.count('dtparam='+field+'=')==1
        for line in (boot/'config_user.txt').read_text().splitlines():
            if line.startswith('dtparam='): assert len(line)<80
        assert 'mmcblk.perdev_minors=64' in (boot/'cmdline.txt').read_text()
        functions(LINEAGE,'hb_patch_data_fstab '+shlex.quote(str(vendor/'etc/fstab.rpi5'))+' /dev/block/mmcblk0p40')
        assert '/dev/block/mmcblk0p40' in (vendor/'etc/fstab.rpi5').read_text()
        functions(LINEAGE,'hb_disable_android_native_recovery '+shlex.quote(str(vendor))+' '+shlex.quote(str(boot)))
        assert (boot/'ramdisk-recovery.img.pinn-disabled').exists()
        assert not (boot/'ramdisk-recovery.img').exists()
        assert 'exit 1' in (vendor/'bin/rpi-recovery.sh').read_text()
        assert 'org.lineageos.updater' in (vendor/'bin/hackberrypi-pinn-no-ota.sh').read_text()
        functions(LINEAGE,'hb_android_path /dev/mmcblk0',success=False)
        functions(LINEAGE,"hb_android_path '/dev/mmcblk0p6;id'",success=False)
        bad=fixture/'bad-fstab';bad.write_text(original+original)
        before=bad.read_bytes()
        functions(LINEAGE,'hb_patch_data_fstab '+shlex.quote(str(bad))+' /dev/block/mmcblk0p40',success=False)
        assert bad.read_bytes()==before

        fyde=fixture/'fyde';fb=fixture/'fyde-boot'
        (fyde/'usr/sbin').mkdir(parents=True);(fyde/'etc/init').mkdir(parents=True)
        (fyde/'sbin').mkdir();fb.mkdir()
        (fyde/'etc/lsb-release').write_text('CHROMEOS_RELEASE_NAME=FydeOS\nCHROMEOS_AUSERVER=https://update.example.invalid/service/update2\n')
        values={'STATE':1,'ROOT_A':3,'OEM':8,'EFI_SYSTEM':12,
                'ROOT_B':5,'ROOT_C':7,'KERN_A':2,'KERN_B':4,
                'KERN_C':6,'RWFW':11,'RESERVED':9}
        native=(BASE/'fixture-data/fydeos-partition-vars.public.json').read_bytes()
        assert hashlib.sha256(native).hexdigest()=='4dc544fdd7c16487cf72f1ddbe59a1c0e21315c5becd71e379c03448038bb6fe'
        dictionary=json.loads(native)
        (fyde/'usr/sbin/partition_vars.json').write_text(json.dumps(dictionary))
        (fyde/'usr/sbin/write_gpt.sh').write_text('\n'.join(
          'PARTITION_NUM_'+k+'="'+str(v)+'"' for k,v in values.items())+'\nFS_FORMAT_ROOT_A="ext2"\n')
        (fb/'cmdline.txt').write_text('console=tty1 root=PARTUUID=old-03 rootfstype=ext2 rootwait\n')
        args=[str(fyde),str(fb),'PARTUUID=1234abcd-25','PARTUUID=1234abcd-24','36','37','38','39']
        functions(FYDE,'patch_root '+' '.join(map(shlex.quote,args)))
        mapped=json.loads((fyde/'usr/sbin/partition_vars.json').read_text())
        for namespace in ['load_base_vars','load_partition_vars']:
            for key,value in [('EFI_SYSTEM',36),('ROOT_A',37),('STATE',38),('OEM',39)]:
                assert mapped[namespace]['PARTITION_NUM_'+key]==str(value)
            for key in ['ROOT_B','ROOT_C','KERN_A','KERN_B','KERN_C','RWFW','RESERVED']:
                assert mapped[namespace]['PARTITION_NUM_'+key]=='0'
            assert mapped[namespace]['FS_FORMAT_ROOT_A']=='ext2'
        assert 'FS_FORMAT_ROOT_A="ext2"' in (fyde/'usr/sbin/write_gpt.sh').read_text()
        assert 'FS_FORMAT_ROOT_A="ext4"' not in (fyde/'usr/sbin/write_gpt.sh').read_text()
        assert 'root=PARTUUID=1234abcd-25 rootfstype=ext2' in (fb/'cmdline.txt').read_text()
        assert '\t/\text2\tro' in (fyde/'etc/fstab').read_text()
        for path in ['sbin/clobber-state','usr/sbin/clobber','usr/sbin/chromeos-install',
                     'usr/sbin/expand-partition.sh','usr/sbin/update_kernel.sh','usr/sbin/update_dtb.sh']:
            assert 'exit 1' in (fyde/path).read_text()
        for job in ['auto-expand-partition','boot-update-firmware','os_install_service','fwupdtool-update','fydeos-scripts-updater']:
            assert 'manual' in (fyde/'etc/init'/f'{job}.conf').read_text()
        assert 'http://127.0.0.1:18097/service/update2' in (fyde/'etc/lsb-release').read_text()
        source=FYDE.read_text()
        assert 'hbf_apps.tar.gz' not in source and 'hbf_runtime.tar.gz' not in source

        out={'passed':True,'scope':'Only owned directory fixtures modified; optional verified source vendor inspected read-only',
          'block_device_written_or_mounted':False,
          'source_vendor_block_readonly_inspection':bool(options.source_vendor and options.source_vendor.is_block_device()),
          'android_ramdisk_fixture_kind':'actual verified source' if options.source_boot else 'self-contained synthetic newc',
          'android_ramdisk_entries_compared':len(old),
          'android_all_ownership_modes_device_nodes_and_other_file_bytes_preserved':True,
          'android_data_fstab_in_ramdisk_and_vendor_relocated':True,
          'android_config_repeated_application_has_single_parameterized_overlay':True,
          'android_partition_numbers_above31_supported_by_config':True,
          'android_native_whole_disk_recovery_and_ota_client_disabled':True,
          'android_whole_device_and_injected_path_refused':True,
          'android_duplicate_data_fstab_refused_without_source_change':True,
          'fydeos_four_dynamic_numbers_and_inactive_slots_mapped':True,
          'fydeos_both_native_partition_namespaces_relocated':True,
          'fydeos_exact_published_dictionary_fixture_relocated':True,
          'fydeos_actual_raw_root_ext2_preserved':True,
          'fydeos_whole_disk_expansion_powerwash_install_entrypoints_blocked':True,
          'legacy_fydeos_application_payload_downloads_excluded':True,
          'physical_boot_tested':False,'completed_unix':time.time()}
        report=BASE/('hook-actual-published-ramdisk-report.json' if options.source_boot else 'hook-fixture-report.json')
        temporary=report.with_suffix('.new.json')
        temporary.write_text(json.dumps(out,indent=2)+'\n');temporary.replace(report)
        print(json.dumps(out,indent=2))
    finally:
        shutil.rmtree(fixture)

if __name__=='__main__':main()
