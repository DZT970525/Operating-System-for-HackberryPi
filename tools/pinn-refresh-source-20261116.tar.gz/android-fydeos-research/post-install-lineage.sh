#!/bin/sh
# SPDX-License-Identifier: MIT
# Candidate post-install hook for the measured public Android17 five-FS layout.
# Run only AFTER the common receiver verified/wrote all four raw payloads.
# Generic receiver supplies part1..part5, PINN_BOOT_MOUNT and PINN_MANIFEST.
# Mapping: boot(FAT), system(ext4), vendor(ext4), metadata(ext4), userdata(ext4).
set -eu
umask 077

hb_die() { echo "LineageOS PINN: $*" >&2; exit 1; }
hb_android_path() {
    printf '%s\n' "$1" | grep -Eq '^/dev/(mmcblk[0-9]+p[0-9]+|sd[a-z]+[0-9]+|nvme[0-9]+n[0-9]+p[0-9]+)$' ||
        hb_die "Unexpected partition device"
    printf '/dev/block/%s\n' "$(basename "$1")"
}
hb_patch_data_fstab() {
    f=$1; dev=$2
    [ -f "$f" ] && [ ! -L "$f" ] || hb_die "Missing regular Android fstab: $f"
    awk -v dev="$dev" '
      /^[[:space:]]*#/ || NF==0 { print; next }
      $2=="/data" {
        if ($3!="ext4" || NF!=5) exit 21
        $1=dev; count++
      }
      { print }
      END { if(count!=1) exit 22 }
    ' "$f" > "$f.pinn-new" || { rm -f "$f.pinn-new"; hb_die "Unexpected /data fstab"; }
    # Preserve the original inode, mode, owner and security.selinux xattr.
    cat "$f.pinn-new" > "$f" && rm -f "$f.pinn-new"
}
hb_patch_ramdisk() {
    boot=$1; data_dev=$2; scratch=$3
    [ -s "$boot/ramdisk.img" ] || hb_die "Missing Android boot ramdisk"
    command -v cpio >/dev/null && cpio --version 2>&1 | grep -q 'GNU cpio' ||
        hb_die "GNU cpio wrapper is required (BusyBox extract-only cpio is insufficient)"
    mkdir -p "$scratch/ramdisk"
    gzip -dc "$boot/ramdisk.img" > "$scratch/ramdisk.cpio" || hb_die "Invalid gzip ramdisk"
    cpio --quiet -it < "$scratch/ramdisk.cpio" > "$scratch/ramdisk-list" ||
        hb_die "Invalid ramdisk CPIO"
    # The archive is already pinned by the verified source-image payload.
    # Refuse absolute and parent-traversal members before any extraction.
    if grep -Eq '(^/|(^|/)\.\.(/|$))' "$scratch/ramdisk-list"; then
        hb_die "Unsafe ramdisk member"
    fi
    (cd "$scratch/ramdisk"; cpio --quiet -idmu --no-absolute-filenames < "$scratch/ramdisk.cpio") ||
        hb_die "Cannot unpack ramdisk"
    hb_patch_data_fstab "$scratch/ramdisk/fstab.rpi5" "$data_dev"
    # Separate stages so a failed archive command cannot be hidden by gzip.
    (cd "$scratch/ramdisk"; find . ! -path . -print0 | cpio --quiet --null --reproducible -o -H newc > "$scratch/ramdisk-new.cpio") ||
        hb_die "Cannot rebuild ramdisk CPIO"
    gzip -n -6 -c "$scratch/ramdisk-new.cpio" > "$boot/ramdisk.img.pinn-new" ||
        hb_die "Cannot compress rebuilt ramdisk"
    gzip -t "$boot/ramdisk.img.pinn-new" || hb_die "Rebuilt ramdisk failed validation"
    chmod 0644 "$boot/ramdisk.img.pinn-new"
    mv "$boot/ramdisk.img.pinn-new" "$boot/ramdisk.img"
}
hb_patch_android_config() {
    boot=$1; boot_dev=$2; system_dev=$3; vendor_dev=$4; metadata_dev=$5
    for name in config.txt config_user.txt; do
        f="$boot/$name"
        [ -f "$f" ] || hb_die "Missing $name"
        sed '/^[[:space:]]*dtoverlay=android-\(sdcard\|usb\|nvme\|pinn\)\([,[:space:]].*\)\?$/d;/^[[:space:]]*dtparam=\(boot_dev\|system_dev\|vendor_dev\|metadata_dev\)=/d' \
            "$f" > "$f.pinn-new"
        cat "$f.pinn-new" > "$f"; rm -f "$f.pinn-new"
    done
    [ -s "$boot/overlays/android-pinn.dtbo" ] || hb_die "Missing precompiled parameterized DTBO"
    # Keep each firmware line below 80 characters. Params must immediately
    # follow their overlay, before any other overlay changes parameter scope.
    {
        printf '\n[all]\n# PINN allocated partition map; generated at install.\n'
        printf 'dtoverlay=android-pinn\n'
        printf 'dtparam=boot_dev=%s\n' "$boot_dev"
        printf 'dtparam=system_dev=%s\n' "$system_dev"
        printf 'dtparam=vendor_dev=%s\n' "$vendor_dev"
        printf 'dtparam=metadata_dev=%s\n' "$metadata_dev"
    } >> "$boot/config_user.txt"
    # The Android kernel's measured default is 32 MMC minors. Twelve systems
    # can use partition numbers above31; request64 before MMC disk discovery.
    awk 'NR==1 {
      for(i=1;i<=NF;i++)
        if($i !~ /^mmcblk[.]perdev_minors=/ && $i !~ /^androidboot[.]hackberry_pinn=/)
          printf "%s ",$i
      print "mmcblk.perdev_minors=64 androidboot.hackberry_pinn=1"
      next
    } NF { exit 23 }' "$boot/cmdline.txt" > "$boot/cmdline.txt.pinn-new" ||
        hb_die "Unexpected multiline cmdline"
    mv "$boot/cmdline.txt.pinn-new" "$boot/cmdline.txt"
}
hb_disable_android_native_recovery() {
    vendor=$1; boot=$2
    f="$vendor/bin/rpi-recovery.sh"
    [ -f "$f" ] && [ ! -L "$f" ] || hb_die "Missing stock recovery-switch script"
    if ! grep -q 'HB_PINN_RECOVERY_DISABLED' "$f"; then
        awk 'NR==1 {print; print "# HB_PINN_RECOVERY_DISABLED: recovery/OTA assumes the stock whole-disk map."; print "echo \"Use PINN to reinstall or upgrade this multiboot edition.\" >&2"; print "exit 1"; next} {print}' \
            "$f" > "$f.pinn-new"
        cat "$f.pinn-new" > "$f"; rm -f "$f.pinn-new"
    fi
    if [ -f "$boot/ramdisk-recovery.img" ]; then
        [ ! -e "$boot/ramdisk-recovery.img.pinn-disabled" ] ||
            hb_die "Unexpected duplicate disabled recovery ramdisk"
        mv "$boot/ramdisk-recovery.img" "$boot/ramdisk-recovery.img.pinn-disabled"
    fi
    # The preexisting init.*.rc loader imports all /vendor/etc/init/*.rc files.
    # Disable only the stock whole-image OTA client, after PackageManager is
    # available. User applications and the factory display/battery setup stay.
    cat > "$vendor/bin/hackberrypi-pinn-no-ota.sh" <<'HB_OTA'
#!/system/bin/sh
if /system/bin/pm path org.lineageos.updater >/dev/null 2>&1; then
    /system/bin/timeout -s TERM -k 2 20 /system/bin/pm disable-user --user 0 org.lineageos.updater
fi
HB_OTA
    chmod 0755 "$vendor/bin/hackberrypi-pinn-no-ota.sh"
    cat > "$vendor/etc/init/init.hackberrypi-pinn.rc" <<'HB_RC'
on property:sys.boot_completed=1
    start hackberrypi-pinn-no-ota

service hackberrypi-pinn-no-ota /system/bin/sh /vendor/bin/hackberrypi-pinn-no-ota.sh
    class late_start
    user root
    group system
    disabled
    oneshot
HB_RC
    chmod 0644 "$vendor/etc/init/init.hackberrypi-pinn.rc"
}
hb_android_fsck() {
    rc=0; e2fsck -f -p "$1" || rc=$?
    [ "$rc" -le 1 ] || hb_die "Filesystem check failed: $1 ($rc)"
}

if [ "${HB_PINN_FUNCTIONS_ONLY:-0}" = 1 ]; then
    return 0 2>/dev/null || exit 0
fi

[ "$(id -u)" = 0 ] || hb_die "Must run in PINN as root"
: "${part1:?}" "${part2:?}" "${part3:?}" "${part4:?}" "${part5:?}" "${PINN_BOOT_MOUNT:?}"
boot=$PINN_BOOT_MOUNT
[ "$(pwd -P)" = "$boot" ] || hb_die "Hook working directory is not the supplied boot mount"
boot_parent=
seen=' '
for p in "$part1" "$part2" "$part3" "$part4" "$part5"; do
    hb_android_path "$p" >/dev/null
    [ -b "$p" ] || hb_die "Not a partition block device"
    n=$(basename "$p")
    [ -f "/sys/class/block/$n/partition" ] || hb_die "Whole-disk device refused"
    nr=$(cat "/sys/class/block/$n/partition")
    [ "$nr" -ge 6 ] || hb_die "Refusing PINN recovery/settings/primary partition"
    parent=$(dirname "$(readlink -f "/sys/class/block/$n")")
    [ -n "$boot_parent" ] || boot_parent=$parent
    [ "$parent" = "$boot_parent" ] || hb_die "Partitions are on different drives"
    case "$seen" in *" $n "*) hb_die "Duplicate partition";; esac
    seen="$seen$n "
done
awk -v p="$part1" -v m="$boot" '$1==p && $2==m {found=1} END {exit !found}' /proc/mounts ||
    hb_die "PINN boot mount identity mismatch"
for p in "$part2" "$part3" "$part4" "$part5"; do
    if awk -v p="$p" '$1==p {found=1} END {exit !found}' /proc/mounts; then
        hb_die "Raw payload partition is already mounted"
    fi
    hb_android_fsck "$p"
done
# Grow only the filesystem inside PINN's already allocated userdata partition.
# Never run parted, cgpt, sfdisk or any whole-drive expansion routine.
resize2fs "$part5" || hb_die "Cannot grow allocated userdata filesystem"
hb_android_fsck "$part5"
scratch=$(mktemp -d /tmp/hb-lineage-pinn.XXXXXX)
vendor="$scratch/vendor"
mounted=0
cleanup() {
    if [ "$mounted" = 1 ]; then umount "$vendor" || return 1; fi
    rm -rf "$scratch"
}
trap 'rc=$?; trap - EXIT HUP INT TERM; cleanup || rc=1; exit "$rc"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir "$vendor"
mount -t ext4 -o rw,nosuid,nodev "$part3" "$vendor" || hb_die "Cannot mount own vendor partition"
mounted=1
data_dev=$(hb_android_path "$part5")
hb_patch_data_fstab "$vendor/etc/fstab.rpi5" "$data_dev"
hb_patch_ramdisk "$boot" "$data_dev" "$scratch"
hb_patch_android_config "$boot" "$(hb_android_path "$part1")" "$(hb_android_path "$part2")" \
    "$(hb_android_path "$part3")" "$(hb_android_path "$part4")"
hb_disable_android_native_recovery "$vendor" "$boot"
mkdir -p "$vendor/etc/hackberrypi-pinn"
printf '%s\n' "boot=$part1" "system=$part2" "vendor=$part3" "metadata=$part4" "userdata=$part5" \
    > "$vendor/etc/hackberrypi-pinn/partition-map"
sync
umount "$vendor" || hb_die "Cannot unmount own vendor partition"
mounted=0
hb_android_fsck "$part3"
trap - EXIT HUP INT TERM
rm -rf "$scratch"
echo "LineageOS PINN five-partition relocation complete."
