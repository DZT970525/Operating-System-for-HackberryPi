#!/bin/sh
# Latest FydeOS23 RAW-preserving four-partition PINN posthook.
# Candidate. Common receiver already verified/wrote ROOT/STATE/OEM.
# No legacy application supplement is downloaded by this adapter.
set -eu
choose_id() { case "$1" in PARTUUID=*) printf '%s\n' "$1";; '') printf '%s\n' "$2";; *) printf 'PARTUUID=%s\n' "$1";; esac; }
part_number() {
 case "$1" in /dev/mmcblk*p[0-9]*|/dev/sd*[0-9]*|/dev/nvme*n*p[0-9]*) n=${1##*[!0-9]};; *) echo 'PINN must supply a real partition path' >&2; return 1;; esac
 case "$n" in ''|0|*[!0-9]*) return 1;; esac
 printf '%s\n' "$n"
}
patch_root() {
 root=$1;boot=$2;root_id=$3;boot_id=$4;bn=$5;rn=$6;sn=$7;on=$8
 sed "s@root=[^ ][^ ]*@root=$root_id@g;s@rootfstype=[^ ][^ ]*@rootfstype=ext2@g" "$boot/cmdline.txt" > "$boot/cmdline.txt.pinn-new"
 mv "$boot/cmdline.txt.pinn-new" "$boot/cmdline.txt"
 # Both dictionaries are consumed by the native C++ startup program.
 j="$root/usr/sbin/partition_vars.json"
 for pair in "STATE:$sn" "ROOT_A:$rn" "OEM:$on" "EFI_SYSTEM:$bn" 'ROOT_B:0' 'ROOT_C:0' 'KERN_A:0' 'KERN_B:0' 'KERN_C:0' 'RWFW:0' 'RESERVED:0'; do
  key=${pair%:*};val=${pair#*:}
  sed "s/\"PARTITION_NUM_$key\"[[:space:]]*:[[:space:]]*\"[0-9][0-9]*\"/\"PARTITION_NUM_$key\": \"$val\"/g" "$j" > "$j.new";cat "$j.new" > "$j";rm -f "$j.new"
  if [ -f "$root/usr/sbin/write_gpt.sh" ]; then
   sed "s/PARTITION_NUM_$key=\"[0-9][0-9]*\"/PARTITION_NUM_$key=\"$val\"/g" "$root/usr/sbin/write_gpt.sh" > "$root/usr/sbin/write_gpt.sh.new";cat "$root/usr/sbin/write_gpt.sh.new" > "$root/usr/sbin/write_gpt.sh";rm -f "$root/usr/sbin/write_gpt.sh.new"
  fi
 done
 sed 's/"FS_FORMAT_ROOT_A"[[:space:]]*:[[:space:]]*"ext[24]"/"FS_FORMAT_ROOT_A": "ext2"/g' "$j" > "$j.new"
 cat "$j.new" > "$j";rm -f "$j.new"
 sed 's/FS_FORMAT_ROOT_A="ext[24]"/FS_FORMAT_ROOT_A="ext2"/g' "$root/usr/sbin/write_gpt.sh" > "$root/usr/sbin/write_gpt.sh.new"
 cat "$root/usr/sbin/write_gpt.sh.new" > "$root/usr/sbin/write_gpt.sh";rm -f "$root/usr/sbin/write_gpt.sh.new"
 printf '%s\t/\text2\tro\t0 0\n' "$root_id" > "$root/etc/fstab"
 printf '%s\t/mnt/boot\tvfat\tnoauto,ro\t0 0\n' "$boot_id" >> "$root/etc/fstab"
 mkdir -p "$root/usr/share/hackberry-pinn/original-jobs"
 for job in auto-expand-partition boot-update-firmware os_install_service fwupdtool-update fydeos-scripts-updater; do
  file="$root/etc/init/$job.conf"
  if [ -f "$file" ] && [ ! -f "$root/usr/share/hackberry-pinn/original-jobs/$job.conf" ]; then cp "$file" "$root/usr/share/hackberry-pinn/original-jobs/$job.conf"; fi
  printf '%s\n' 'description "Disabled for PINN multiboot disk protection"' manual task 'exec /bin/false' > "$file"
 done
 # Prevent native whole-disk powerwash/installer paths from touching other OSes.
 for rel in sbin/clobber-state usr/sbin/clobber usr/sbin/chromeos-install usr/sbin/expand-partition.sh usr/sbin/update_kernel.sh usr/sbin/update_dtb.sh; do
  file="$root/$rel"
  if [ -f "$file" ] && [ ! -f "$file.pinn-disabled" ]; then mv "$file" "$file.pinn-disabled"; fi
  printf '%s\n' '#!/bin/sh' 'rm -f /mnt/stateful_partition/factory_install_reset 2>/dev/null || true' 'echo "This operation is disabled in the PINN edition. Reinstall this OS through PINN." >&2' 'exit 1' > "$file";chmod 755 "$file"
 done
 # Keep the genuine update-engine D-Bus API for the first-run wizard, but
 # direct its default checks to a loopback endpoint which never offers updates.
 mkdir -p "$root/usr/share/hackberry-pinn"
 cat > "$root/usr/share/hackberry-pinn/no-update-server.py" <<'PINN_PY'
#!/usr/bin/python3.11
"""Loopback-only no-update endpoint for the PINN edition's OOBE check."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from xml.etree import ElementTree as ET
class Handler(BaseHTTPRequestHandler):
 def do_POST(self):
  try:
   size=int(self.headers.get('Content-Length','0'))
   if not 0<size<=1048576:raise ValueError('size')
   request=ET.fromstring(self.rfile.read(size));response=ET.Element('response',{'protocol':'3.0','server':'pinn-no-update'})
   for app in request.iter():
    if app.tag.rsplit('}',1)[-1]=='app' and app.get('appid'):
     a=ET.SubElement(response,'app',{'appid':app.get('appid'),'status':'ok'});ET.SubElement(a,'updatecheck',{'status':'noupdate'});ET.SubElement(a,'ping',{'status':'ok'})
   data=ET.tostring(response,encoding='utf-8',xml_declaration=True);self.send_response(200);self.send_header('Content-Type','text/xml');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  except (ValueError,ET.ParseError):self.send_error(400)
 def log_message(self,*args):pass
if __name__=='__main__':HTTPServer(('127.0.0.1',18097),Handler).serve_forever()
PINN_PY
 cat > "$root/etc/init/hackberry-pinn-update-server.conf" <<'PINN_JOB'
description "PINN local no-update responder"
start on starting system-services
stop on stopping system-services
respawn
respawn limit 3 60
exec /usr/bin/python3.11 /usr/share/hackberry-pinn/no-update-server.py
PINN_JOB
 cat > "$root/etc/init/update-engine.override" <<'PINN_WAIT'
pre-start script
 start hackberry-pinn-update-server >/dev/null 2>&1 || true
 attempts=0
 while ! /usr/bin/python3.11 -c 'import socket; s=socket.create_connection(("127.0.0.1",18097),1); s.close()' >/dev/null 2>&1; do
  attempts=$((attempts+1))
  [ "$attempts" -lt 15 ] || exit 1
  sleep 1
 done
end script
PINN_WAIT
 sed 's@^CHROMEOS_AUSERVER=.*@CHROMEOS_AUSERVER=http://127.0.0.1:18097/service/update2@' "$root/etc/lsb-release" > "$root/etc/lsb-release.new"
 cat "$root/etc/lsb-release.new" > "$root/etc/lsb-release";rm -f "$root/etc/lsb-release.new"
}

fyde_die() { echo "FydeOS PINN: $*" >&2; exit 1; }
fyde_fsck() {
 rc=0; e2fsck -f -p "$1" || rc=$?
 [ "$rc" -le 1 ] || fyde_die "Filesystem check failed: $1 ($rc)"
}
fyde_partuuid() {
 case "$1" in PARTUUID=*) value=$1;; '') fyde_die "PINN did not supply a partition-table identity";; *) value="PARTUUID=$1";; esac
 printf '%s\n' "$value" | grep -Eq '^PARTUUID=[A-Fa-f0-9-]+$' || fyde_die "Invalid partition identity"
 printf '%s\n' "$value"
}
if [ "${HB_PINN_FUNCTIONS_ONLY:-0}" = 1 ]; then
 return 0 2>/dev/null || exit 0
fi
[ "$(id -u)" = 0 ] || fyde_die "Must run in PINN as root"
: "${part1:?}" "${part2:?}" "${part3:?}" "${part4:?}" "${partuuid1:?}" "${partuuid2:?}" "${PINN_BOOT_MOUNT:?}"
boot=$PINN_BOOT_MOUNT
[ "$(pwd -P)" = "$boot" ] || fyde_die "Boot working directory mismatch"
parent=
seen=' '
for p in "$part1" "$part2" "$part3" "$part4"; do
 printf '%s\n' "$p" | grep -Eq '^/dev/(mmcblk[0-9]+p[0-9]+|sd[a-z]+[0-9]+|nvme[0-9]+n[0-9]+p[0-9]+)$' || fyde_die "Invalid partition path"
 [ -b "$p" ] || fyde_die "Not a block partition"
 n=$(basename "$p")
 [ -f "/sys/class/block/$n/partition" ] || fyde_die "Whole-drive device refused"
 [ "$(cat "/sys/class/block/$n/partition")" -ge 6 ] || fyde_die "PINN recovery/settings partition refused"
 actual_parent=$(dirname "$(readlink -f "/sys/class/block/$n")")
 [ -n "$parent" ] || parent=$actual_parent
 [ "$parent" = "$actual_parent" ] || fyde_die "Cross-drive installation refused"
 case "$seen" in *" $n "*) fyde_die "Duplicate partition";; esac
 seen="$seen$n "
done
awk -v p="$part1" -v m="$boot" '$1==p && $2==m {found=1} END {exit !found}' /proc/mounts || fyde_die "Boot mount identity mismatch"
for p in "$part2" "$part3" "$part4"; do
 if awk -v p="$p" '$1==p {found=1} END {exit !found}' /proc/mounts; then fyde_die "Raw partition already mounted"; fi
 fyde_fsck "$p"
done
# Only enlarge STATE inside PINN's already allocated part3.
resize2fs "$part3" || fyde_die "Cannot grow allocated STATE filesystem"
fyde_fsck "$part3"
bn=$(part_number "$part1"); rn=$(part_number "$part2")
sn=$(part_number "$part3"); on=$(part_number "$part4")
root_id=$(fyde_partuuid "$partuuid2")
boot_id=$(fyde_partuuid "$partuuid1")
scratch=$(mktemp -d /tmp/hb-fydeos-pinn.XXXXXX)
root="$scratch/root"
mounted=0
cleanup() {
 if [ "$mounted" = 1 ]; then umount "$root" || return 1; fi
 rm -rf "$scratch"
}
trap 'rc=$?; trap - EXIT HUP INT TERM; cleanup || rc=1; exit "$rc"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir "$root"
mount -t ext2 -o rw,nosuid,nodev "$part2" "$root" || fyde_die "Cannot mount actual RAW ext2 root"
mounted=1
[ -f "$root/usr/sbin/partition_vars.json" ] && [ -f "$root/usr/sbin/write_gpt.sh" ] || fyde_die "Missing native FydeOS partition dictionaries"
for key in STATE ROOT_A OEM EFI_SYSTEM; do
 grep -q "\"PARTITION_NUM_$key\"" "$root/usr/sbin/partition_vars.json" || fyde_die "Missing native partition key: $key"
done
patch_root "$root" "$boot" "$root_id" "$boot_id" "$bn" "$rn" "$sn" "$on"
# Boot-confirmation has no A/B GPT slot here. Preserve its caller contract
# while preventing GPT flag updates on the MBR multiboot disk.
for rel in usr/sbin/chromeos-setgoodkernel usr/bin/chromeos-setgoodkernel; do
 file="$root/$rel"
 if [ -f "$file" ]; then
  [ -f "$file.pinn-disabled" ] || cp -p "$file" "$file.pinn-disabled"
  printf '%s\n' '#!/bin/sh' '# PINN single-active-slot edition: no GPT flags to mark.' 'exit 0' > "$file"
  chmod 0755 "$file"
 fi
done
awk 'NR==1 {
 for(i=1;i<=NF;i++) if($i !~ /^mmcblk[.]perdev_minors=/) printf "%s ",$i
 print "mmcblk.perdev_minors=64"; next
} NF {exit 23}' "$boot/cmdline.txt" > "$boot/cmdline.txt.pinn-new" || fyde_die "Unexpected cmdline"
mv "$boot/cmdline.txt.pinn-new" "$boot/cmdline.txt"
printf '%s\n' "boot=$part1" "root=$part2" "state=$part3" "oem=$part4" \
 > "$root/usr/share/hackberry-pinn/partition-map"
sync
umount "$root" || fyde_die "Cannot unmount own root partition"
mounted=0
fyde_fsck "$part2"
trap - EXIT HUP INT TERM
rm -rf "$scratch"
echo "FydeOS PINN relocation complete; native whole-disk OTA/Powerwash disabled."
