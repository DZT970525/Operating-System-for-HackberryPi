# Android17 and FydeOS23 PINN adapters

These are candidate native multiboot adapters, checked offline; no physical PINN installation/boot is claimed. The whole-card source images are the existing sanitized public releases. The receiver writes only PINN allocated nonboot partitions and validates all source/payload hashes before calling these hooks.

## API for the conversion worker

- `plans/lineageos.json` and `plans/fydeos.json` are portable schema1 plans. `LineageOS.json`/`FydeOS.json` are identical naming aliases.
- Import `build-preparation.py` and call `prepare_boot(sources.family, boot_stage_directory)` with family `LineageOS` or `FydeOS`.
- The common payload generator installs its verified raw-part receiver and hashes the final post-hook bytes. Use the staged post-hook prepared below; do not recopy the unadjusted template.
- For **FydeOS only**, mount verified source p3 ext2 and p1 ext4 read-only (`ro,noload` for journaled STATE). Call `preflight('FydeOS', ROOT_mount, STATE_mount, boot_stage)` **after prepare_boot copies the reviewed hook, but before the common payload generator binds its SHA256**. It validates native partition dictionaries, seven active Display Scale1.2 file hashes, and a source-supplied AArch64 Python interpreter/loader and HTTP/socket/XML stdlib. It resolves `/usr/local` through preserved STATE/dev_image, and rewrites the staged no-update bridge to an existing `/usr/bin` or `/usr/local/bin` interpreter. It downloads no runtime. Read the adjusted staged hook, verify the returned post_hook_sha256, and pass those bytes into the common generator so its HB_POST_INSTALL_SHA256 matches. Do not overwrite it with the unadjusted template. `pinn/fydeos-preflight.json` records the binding.
- Preflight is static source resolution, not ARM runtime execution or OOBE validation. Absence of a complete matching source runtime aborts instead of installing old runtime/application archives.

Package only source/API assets: `build-preparation.py`, `post-install-lineage.sh`, `post-install-fydeos.sh`, `android-pinn.dtbo`, `android-pinn-overlay.dts`, `fydeos-scale-binding.json`, and selected JSON plans. For the initial CI unit gate also include test-hooks.py, test-preflight.py and fixture-data/scale-root (seven small public files). Research source boot extracts and fixture logs are local audit artifacts, not required payloads. The temporary128MiB boot filesystem inspection copy has been removed.

## LineageOS24 / Android17

The real source DOS layout has boot p1, system p5, vendor p6, metadata p7 and userdata p3; p2 is only the extended container. Build five PINN filesystems in boot/system/vendor/metadata/userdata order. The first boot payload must be **FAT filesystem tar**, because PINN calls partition_setup only when its first filesystem type contains `fat`. Other four payloads can be raw filesystem images, preserving Android SELinux xattrs, ownership, inode size and factory clean data.

The precompiled DT overlay has four Raspberry Pi string parameters for actual boot/system/vendor/metadata device paths, with invalid default paths so an omitted mapping fails closed. Firmware handles these overrides; PINN runtime dtc is unnecessary. The hook patches the `/data` path in both vendor and the actual published13-entry gzip/newc boot ramdisk. Runtime GNU cpio is required; original PINN BusyBox cpio cannot create archives. Repacking excludes a new `.` CPIO entry to avoid importing a temporary directory mode0700 as Android root permissions.

Userdata is resized only inside PINN's already allocated fifth partition. Native stock whole-disk OTA/recovery assumes fixed partition numbers; this edition disables the stock recovery switch, preserves its recovery ramdisk under a disabled filename, and disables only the stock OTA client after Android boots. Reinstall/upgrade using PINN. Existing battery, scale, native QS, Firefox, Termux and Neofetch provisioning remain in the copied vendor/system payloads.

## FydeOS23 / Display Scale1.2

Extract latest standalone source p12(FAT), p3(ROOT-A ext2), p1(STATE ext4) and p8(OEM ext4), in that PINN order. Keep the **actual raw ROOT-A ext2 type**; the old PINN preview changed it to ext4 only because it recreated a filesystem from tar. Preserve clean STATE system seeds and empty OEM from the public source. Older hbf_apps/runtime/share downloads are excluded, so they cannot revert the newer scaling integration.

The posthook maps native partition dictionaries to the four PINN numbers, disables unused GPT/A-B slots, whole-disk expansion, Powerwash, disk installer, firmware and OTA update entry points, and retains the native update-engine D-Bus/OOBE path using a loopback no-update responder. Only the allocated STATE filesystem grows; its partition table is not altered. Native whole-disk OTA/A-B rollback is not part of this edition.

## Shared constraints and completed checks

Use actual `/dev/...pN` part parameters (`use_partuuid=false` for these SD-only adapters), retaining separately supplied `partuuidN`. Blank raw placeholders give temporary `idN=UUID=`; ignore these IDs. PINN installed_os.json records actual partition paths, not those temporary filesystem IDs. Hook failure makes PINN mark the OS nonbootable.

Twelve installations may exceed partition31. The measured Android kernel defaults to CONFIG_MMC_BLOCK_MINORS=32; add `mmcblk.perdev_minors=64` to PINN and each OS kernel command line. The exact Android kernel source explicitly sets MODULE_PARAM_PREFIX to `mmcblk.`.

`hook-fixture-report.json`: genuine published ramdisk ownership/modes/device nodes and other file contents preserved, both data fstabs relocated, repeated config has one overlay, high partition mapping works, duplicate fstab and whole-device paths refused, Fyde dictionary/ext2/whole-drive protection and no legacy payload download verified. `preflight-fixture-report.json`: missing runtime, missing socket extension and changed scale files fail; existing STATE runtime fallback, source virtual symlinks and repeated static preflight pass. `public-lineage-boot-manifest.json` binds extracted files to a freshly rehashed public compressed image.

Primary references:

- https://github.com/procount/pinn/wiki/JSON-fields
- https://github.com/procount/pinn/blob/master/recovery/multiimagewritethread.cpp
- https://github.com/procount/pinn/issues/842 (older four-part Android example; actual current image has five filesystems)
- https://www.raspberrypi.com/documentation/computers/configuration.html (string overlay parameters)
- https://github.com/raspberry-vanilla/android_kernel_brcm_rpi/blob/1bc0869a3e521e36b5802396b193e9012a8a0015/drivers/mmc/core/block.c
