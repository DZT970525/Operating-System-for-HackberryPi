#!/usr/bin/env python3
import lzma,pathlib,runpy,json,hashlib,time
b=pathlib.Path('work/pinn-refresh-20261116/android-fydeos-research').resolve(); src=pathlib.Path('/media/zitaotech/SSD/HackberryPi-LineageOS-Publication-20261116/LineageOS-24.0-Android17-HackberryPi-CM5-DisplayScale-Neofetch-20261116.img.xz'); target=b/'boot-preview.img'; count=128*1024**2
with lzma.open(src,'rb') as f:
 f.seek(2048*512)
 with target.open('wb') as o:
  while count:
   data=f.read(min(count,1024**2)); assert data; o.write(data);count-=len(data)
g=runpy.run_path('work/lineage-install/extract-preview-fat.py',run_name='research_import_only');g['main'].__globals__.update(BASE=b,OUT=b/'public-lineage-boot',WANTED=['config.txt','config_user.txt','cmdline.txt','ramdisk.img','overlays/android-sdcard.dtbo','overlays/android-usb.dtbo','overlays/android-nvme.dtbo']);g['main']()
