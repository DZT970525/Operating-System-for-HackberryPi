/* Native display scaling shared by the privileged app page and worker.
 * Loading this file registers no events and changes no display settings. */
(() => {
  "use strict";

  const WORKSPACE_KEY = "display_scale_workspace_v1";
  const MINIMUM = 640;
  const MAXIMUM = 1080;
  const DEFAULT_WORKSPACE = 900;
  const NATIVE = 720;
  let tail = Promise.resolve();

  function enqueue(operation) {
    const result = tail.then(operation);
    tail = result.catch(() => {});
    return result;
  }

  function api(object, method, ...args) {
    return new Promise((resolve, reject) => {
      if (!object || typeof object[method] !== "function") {
        reject(new Error(`The FydeOS ${method} API is unavailable.`));
        return;
      }
      let finished = false;
      const timeout = setTimeout(() => finish(new Error(`FydeOS ${method} did not respond.`)), 8000);
      function finish(error, value) {
        if (finished) return;
        finished = true;
        clearTimeout(timeout);
        if (error) reject(error); else resolve(value);
      }
      try {
        object[method](...args, value => {
          const error = chrome.runtime.lastError;
          finish(error ? new Error(error.message || String(error)) : null, value);
        });
      } catch (error) {
        finish(error);
      }
    });
  }

  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const validWorkspace = value => Number.isInteger(value) && value >= MINIMUM && value <= MAXIMUM;
  const nativeMode = mode => mode && mode.widthInNativePixels === NATIVE && mode.heightInNativePixels === NATIVE;
  function notReady(message) {
    const error = new Error(message);
    error.displayNotReady = true;
    return error;
  }

  async function savedSetting() {
    const values = await api(chrome.storage.local, "get", WORKSPACE_KEY);
    const present = Object.prototype.hasOwnProperty.call(values, WORKSPACE_KEY);
    return {present, raw: values[WORKSPACE_KEY], workspace: validWorkspace(values[WORKSPACE_KEY]) ? values[WORKSPACE_KEY] : DEFAULT_WORKSPACE};
  }

  async function panelInfo() {
    const displays = await api(chrome.system.display, "getInfo");
    if (!Array.isArray(displays)) throw notReady("FydeOS returned invalid display information.");
    const candidates = displays.filter(display => display.isEnabled !== false && display.activeState !== "inactive" && !display.isUnified &&
      Array.isArray(display.modes) && (display.modes.some(mode => nativeMode(mode) && mode.isNative) ||
        // A fixed RP1 DPI panel may have no EDID/preferred-mode marker.
        (display.modes.length === 1 && nativeMode(display.modes[0]) && display.modes[0].isSelected !== false)));
    let display;
    if (candidates.length === 1) display = candidates[0];
    else {
      const touch = candidates.filter(item => item.hasTouchSupport);
      const primary = candidates.filter(item => item.isPrimary);
      if (touch.length === 1) display = touch[0];
      else if (primary.length === 1) display = primary[0];
    }
    if (!display) {
      if (candidates.length > 1) throw new Error("More than one 720 × 720 display was found. Make the HackberryPi screen primary and try again.");
      throw notReady("The native 720 × 720 HackberryPi display was not found. Other monitors will not be changed.");
    }
    const selected = display.modes.find(mode => mode.isSelected) || (display.modes.length === 1 ? display.modes[0] : null);
    if (!selected) throw notReady("FydeOS has not reported the active display mode yet.");
    if (!nativeMode(selected)) throw new Error("The HackberryPi panel is not using its native 720 × 720 mode. Select its native mode in Display settings first.");
    const dsf = selected.deviceScaleFactor;
    if (!Number.isFinite(dsf) || dsf <= 0 || !Number.isFinite(display.displayZoomFactor) || display.displayZoomFactor <= 0 ||
        !display.bounds || !Number.isInteger(display.bounds.width) || !Number.isInteger(display.bounds.height)) {
      throw notReady("FydeOS did not report usable native display scale information.");
    }
    return {display, baseWidth: NATIVE / dsf};
  }

  function stateFor(panel, desiredWorkspace) {
    return {
      workspace: panel.display.bounds.width,
      desiredWorkspace,
      minimum: MINIMUM,
      maximum: MAXIMUM,
      nativeWidth: NATIVE,
      nativeHeight: NATIVE,
      defaultWorkspace: DEFAULT_WORKSPACE,
      displayName: panel.display.name || "HackberryPi 720 × 720"
    };
  }

  async function getState() {
    const setting = await savedSetting();
    return stateFor(await panelInfo(), setting.workspace);
  }

  async function readApplied(id, target) {
    let last;
    for (let attempt = 0; attempt < 5; attempt++) {
      if (attempt) await delay(60);
      last = await panelInfo();
      if (last.display.id !== id) throw new Error("The active HackberryPi display changed while applying the scale.");
      if (Math.abs(last.display.bounds.width - target) <= 1 && Math.abs(last.display.bounds.height - target) <= 1) return last;
    }
    throw new Error(`FydeOS did not apply the requested ${target} × ${target} workspace (reported ${last.display.bounds.width} × ${last.display.bounds.height}).`);
  }

  async function applyWorkspace(workspace, persist, setting) {
    if (!validWorkspace(workspace)) throw new Error(`Choose a whole-number workspace from ${MINIMUM} to ${MAXIMUM}.`);
    const before = await panelInfo();
    const id = before.display.id;
    const oldZoom = before.display.displayZoomFactor;
    let displayMayHaveChanged = false;
    let persistenceAttempted = false;
    try {
      // Use native mode metadata, not rounded current bounds, to avoid drift.
      displayMayHaveChanged = true;
      await api(chrome.system.display, "setDisplayProperties", id, {displayZoomFactor: before.baseWidth / workspace});
      const applied = await readApplied(id, workspace);
      if (persist) {
        persistenceAttempted = true;
        await api(chrome.storage.local, "set", {[WORKSPACE_KEY]: workspace});
      }
      return stateFor(applied, workspace);
    } catch (error) {
      const recovery = [];
      if (displayMayHaveChanged) {
        try {
          let current = await panelInfo();
          const restored = panel => panel.display.id === id && Math.abs(panel.display.bounds.width - before.display.bounds.width) <= 1 &&
            Math.abs(panel.display.bounds.height - before.display.bounds.height) <= 1;
          if (!restored(current)) {
            await api(chrome.system.display, "setDisplayProperties", id, {displayZoomFactor: oldZoom});
            current = await panelInfo();
          }
          if (!restored(current)) throw new Error("Previous scale did not return.");
        } catch (_) {
          recovery.push("The previous display scale could not be restored automatically.");
        }
      }
      if (persistenceAttempted) {
        try {
          if (setting.present) await api(chrome.storage.local, "set", {[WORKSPACE_KEY]: setting.raw});
          else await api(chrome.storage.local, "remove", WORKSPACE_KEY);
        } catch (_) {
          recovery.push("Saved settings could not be restored; check Display Scale after restarting.");
        }
      }
      throw new Error(`Display scale was not saved: ${error.message || error}${recovery.length ? " " + recovery.join(" ") : " The previous setting was kept."}`);
    }
  }

  async function restoreWorkspace() {
    const setting = await savedSetting();
    return applyWorkspace(setting.workspace, !validWorkspace(setting.raw), setting);
  }

  async function restoreWhenReady() {
    for (let attempt = 0; attempt < 3; attempt++) {
      try { return await restoreWorkspace(); }
      catch (error) {
        if (!error.displayNotReady || attempt === 2) throw error;
        await delay(300);
      }
    }
  }

  async function setWorkspace(workspace) {
    const setting = await savedSetting();
    return applyWorkspace(workspace, true, setting);
  }

  globalThis.HBDisplayScale = Object.freeze({
    getState: () => enqueue(getState),
    setWorkspace: workspace => enqueue(() => setWorkspace(workspace)),
    restoreWhenReady: () => enqueue(restoreWhenReady)
  });
})();

/* Background-only adapter. Keep event registration synchronous at worker start. */
(() => {
  "use strict";
  let restoring = null;

  function core() {
    if (!globalThis.HBDisplayScale) throw new Error("The native Display Scale controls did not load.");
    return globalThis.HBDisplayScale;
  }

  function reply(sendResponse, result) {
    try { sendResponse(result); } catch (_) { /* The requesting page closed. */ }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || (message.type !== "HB_DISPLAY_GET" && message.type !== "HB_DISPLAY_SET")) return false;
    if (!sender || sender.id !== chrome.runtime.id) {
      reply(sendResponse, {ok: false, error: "Only the local Display Scale app can access this setting."});
      return false;
    }
    Promise.resolve().then(() => message.type === "HB_DISPLAY_GET"
      ? core().getState() : core().setWorkspace(message.workspace))
      .then(state => reply(sendResponse, {ok: true, state}),
        error => reply(sendResponse, {ok: false, error: error.message || String(error)}));
    return true;
  });

  function restore() {
    if (restoring) return restoring;
    restoring = Promise.resolve().then(() => core().restoreWhenReady())
      .catch(error => console.error("HACKBERRY_DISPLAY_SCALE_STARTUP " + (error.message || error)))
      .finally(() => { restoring = null; });
    return restoring;
  }

  chrome.runtime.onStartup.addListener(restore);
  restore();
})();

// Existing ChatGPT shelf setup, preserved.
"use strict";
const APP_ID = "cadlkienfkclaiaibeoongdcgmdikeeg";
function call(api, ...args) {
 return new Promise((resolve, reject) => api(...args, value => {
  const error = chrome.runtime.lastError;
  if (error) reject(new Error(error.message)); else resolve(value);
 }));
}
async function setup() {
 try {
  if ((await chrome.storage.local.get("completed_v1")).completed_v1) return;
  for (let attempt=0; attempt<36; attempt++) {
   try {
    if (!chrome.autotestPrivate) throw new Error("Shelf API unavailable");
    await call(chrome.autotestPrivate.setShelfIconPin, [{appId:APP_ID,pinned:true}]);
    const items = await call(chrome.autotestPrivate.getShelfItems);
    if (!items.some(item => item.appId===APP_ID && item.type==="PinnedApp"))
     throw new Error("ChatGPT pin not yet visible");
    const displays=await call(chrome.system.display.getInfo);
    for (const display of displays) {
     await call(chrome.autotestPrivate.setShelfAutoHideBehavior,display.id,"never");
     await call(chrome.autotestPrivate.setShelfAlignment,display.id,"Bottom");
    }
    await chrome.storage.local.set({completed_v1:true});
    console.error("HACKBERRY_SHELF_SETUP ChatGPT pinned and shelf always visible; verified");
    return;
   } catch (error) {
    console.error("HACKBERRY_SHELF_SETUP retry " + attempt + ": " + error.message);
    await new Promise(resolve => setTimeout(resolve,5000));
   }
  }
 } catch (error) {console.error("HACKBERRY_SHELF_SETUP failed: " + error.message);}
}
setup();
