(() => {
  "use strict";

  const byId = id => document.getElementById(id);
  const slider = byId("scale");
  const value = byId("workspace");
  const current = byId("current");
  const currentLabel = byId("current-label");
  const defaultButton = byId("default");
  const nativeButton = byId("native");
  const retryButton = byId("retry");
  const status = byId("status");
  let state = null;
  let pending = false;
  let confirmed = false;

  function showStatus(message, kind) {
    status.textContent = message;
    status.dataset.kind = kind;
  }

  function preview(workspace) {
    value.textContent = `${workspace} × ${workspace}`;
    slider.setAttribute("aria-valuetext", `${workspace} by ${workspace} desktop workspace`);
  }

  function setBusy(busy) {
    pending = busy;
    slider.disabled = busy || !state;
    defaultButton.disabled = busy || !state;
    nativeButton.disabled = busy || !state;
    retryButton.disabled = busy;
    document.body.setAttribute("aria-busy", String(busy));
  }

  function readResponse(response) {
    if (!response || response.ok !== true) {
      throw new Error(response && typeof response.error === "string" ? response.error : "Display controls did not respond. Try again.");
    }
    const next = response.state;
    if (!next || !Number.isInteger(next.workspace) || !Number.isInteger(next.minimum) ||
        !Number.isInteger(next.maximum) || next.minimum < 640 || next.maximum > 1080 ||
        next.minimum > next.maximum || next.workspace <= 0 || next.workspace > 8192 ||
        next.nativeWidth !== 720 || next.nativeHeight !== 720) {
      throw new Error("The display returned invalid scaling information. Try again.");
    }
    return next;
  }

  async function request(message) {
    const controls = globalThis.HBDisplayScale;
    if (!controls || typeof controls.getState !== "function" || typeof controls.setWorkspace !== "function") {
      throw new Error("Local display controls did not load. Close this window and open Display Scale again.");
    }
    if (typeof chrome === "undefined" || !chrome.system || !chrome.system.display ||
        typeof chrome.system.display.setDisplayProperties !== "function") {
      throw new Error("The native FydeOS display API is unavailable in this window. Open the installed Display Scale extension.");
    }
    const next = message.type === "HB_DISPLAY_GET" ? await controls.getState() : await controls.setWorkspace(message.workspace);
    return readResponse({ ok: true, state: next });
  }

  function sliderWorkspace(next) {
    if (next.workspace >= next.minimum && next.workspace <= next.maximum) return next.workspace;
    if (Number.isInteger(next.desiredWorkspace) && next.desiredWorkspace >= next.minimum && next.desiredWorkspace <= next.maximum) return next.desiredWorkspace;
    return Math.min(next.maximum, Math.max(next.minimum, next.workspace));
  }

  function render(next) {
    state = next;
    confirmed = true;
    slider.min = String(next.minimum);
    slider.max = String(next.maximum);
    const selection = sliderWorkspace(next);
    slider.value = String(selection);
    preview(selection);
    currentLabel.textContent = "Current workspace";
    current.textContent = `${next.workspace} × ${next.workspace}`;
    retryButton.hidden = true;
  }

  async function perform(message, desired) {
    if (pending) return;
    const restoreFocus = document.activeElement;
    setBusy(true);
    showStatus(message.type === "HB_DISPLAY_GET" ? "Reading display settings…" : `Applying ${desired} × ${desired}…`, "working");
    try {
      const next = await request(message);
      render(next);
      if (next.workspace < next.minimum || next.workspace > next.maximum) {
        showStatus(`Current size is outside ${next.minimum}–${next.maximum}. Choose a size or restore Default 900.`, "ready");
      } else {
        showStatus(message.type === "HB_DISPLAY_GET" ? "Ready. Changes are saved for your next login." : `Saved · ${next.workspace} × ${next.workspace}`, message.type === "HB_DISPLAY_GET" ? "ready" : "success");
      }
    } catch (error) {
      confirmed = false;
      currentLabel.textContent = state ? "Last confirmed workspace" : "Current workspace";
      if (!state) current.textContent = "Unavailable";
      else { const selection = sliderWorkspace(state); slider.value = String(selection); preview(selection); }
      const detail = error instanceof Error ? error.message : "Display controls are unavailable.";
      showStatus(detail.slice(0, 240), "error");
      retryButton.hidden = false;
    } finally {
      setBusy(false);
      if (!confirmed) {
        slider.disabled = true;
        defaultButton.disabled = true;
        nativeButton.disabled = true;
      }
      if (restoreFocus && restoreFocus !== document.body && !restoreFocus.disabled && restoreFocus.isConnected) {
        restoreFocus.focus({ preventScroll: true });
      }
    }
  }

  function apply(workspace) {
    if (!state || !confirmed || pending || !Number.isInteger(workspace) || workspace < state.minimum || workspace > state.maximum) return;
    slider.value = String(workspace);
    preview(workspace);
    return perform({ type: "HB_DISPLAY_SET", workspace }, workspace);
  }

  slider.addEventListener("input", () => {
    if (!pending && confirmed) preview(Number(slider.value));
  });
  slider.addEventListener("change", () => apply(Number(slider.value)));
  defaultButton.addEventListener("click", () => apply(900));
  nativeButton.addEventListener("click", () => apply(720));
  retryButton.addEventListener("click", () => perform({ type: "HB_DISPLAY_GET" }));
  perform({ type: "HB_DISPLAY_GET" });
})();
