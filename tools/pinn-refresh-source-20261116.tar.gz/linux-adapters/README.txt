HackberryPi native PINN raw payload receiver and Linux relocation
================================================================

This candidate implementation never opens an SD card on the build computer.
Local tests use disposable ordinary files. Production writes happen only when
PINN invokes partition_setup with its allocated logical partN block devices.

Files and interfaces
--------------------
plans/{ubuntu,fedora,arch,dietpi,buildroot,twisteros}.json:
  Parent converter input: first FAT source partition, raw source partitions,
  desired filesystem allocation, post-install path and special boot transform.
  Filesystem UUIDs of every raw payload MUST remain those in profiles.json.

profiles.json:
  Audited published-image layouts, whole-image checksums, original filesystem
  UUIDs, source offsets/lengths and minimum nominal sizes. Sourceid twisteros
  corresponds to Linux profileid twister.

render_linux_post.py --os-id PROFILE --output NEW_FILE:
  Emits the OS-specific POSIX post hook. Pre-rendered hooks are under generated/.
  No runtime target binary is executed from the offline root.

generate_payload.py --manifest PAYLOAD_JSON --post-install POST_SH --output NEW_DIR:
  Strict schema1 validator and renderer. Output contents belong under boot/pinn.
  Also copy its partition_setup.sh to the PINN metadata release directory, so
  PINN downloads/invokes that exact script. The first FAT tar must include all
  the generated pinn/ files and any OS-specific boot-transform markers.

Schema1 input partitions are ordered slots2..N. Each requires:
  slot, label, filesystem, raw_bytes, raw_sha256, compressed_sha256, codec,
  parts:[{name,url,bytes,sha256}]. codec is xz or gzip. Each chunk is <=149000000B.
  Source image identity is source.sha256. All chunks for one filesystem must be
  immutable plain filenames under one release of the user's exact repository.

Runtime uses generated payload-vars.sh and ASCII SHA tables, not a JSON parser.
  The vars file defines HB_OS_ID, HB_POST_INSTALL_SHA256, and hb_payload_rows().
  Each row is slot|label|codec|rawbytes|rawsha|compressedsha|base|manifestrel|sha.
  PINN idN='UUID=' for the initial raw stub is deliberately ignored.

raw-payload-common.sh is embedded into the generated partition_setup.sh.
  hb_write_raw TARGET ROLE CODEC RAW_BYTES RAW_SHA COMP_SHA BASE_URL
               MANIFEST_FILE MANIFEST_SHA PACKAGE_DIR
  HB_BOOT_DEVICE must be the assigned first FAT part1. Targets must be block
  partitions numbered>=6, distinct from FAT, unmounted, on the same disk, and
  large enough. Entire disks and normal primary p1/p2 are refused.

  One verified 128/149MB chunk is held at a time, normally in /tmp. Optional
  HB_DOWNLOAD_PARENT may name an explicitly mounted scratch folder. Streaming
  FIFO stages independently hash compressed/raw data, decode and dd ONLY the
  allocated partition. All child exit statuses are checked; decoder CRC/EOF
  failure cannot be hidden by a successful downstream writer. Cleanup removes
  only this receiver's mktemp directories and processes. Corrupted downloads
  abort PINN installation and never produce a success marker.

After all raw writes, partition_setup executes boot/pinn/post-install.sh with
the original PINN partN/partuuidN environment plus PINN_BOOT_MOUNT and
PINN_MANIFEST. Android/FydeOS may supply their own post hook with the same API.
Raw packages do not advertise PINN backup restoration yet.

Linux post hook behavior
-------------------------
* Verify original filesystem UUID, run e2fsck, resize2fs only within its already
  allocated partition, then mount root nodev/nosuid/noexec for file edits.
* Patch root and first FAT fstab mappings to actual assigned PARTUUIDs. Fedora
  retains three partitions; its separate /boot is also relocated.
* Rewrite all first-FAT cmdline.txt files, including Fedora nested active slot.
  Preserve driver arguments, require one root, reject custom init/rdinit and
  add mmcblk.perdev_minors=64 for large multiboot layouts.
* Write through the existing fstab inode, retaining Fedora SELinux xattrs/ACLs.
* Disable only the standalone disk-growth helper/unit/marker and known native
  resize units. No partition table command or target chroot is used.
* Require the public root's empty machine-id and absent SSH host/random keys;
  retain native identity-generation services and Arch package-trust timer.
* Ubuntu must retain its already-disabled growroot and cloud account setup.

Fedora raw root UUID preservation keeps its existing dracut root identity valid.
Do not randomly recreate the root or /boot filesystems. Its active firmware
slot remains selected by hackberrypi/active.conf on the first FAT.

Buildroot boot transformation
-----------------------------
Its published /init is intentionally bound to the source standalone MBR. It
will NOT boot from PINN merely by changing fstab. Before making its boot tar:

  python3 patch_buildroot_initramfs.py --boot-dir WRITABLE_COPIED_FAT --report REPORT

The transformer accepts only published initrd SHA3c0db3ff710756ad2c64dcd846c8d09f3ad5ff3ecb532ed7c0c960e0fd35344e.
It changes only /init in the gzip/newc archive and proves all3252other entries
unchanged. The exact known-visible DPI/USB early-module sequence is preserved.
It writes pinn/buildroot-initrd-mode=generic-v1 only after verification.

New init parses root=PARTUUID=<PINNroot> and hbpinn.boot=PARTUUID=<PINNFAT>.
It validates same MBR identity, logical part numbers6..63, unique boot/root
pair, root minimum size, original preserved root filesystem UUID, and never
depends on BusyBox blkid supporting PARTUUID. It retains bounded early-I/O
logging, eudev startup/shutdown and all hardware payloads. The source-card
physical boot test does not establish this new adapter's physical boot result.

Verification and limitations
----------------------------
  python3 -B test_adapters.py
  HBPINN_TEST_SHELL='busybox sh' python3 -B test_adapters.py

Fixtures cover xz/gzip multichunk writes, rejected corrupt first chunks,
traversal, global checksum mismatch, decoder end truncation, cleanup, generator
input rejection, fstab inode preservation/duplicate rejection, cmdline mapping
and custom-init rejection, Buildroot logical relocation and ambiguous disks.

Heavy image conversion/repack and physical PINN installation are not performed
by these local tests. Parent CI must prove the measured source archive and
filesystem regions, perform the Buildroot repack, verify emitted metadata,
and publish every referenced asset before the catalog is advertised.

Primary source for the MMC boot parameter spelling: Linux explicitly defines
MODULE_PARAM_PREFIX as mmcblk. and allows perdev_minors boot overrides:
https://github.com/torvalds/linux/blob/master/drivers/mmc/core/block.c
