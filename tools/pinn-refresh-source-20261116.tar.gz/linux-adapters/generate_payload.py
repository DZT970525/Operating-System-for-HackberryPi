#!/usr/bin/env python3
"""Render runtime-Python-free PINN raw receiver files from a measured manifest.

Input schema1 is data only. Every chunk URL must be a basename under one exact
immutable release of the owner's repository. No shell input is interpolated
unquoted. Generated files belong inside the first PINN FAT partition's `pinn/`.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex

HERE = Path(__file__).resolve().parent
BASE = 'https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(value):
    need(isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'Invalid SHA256')
    return value


def uint(value, maximum=2**53):
    need(type(value) is int and 0 < value <= maximum, 'Invalid positive bounded integer')
    return value


def safe_name(value):
    need(isinstance(value, str) and re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,179}', value), 'Unsafe filename')
    return value


def validate(manifest):
    need(isinstance(manifest, dict) and manifest.get('schema') == 1, 'Expected payload schema1')
    os_id = manifest.get('os_id')
    need(isinstance(os_id, str) and re.fullmatch('[a-z][a-z0-9_-]{0,39}', os_id), 'Unsafe OS id')
    need(isinstance(manifest.get('os_name'), str) and '\n' not in manifest['os_name'], 'Invalid OS name')
    digest(manifest['source']['sha256'])
    rows, tables = [], {}
    parts = manifest.get('partitions')
    need(isinstance(parts, list) and 1 <= len(parts) <= 15, 'Expected 1..15 raw partitions')
    for expected_slot, item in enumerate(parts, 2):
        need(item.get('slot') == expected_slot, 'Raw slots must be unique/ordered/contiguous from2')
        label = safe_name(item['label'])
        need(item['filesystem'] in ('ext2', 'ext4', 'raw', 'f2fs', 'erofs', 'squashfs'), 'Unexpected nonboot filesystem')
        raw_bytes = uint(item['raw_bytes'])
        need(raw_bytes % 512 == 0, 'Raw partition length must be sector aligned')
        digest(item['raw_sha256'])
        digest(item['compressed_sha256'])
        codec = item.get('codec', 'xz')
        need(codec in ('xz', 'gzip'), 'Expected xz/gzip codec')
        chunks = item.get('parts')
        need(isinstance(chunks, list) and chunks, 'Missing measured chunk list')
        names, base, lines = set(), None, []
        for chunk in chunks:
            name = safe_name(chunk['name'])
            need(name not in names, 'Duplicate chunk filename')
            names.add(name)
            size = uint(chunk['bytes'], 149000000)
            checksum = digest(chunk['sha256'])
            url = chunk['url']
            need(isinstance(url, str) and url.startswith(BASE), 'Unexpected payload URL')
            release, separator, basename = url[len(BASE):].partition('/')
            safe_name(release)
            need(separator and basename == name, 'URL must be a plain release/basename')
            current_base = BASE + release
            need(base in (None, current_base), 'One raw stream cannot span mutable release bases')
            base = current_base
            lines.append(f'{checksum} {size} {name}\n')
        content = ''.join(lines).encode('ascii')
        filename = f'payload-{expected_slot}-{label}.sha256'
        tables[filename] = content
        rows.append('|'.join(map(str, (expected_slot, label, codec, raw_bytes,
            item['raw_sha256'], item['compressed_sha256'], base,
            'pinn/' + filename, hashlib.sha256(content).hexdigest()))))
    return rows, tables


def render(manifest, post_script):
    rows, tables = validate(manifest)
    post_sha = hashlib.sha256(post_script).hexdigest()
    values = ('#!/bin/sh\n# Strict data generated from payload.json; no runtime JSON dependency.\n'
              + 'HB_OS_ID=' + shlex.quote(manifest['os_id']) + '\n'
              + 'HB_POST_INSTALL_SHA256=' + shlex.quote(post_sha) + '\n'
              + "hb_payload_rows() { cat <<'HBPINN_PAYLOAD_ROWS'\n"
              + '\n'.join(rows) + '\nHBPINN_PAYLOAD_ROWS\n}\n')
    entry = (HERE / 'partition_setup.sh').read_text()
    common = (HERE / 'raw-payload-common.sh').read_text()
    need(entry.count('# GENERATOR_INSERT_COMMON') == 1, 'Entry template changed')
    entry = entry.replace('# GENERATOR_INSERT_COMMON', common)
    return {**tables, 'payload.json': (json.dumps(manifest, indent=2) + '\n').encode(),
            'payload-vars.sh': values.encode(), 'post-install.sh': post_script,
            'partition_setup.sh': entry.encode()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--post-install', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='Fresh output directory (its contents go under boot/pinn)')
    args = parser.parse_args()
    need(args.manifest.is_file() and not args.manifest.is_symlink(), 'Ordinary manifest required')
    need(args.post_install.is_file() and not args.post_install.is_symlink(), 'Ordinary post hook required')
    result = render(json.loads(args.manifest.read_text()), args.post_install.read_bytes())
    args.output.mkdir(parents=True, exist_ok=False)
    report = {}
    for name, data in result.items():
        path = args.output / name
        path.write_bytes(data)
        path.chmod(0o755 if name.endswith('.sh') else 0o644)
        report[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    (args.output / 'receiver-render-report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': True, 'os_id': json.loads(args.manifest.read_text())['os_id'],
                      'files': report}, indent=2))


if __name__ == '__main__':
    main()
