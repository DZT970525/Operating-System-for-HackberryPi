#!/usr/bin/env python3
"""Render an OS-specific POSIX hook from audited immutable image profiles."""
import argparse
import json
from pathlib import Path
import shlex

HERE = Path(__file__).resolve().parent


def render(profile):
    values = {'OS_ID': profile['os_id'], 'ROOT_SLOT': profile['root_slot'],
              'BOOT_MOUNT': profile['boot_mount'],
              'SOURCE_ROOT_UUID': profile['source_root_uuid'],
              'SOURCE_AUX_UUID': profile.get('source_aux_uuid', ''),
              'BUILDROOT_INITRD': 'generic-v1' if profile['os_id'] == 'buildroot' else ''}
    text = (HERE / 'linux-post-install.sh').read_text()
    assert text.count('# GENERATOR_INSERT_PROFILE') == 1
    return text.replace('# GENERATOR_INSERT_PROFILE', '\n'.join(
        key + '=' + shlex.quote(str(value)) for key, value in values.items()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--os-id', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    profiles = json.loads((HERE / 'profiles.json').read_text())['profiles']
    profile = next(p for p in profiles if p['os_id'] == args.os_id)
    assert not args.output.exists()
    args.output.write_text(render(profile))
    args.output.chmod(0o755)


if __name__ == '__main__':
    main()
