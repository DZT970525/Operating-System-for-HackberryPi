#!/bin/sh
# Shared native PINN postinstall entry. The first FAT archive carries pinn/*.
set -eu
umask 022

# GENERATOR_INSERT_COMMON

PINN_BOOT_MOUNT=$(pwd -P)
PINN_MANIFEST=$PINN_BOOT_MOUNT/pinn/payload.json
export PINN_BOOT_MOUNT PINN_MANIFEST
: "${part1:?PINN boot partition missing}"
HB_BOOT_DEVICE=$part1
export HB_BOOT_DEVICE
hb_vars=$PINN_BOOT_MOUNT/pinn/payload-vars.sh
[ -f "$hb_vars" ] && [ ! -L "$hb_vars" ] || { hb_fail 'PINN payload variables are missing'; exit 1; }
# This strictly generated shell table is part of the SHA-256-verified boot tar.
. "$hb_vars"
case "$HB_OS_ID" in ''|*[!a-z0-9_-]*) exit 1;; esac
hb_post=$PINN_BOOT_MOUNT/pinn/post-install.sh
hb_require_sha "$hb_post" "$HB_POST_INSTALL_SHA256"
if [ "${restore:-false}" = true ]; then
    hb_fail 'Raw-image PINN backup restoration is not advertised by this package'; exit 1
fi
hb_rows=$(mktemp /tmp/hbpinn-rows.XXXXXX)
trap 'rm -f "$hb_rows"' EXIT HUP INT TERM
hb_payload_rows > "$hb_rows"
while IFS='|' read -r hb_slot hb_label hb_codec hb_bytes hb_raw_sha hb_comp_sha hb_base hb_manifest_rel hb_manifest_sha hb_extra; do
    [ -z "${hb_extra:-}" ] || exit 1
    case "$hb_slot" in
        2) hb_target=${part2:?};; 3) hb_target=${part3:?};; 4) hb_target=${part4:?};;
        5) hb_target=${part5:?};; 6) hb_target=${part6:?};; 7) hb_target=${part7:?};;
        8) hb_target=${part8:?};; 9) hb_target=${part9:?};; 10) hb_target=${part10:?};;
        11) hb_target=${part11:?};; 12) hb_target=${part12:?};; 13) hb_target=${part13:?};;
        14) hb_target=${part14:?};; 15) hb_target=${part15:?};; 16) hb_target=${part16:?};;
        *) hb_fail 'Unexpected payload slot'; exit 1;;
    esac
    case "$hb_manifest_rel" in pinn/payload-[A-Za-z0-9_-]*.sha256) ;; *) exit 1;; esac
    hb_write_raw "$hb_target" "$hb_label" "$hb_codec" "$hb_bytes" "$hb_raw_sha" \
        "$hb_comp_sha" "$hb_base" "$PINN_BOOT_MOUNT/$hb_manifest_rel" "$hb_manifest_sha" "$PINN_BOOT_MOUNT/pinn"
done < "$hb_rows"
rm -f "$hb_rows"
trap - EXIT HUP INT TERM
exec /bin/sh "$hb_post"
