#!/bin/sh
# Shared PINN raw receiver. No filesystem or partition-table discovery writes.
# Include this file verbatim in partition_setup.sh; never download shell code.

hb_fail() { printf 'HackberryPi PINN: %s\n' "$*" >&2; return 1; }

hb_require_sha() {
    [ -f "$1" ] && [ ! -L "$1" ] || { hb_fail "Missing ordinary file: $1"; return 1; }
    case "$2" in ''|*[!0-9a-f]*) hb_fail 'Invalid SHA-256'; return 1;; esac
    [ "${#2}" -eq 64 ] || { hb_fail 'Invalid SHA-256 length'; return 1; }
    hb_got=$(sha256sum "$1") || return 1
    [ "${hb_got%% *}" = "$2" ] || { hb_fail "Checksum differs: $1"; return 1; }
}

hb_plain_uint() {
    case "$1" in ''|*[!0-9]*) return 1;; esac
    [ "${#1}" -le 16 ] && [ "$1" -gt 0 ]
}

hb_check_target() {
    # Only PINN-allocated logical partitions on the first assigned FAT's disk.
    # Rejecting primary partitions also prevents the host's ordinary p2 root.
    hb_target=$(readlink -f "$1") || return 1
    hb_boot=$(readlink -f "$2") || return 1
    [ -b "$hb_target" ] && [ -b "$hb_boot" ] && [ "$hb_target" != "$hb_boot" ] || {
        hb_fail 'Distinct assigned block partitions required'; return 1;
    }
    for hb_dev in "$hb_target" "$hb_boot"; do
        case "$hb_dev" in /dev/mmcblk[0-9]*p[0-9]*|/dev/sd[a-z][0-9]*|/dev/nvme[0-9]*n[0-9]*p[0-9]*) ;; *) hb_fail 'Unsupported assigned partition path'; return 1;; esac
        case "${hb_dev#/dev/}" in *[!A-Za-z0-9_-]*) return 1;; esac
        hb_sys=/sys/class/block/${hb_dev#/dev/}
        [ -f "$hb_sys/partition" ] || { hb_fail 'Whole disks are forbidden'; return 1; }
        hb_number=$(cat "$hb_sys/partition") || return 1
        hb_plain_uint "$hb_number" && [ "$hb_number" -ge 6 ] || {
            hb_fail 'PINN logical partition number must be at least 6'; return 1;
        }
    done
    hb_tsys=$(readlink -f "/sys/class/block/${hb_target#/dev/}") || return 1
    hb_bsys=$(readlink -f "/sys/class/block/${hb_boot#/dev/}") || return 1
    [ "${hb_tsys%/*}" = "${hb_bsys%/*}" ] || { hb_fail 'Assigned partitions are on different disks'; return 1; }
    hb_plain_uint "$3" || return 1
    hb_sectors=$(cat "/sys/class/block/${hb_target#/dev/}/size") || return 1
    hb_plain_uint "$hb_sectors" && [ "$((hb_sectors * 512))" -ge "$3" ] || {
        hb_fail 'Assigned partition is smaller than its verified raw image'; return 1;
    }
    while read -r hb_src hb_mount hb_rest; do
        case "$hb_src" in /dev/*) ;; *) continue;; esac
        hb_real=$(readlink -f "$hb_src" 2>/dev/null) || continue
        [ "$hb_real" != "$hb_target" ] || { hb_fail "Raw target is already mounted at $hb_mount"; return 1; }
    done < /proc/mounts
}

hb_stream_cleanup() {
    # All paths/PIDs below were created by this one receiver subprocess.
    trap - EXIT
    trap '' HUP INT TERM
    [ "${HB_INPUT_OPEN:-0}" = 0 ] || { exec 3>&-; HB_INPUT_OPEN=0; }
    for hb_pid in ${HB_STREAM_PIDS:-}; do kill "$hb_pid" 2>/dev/null || true; done
    # A shell child may still be blocked opening its FIFO redirection before
    # exec. A caught TERM can be deferred until that open completes. KILL is
    # therefore necessary before wait; otherwise an early rejected manifest
    # can deadlock cleanup while its peer never opens the other FIFO end.
    for hb_pid in ${HB_STREAM_PIDS:-}; do kill -KILL "$hb_pid" 2>/dev/null || true; done
    for hb_pid in ${HB_STREAM_PIDS:-}; do wait "$hb_pid" 2>/dev/null || true; done
    if [ -n "${HB_STREAM_WORK:-}" ]; then rm -rf "$HB_STREAM_WORK"; fi
    if [ -n "${HB_DOWNLOAD_WORK:-}" ]; then rm -rf "$HB_DOWNLOAD_WORK"; fi
}

hb_write_raw() (
    # TARGET ROLE CODEC RAW_BYTES RAW_SHA256 COMPRESSED_SHA256 BASE_URL
    # MANIFEST_FILE MANIFEST_SHA256 PACKAGE_DIR
    set -eu
    [ "$#" -eq 10 ] || { hb_fail 'Wrong raw receiver interface'; exit 1; }
    hb_out=$1; hb_role=$2; hb_codec=$3; hb_bytes=$4; hb_raw_sha=$5
    hb_comp_sha=$6; hb_base=$7; hb_manifest=$8; hb_manifest_sha=$9
    shift 9; hb_package=$1
    : "${HB_BOOT_DEVICE:?Assigned PINN boot partition required}"
    hb_check_target "$hb_out" "$HB_BOOT_DEVICE" "$hb_bytes"
    case "$hb_role" in ''|.*|-*|*[!A-Za-z0-9._-]*) hb_fail 'Unsafe payload label'; exit 1;; esac
    case "$hb_base" in https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/*) ;; *) hb_fail 'Unexpected immutable release base'; exit 1;; esac
    case "$hb_base" in *[\ \|\'\"\`\$\;\&\<\>\(\)\\]*|*/../*|*/./*|*/|*\?*|*\#*) hb_fail 'Unsafe release base'; exit 1;; esac
    case "$hb_codec" in xz|gzip) ;; *) hb_fail 'Unsupported compression'; exit 1;; esac
    for hb_hash in "$hb_raw_sha" "$hb_comp_sha"; do
        case "$hb_hash" in ''|*[!0-9a-f]*) exit 1;; esac
        [ "${#hb_hash}" -eq 64 ] || exit 1
    done
    hb_require_sha "$hb_manifest" "$hb_manifest_sha"
    HB_STREAM_PIDS=; HB_INPUT_OPEN=0; HB_STREAM_WORK=; HB_DOWNLOAD_WORK=
    trap 'hb_stream_cleanup' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM HUP
    umask 077
    HB_STREAM_WORK=$(mktemp -d "${TMPDIR:-/tmp}/hbpinn-stream.XXXXXX")
    # Chunks live on the target disk's free first FAT space only if explicitly
    # provided. Normal installations use /tmp with a single 128/149MB chunk;
    # the caller may set HB_DOWNLOAD_PARENT to another mounted storage folder.
    hb_download_parent=${HB_DOWNLOAD_PARENT:-/tmp}
    [ -d "$hb_download_parent" ] && [ ! -L "$hb_download_parent" ] || exit 1
    HB_DOWNLOAD_WORK=$(mktemp -d "$hb_download_parent/hbpinn-chunk.XXXXXX")
    hb_comp_in=$HB_STREAM_WORK/compressed.in
    hb_comp_hash_in=$HB_STREAM_WORK/compressed.hash.in
    hb_decode_in=$HB_STREAM_WORK/decode.in
    hb_raw_in=$HB_STREAM_WORK/raw.in
    hb_raw_hash_in=$HB_STREAM_WORK/raw.hash.in
    hb_write_in=$HB_STREAM_WORK/write.in
    mkfifo "$hb_comp_in" "$hb_comp_hash_in" "$hb_decode_in" "$hb_raw_in" "$hb_raw_hash_in" "$hb_write_in"
    sha256sum < "$hb_comp_hash_in" > "$HB_STREAM_WORK/compressed.sha" & hb_hc=$!; HB_STREAM_PIDS="$hb_hc"
    sha256sum < "$hb_raw_hash_in" > "$HB_STREAM_WORK/raw.sha" & hb_hr=$!; HB_STREAM_PIDS="$HB_STREAM_PIDS $hb_hr"
    dd if="$hb_write_in" of="$hb_out" bs=1048576 2> "$HB_STREAM_WORK/dd.log" & hb_dd=$!; HB_STREAM_PIDS="$HB_STREAM_PIDS $hb_dd"
    tee "$hb_raw_hash_in" < "$hb_raw_in" > "$hb_write_in" & hb_tr=$!; HB_STREAM_PIDS="$HB_STREAM_PIDS $hb_tr"
    if [ "$hb_codec" = xz ]; then
        xz -dc < "$hb_decode_in" > "$hb_raw_in" &
    else
        gzip -dc < "$hb_decode_in" > "$hb_raw_in" &
    fi
    hb_dc=$!; HB_STREAM_PIDS="$HB_STREAM_PIDS $hb_dc"
    tee "$hb_comp_hash_in" < "$hb_comp_in" > "$hb_decode_in" & hb_tc=$!; HB_STREAM_PIDS="$HB_STREAM_PIDS $hb_tc"
    exec 3> "$hb_comp_in"; HB_INPUT_OPEN=1
    hb_count=0; hb_total=0
    while read -r hb_expected hb_size hb_name hb_extra; do
        [ -n "$hb_expected$hb_size$hb_name${hb_extra:-}" ] || continue
        [ -z "${hb_extra:-}" ] || { hb_fail 'Unexpected manifest field'; exit 1; }
        case "$hb_name" in ''|.*|-*|*[!A-Za-z0-9._-]*) hb_fail 'Unsafe chunk filename'; exit 1;; esac
        hb_plain_uint "$hb_size" && [ "$hb_size" -le 149000000 ] || { hb_fail 'Chunk size outside bounded transport'; exit 1; }
        hb_chunk=$hb_package/$hb_name
        if [ ! -f "$hb_chunk" ] || [ -L "$hb_chunk" ]; then
            hb_chunk=$HB_DOWNLOAD_WORK/chunk
            rm -f "$hb_chunk"
            hb_attempt=0
            while :; do
                hb_attempt=$((hb_attempt + 1))
                # BusyBox has -T but no --tries/-t. GNU wget defaults to many
                # retries, so explicitly make its outer retry loop bounded.
                if wget --help 2>&1 | grep -q -- '--tries'; then
                    if wget -T 120 -t 1 -O "$hb_chunk" "$hb_base/$hb_name"; then break; fi
                else
                    if wget -T 120 -O "$hb_chunk" "$hb_base/$hb_name"; then break; fi
                fi
                [ "$hb_attempt" -lt 5 ] || { hb_fail "Download failed: $hb_name"; exit 1; }
                rm -f "$hb_chunk"
                sleep 2
            done
        fi
        [ "$(wc -c < "$hb_chunk" | tr -d ' ')" = "$hb_size" ] || { hb_fail "Chunk length differs: $hb_name"; exit 1; }
        hb_require_sha "$hb_chunk" "$hb_expected"
        hb_count=$((hb_count + 1)); hb_total=$((hb_total + hb_size))
        printf 'HackberryPi PINN: %s chunk %s verified (%s compressed bytes).\n' "$hb_role" "$hb_count" "$hb_total"
        cat "$hb_chunk" >&3
        [ "$hb_chunk" != "$HB_DOWNLOAD_WORK/chunk" ] || rm -f "$hb_chunk"
    done < "$hb_manifest"
    [ "$hb_count" -gt 0 ] || { hb_fail 'Empty transport manifest'; exit 1; }
    exec 3>&-; HB_INPUT_OPEN=0
    # POSIX pipelines expose only the final status. Wait for EVERY process so
    # decoder truncation/CRC failure cannot be mistaken for a valid dd result.
    hb_status=0
    while [ -n "$HB_STREAM_PIDS" ]; do
        hb_pid=${HB_STREAM_PIDS%% *}
        wait "$hb_pid" || hb_status=1
        case "$HB_STREAM_PIDS" in *' '*) HB_STREAM_PIDS=${HB_STREAM_PIDS#* };; *) HB_STREAM_PIDS=;; esac
    done
    [ "$hb_status" = 0 ] || { hb_fail 'Decoder, hasher or partition writer failed'; exit 1; }
    read -r hb_got hb_rest < "$HB_STREAM_WORK/compressed.sha"
    [ "$hb_got" = "$hb_comp_sha" ] || { hb_fail 'Complete compressed stream checksum differs'; exit 1; }
    read -r hb_got hb_rest < "$HB_STREAM_WORK/raw.sha"
    [ "$hb_got" = "$hb_raw_sha" ] || { hb_fail 'Complete raw filesystem checksum differs'; exit 1; }
    sync
    printf 'HackberryPi PINN: %s raw partition image written and SHA-256 verified.\n' "$hb_role"
)
