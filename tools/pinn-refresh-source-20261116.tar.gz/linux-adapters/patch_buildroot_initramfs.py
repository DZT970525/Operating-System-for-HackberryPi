#!/usr/bin/env python3
"""Relocate the exact tested Buildroot early-userspace to PINN logical partitions.

Only /init changes. All 3252 other newc entries and the known DPI/USB driver
ordering are retained byte-for-byte. Runtime uses BusyBox, not Python.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path

SOURCE_ARCHIVE_SHA256 = '3c0db3ff710756ad2c64dcd846c8d09f3ad5ff3ecb532ed7c0c960e0fd35344e'
SOURCE_INIT_SHA256 = 'a1849b91008e79d461a0bf509dd8b0b61de8cba5c787cfa3525650a9ef9317a1'
UNCHANGED_ENTRIES_SHA256 = '02a6053d3087163062004daaf57d5b4a5453346ec0739cd10c2ca1b2f1bd762e'

CMDLINE = r'''valid_pinn_id() {
    case "$1" in PARTUUID=????????-??) value=${1#PARTUUID=};; *) return 1;; esac
    case "${value%-??}${value#????????-}" in *[!0-9a-fA-F]*) return 1;; esac
}

valid_cmdline() {
    roots=0; boots=0; root_id=; boot_id=
    for argument in $1; do
        case "$argument" in
            root=*)
                root_id=${argument#root=}
                valid_pinn_id "$root_id" || return 1
                roots=$((roots + 1));;
            hbpinn.boot=*)
                boot_id=${argument#hbpinn.boot=}
                valid_pinn_id "$boot_id" || return 1
                boots=$((boots + 1));;
        esac
    done
    [ "$roots" -eq 1 ] && [ "$boots" -eq 1 ] || return 1
    root_value=$(printf '%s' "${root_id#PARTUUID=}" | tr A-F a-f)
    boot_value=$(printf '%s' "${boot_id#PARTUUID=}" | tr A-F a-f)
    PINN_MBR_ID=${boot_value%-??}
    [ "${root_value%-??}" = "$PINN_MBR_ID" ] || return 1
    root_hex=${root_value#????????-}; boot_hex=${boot_value#????????-}
    PINN_ROOT_PART=$((0x$root_hex)); PINN_BOOT_PART=$((0x$boot_hex))
    [ "$PINN_ROOT_PART" -ge 6 ] && [ "$PINN_ROOT_PART" -le 63 ] || return 1
    [ "$PINN_BOOT_PART" -ge 6 ] && [ "$PINN_BOOT_PART" -le 63 ] || return 1
    [ "$PINN_ROOT_PART" != "$PINN_BOOT_PART" ] || return 1
    byte1=${PINN_MBR_ID%??????}; tail=${PINN_MBR_ID#??}
    byte2=${tail%????}; tail=${tail#??}
    byte3=${tail%??}; byte4=${tail#??}
    PINN_MBR_LE=$byte4$byte3$byte2$byte1
}

'''

SELFTEST = r'''    valid_cmdline 'root=PARTUUID=12345678-07 hbpinn.boot=PARTUUID=12345678-06 rootfstype=ext4 rootwait rw' || exit 11
    valid_cmdline 'root=/dev/mmcblk0p7 hbpinn.boot=PARTUUID=12345678-06' && exit 12
    valid_cmdline 'root=PARTUUID=12345678-07 root=PARTUUID=12345678-07 hbpinn.boot=PARTUUID=12345678-06' && exit 13
    valid_cmdline 'console=tty1' && exit 14
    valid_cmdline 'root=PARTUUID=aaaaaaaa-07 hbpinn.boot=PARTUUID=12345678-06' && exit 15
'''

DISCOVERY = r'''discover_boot() {
    matches=0
    found_device=
    found_disk=
    for partition in /sys/class/block/*; do
        [ -f "$partition/partition" ] || continue
        [ "$(cat "$partition/partition")" = "$PINN_BOOT_PART" ] || continue
        [ "$(cat "$partition/size")" -ge 524288 ] 2>/dev/null || continue
        resolved=$(readlink -f "$partition") || continue
        disk_path=${resolved%/*}
        disk=${disk_path##*/}
        name=${partition##*/}
        operation "PINN MBR identity read: /dev/$disk"
        [ "$(od -An -tx1 -j440 -N4 "/dev/$disk" 2>/dev/null | tr -d ' \n')" = "$PINN_MBR_LE" ] || continue
        blkid "/dev/$name" 2>/dev/null | grep -F 'TYPE="vfat"' >/dev/null || continue
        matches=$((matches + 1))
        found_device=/dev/$name
        found_disk=$disk
    done
    [ "$matches" -eq 1 ] || return 1
    BOOT_DEVICE=$found_device
    BOOT_DISK=$found_disk
}

discover_root() {
    matches=0
    found_root=
    for partition in /sys/class/block/*; do
        [ -f "$partition/partition" ] || continue
        [ "$(cat "$partition/partition")" = "$PINN_ROOT_PART" ] || continue
        [ "$(cat "$partition/size")" -ge "$ROOT_SECTORS" ] 2>/dev/null || continue
        resolved=$(readlink -f "$partition") || continue
        disk_path=${resolved%/*}
        [ "${disk_path##*/}" = "$BOOT_DISK" ] || continue
        name=${partition##*/}
        probe_uuid "/dev/$name" "$ROOT_UUID" || continue
        matches=$((matches + 1))
        found_root=/dev/$name
    done
    [ "$matches" -eq 1 ] || return 1
    ROOT_DEVICE=$found_root
}

'''


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def patch_init(data):
    need(hashlib.sha256(data).hexdigest() == SOURCE_INIT_SHA256, 'Unrecognized public /init')
    text = data.decode('utf8')
    original_modules = next(s for s in text.splitlines() if s.startswith('MODULES='))
    hardware = text[text.index('# Exact v2 manual order'):text.index('UDEV_STARTED=1\nrun_bounded')]
    start = text.index('valid_cmdline() {')
    end = text.index('if [ "${1:-}" = --self-test ]; then', start)
    text = text[:start] + CMDLINE + text[end:]
    start = text.index("    valid_cmdline 'root=")
    end = text.index('    [ -r /lib/libc.so.6 ]', start)
    text = text[:start] + SELFTEST + text[end:]
    start = text.index('discover_boot() {')
    end = text.index('discover_pair_record() {', start)
    text = text[:start] + DISCOVERY + text[end:]
    text = text.replace('BOOT_UUID=F66B-4C89\n', '# FAT UUID is assigned by PINN; root UUID is retained by the raw payload.\n')
    text = text.replace('Buildroot initramfs v4 self-test passed', 'Buildroot PINN generic-v1 initramfs self-test passed')
    text = text.replace('Buildroot early boot v4: entered /init.', 'Buildroot PINN generic-v1: entered /init.')
    need(next(s for s in text.splitlines() if s.startswith('MODULES=')) == original_modules,
         'Early hardware module order changed')
    need(text[text.index('# Exact v2 manual order'):text.index('UDEV_STARTED=1\nrun_bounded')] == hardware,
         'Known visible DPI/USB bootstrap changed')
    need('root=PARTUUID=aadddfcb-02' not in text and '532480' not in text and 'cbdfddaa' not in text,
         'Standalone partition identity remains')
    return text.encode()


def exact(stream, count):
    data = stream.read(count)
    need(len(data) == count, 'Truncated newc archive')
    return data


def repack(source, destination):
    need(source.is_file() and not source.is_symlink(), 'Ordinary source initramfs required')
    with source.open('rb') as stream:
        need(hashlib.file_digest(stream, 'sha256').hexdigest() == SOURCE_ARCHIVE_SHA256,
             'Source archive is not the published Buildroot initramfs')
    need(not destination.exists() and not destination.is_symlink(), 'Fresh output initramfs required')
    count, changes = 0, []
    inventory = hashlib.sha256()
    with source.open('rb') as raw_in, destination.open('xb') as raw_out:
        with gzip.GzipFile(fileobj=raw_in, mode='rb') as src, gzip.GzipFile(
                filename='', fileobj=raw_out, mode='wb', mtime=0, compresslevel=1) as dst:
            while True:
                header = exact(src, 110)
                need(header[:6] == b'070701', 'Expected newc without CRC')
                fields = [int(header[6+i*8:14+i*8], 16) for i in range(13)]
                size, namesize = fields[6], fields[11]
                need(1 <= namesize <= 4096 and 0 <= size <= 32*1024**2, 'Unexpected newc entry bounds')
                name_raw = exact(src, namesize)
                need(name_raw[-1:] == b'\0', 'Missing archive name terminator')
                name = name_raw[:-1].decode()
                need(not name.startswith('/') and '..' not in Path(name).parts, 'Unsafe archive name')
                pad = exact(src, (-110-namesize) % 4)
                if name == 'init':
                    result = patch_init(exact(src, size))
                    exact(src, (-size) % 4)
                    fields[6] = len(result)
                    dst.write(b'070701' + b''.join(f'{n:08x}'.encode() for n in fields))
                    dst.write(name_raw + pad + result + b'\0' * ((-len(result)) % 4))
                    changes.append(name)
                else:
                    dst.write(header + name_raw + pad)
                    remain, member_sha = size, hashlib.sha256()
                    while remain:
                        block = exact(src, min(remain, 1024**2))
                        dst.write(block); member_sha.update(block); remain -= len(block)
                    dst.write(exact(src, (-size) % 4))
                    inventory.update(name_raw + header + member_sha.digest())
                if name == 'TRAILER!!!':
                    need(size == 0 and not src.read(1), 'Unexpected archive suffix')
                    break
                count += 1
    need(count == 3253 and changes == ['init'], 'Unexpected archive manifest changes')
    need(inventory.hexdigest() == UNCHANGED_ENTRIES_SHA256, 'A non-init archive entry changed')
    with destination.open('rb') as stream: checksum = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'passed': True, 'mode': 'generic-v1', 'source_sha256': SOURCE_ARCHIVE_SHA256,
            'archive_sha256': checksum, 'archive_bytes': destination.stat().st_size,
            'entries': count, 'changed_entries': changes,
            'unchanged_entries_sha256': inventory.hexdigest(),
            'early_dpi_usb_hardware_order_retained': True,
            'requires_cmdline': 'root=PARTUUID=<PINN-root> hbpinn.boot=PARTUUID=<PINN-FAT>',
            'raw_root_uuid_preserved': '2639ef2a-dd9f-49d4-985d-0f993c19068f'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, nargs='?')
    parser.add_argument('destination', type=Path, nargs='?')
    parser.add_argument('--boot-dir', type=Path, help='Transform a fresh writable copy of the published first FAT')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.boot_dir:
        need(args.source is None and args.destination is None, 'Choose boot-dir or explicit paths')
        source = args.boot_dir / 'initrd-buildroot.img'
        destination = args.boot_dir / 'initrd-buildroot.img.pinn-new'
        report = repack(source, destination)
        destination.chmod(source.stat().st_mode & 0o777)
        os.replace(destination, source)
        metadata = args.boot_dir / 'pinn'
        metadata.mkdir(exist_ok=True)
        marker = metadata / 'buildroot-initrd-mode'
        need(not marker.exists() and not marker.is_symlink(), 'Fresh Buildroot PINN marker required')
        marker.write_text('generic-v1\n')
        report['boot_transform_completed'] = True
    else:
        need(args.source is not None and args.destination is not None, 'Source and destination required')
        report = repack(args.source, args.destination)
    if args.report: args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__': main()
