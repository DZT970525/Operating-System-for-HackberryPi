#!/bin/sh
# Generic Linux PINN relocation. Does not run target binaries or change a table.
set -eu
umask 022
# GENERATOR_INSERT_PROFILE

fail() { printf 'HackberryPi %s PINN: %s\n' "$OS_ID" "$*" >&2; exit 1; }
safe_id() {
    case "$1" in PARTUUID=*) value=${1#PARTUUID=};; UUID=*) value=${1#UUID=};; *) return 1;; esac
    case "$value" in ''|*[!a-fA-F0-9-]*) return 1;; esac
    [ "${#value}" -ge 4 ] && [ "${#value}" -le 64 ]
}
actual_id() {
    value=$(blkid -s PARTUUID -o value "$1") || return 1
    safe_id "PARTUUID=$value" || return 1
    printf 'PARTUUID=%s\n' "$value"
}
inside_parent() {
    parent=$(readlink -f "$(dirname "$1")") || fail "Missing parent: $1"
    case "$parent/" in "$ROOT/"*) ;; *) fail "Path escapes allocated root: $1";; esac
}
remove_file() {
    inside_parent "$1"
    [ ! -d "$1" ] || [ -L "$1" ] || fail "Expected file, found directory: $1"
    rm -f "$1"
}
replace_preserving_inode() {
    # Keeping the target inode preserves Fedora's SELinux xattr and ACLs.
    [ -f "$1" ] && [ ! -L "$1" ] || fail "Ordinary file required: $1"
    cat "$2" > "$1"
    rm -f "$2"
}
patch_fstab() {
    file=$ROOT/etc/fstab
    inside_parent "$file"
    [ -f "$file" ] && [ ! -L "$file" ] || fail 'Native fstab missing or symlinked'
    temporary=$(mktemp "$file.pinn.XXXXXX")
    awk -v root="$ROOT_ID" -v first="$FAT_ID" -v second="$AUX_ID" -v boot="$BOOT_MOUNT" '
      BEGIN {OFS="\t";nr=0;nf=0;ns=0}
      /^[[:space:]]*#/ || NF==0 {print;next}
      NF<4 {exit 31}
      $2=="/" {$1=root;$3="ext4";nr++}
      $2==boot {$1=first;$3="vfat";nf++}
      second!="" && $2=="/boot" {$1=second;$3="ext4";ns++}
      {print}
      END {if(nr!=1 || nf!=1 || (second!="" && ns!=1))exit 32}
    ' "$file" > "$temporary" || { rm -f "$temporary"; fail 'Unexpected native fstab layout'; }
    replace_preserving_inode "$file" "$temporary"
}
patch_cmdline() {
    file=$1
    [ -f "$file" ] && [ ! -L "$file" ] || fail 'Ordinary firmware cmdline required'
    temporary=$(mktemp "$file.pinn.XXXXXX")
    awk -v root="$ROOT_ID" -v first="$FAT_ID" -v buildroot="$BUILDROOT_INITRD" '
      BEGIN {roots=0;types=0;lines=0;minors=0;boots=0;output=""}
      NF {lines++;for(i=1;i<=NF;i++){
        token=$i
        if(token ~ /^(init=|rdinit=|cryptdevice=|systemd.run=)/)exit 41
        if(token ~ /^root=/){token="root=" root;roots++}
        else if(token ~ /^rootfstype=/){token="rootfstype=ext4";types++}
        else if(token ~ /^mmcblk.perdev_minors=/){token="mmcblk.perdev_minors=64";minors++}
        else if(token ~ /^hbpinn.boot=/){token="hbpinn.boot=" first;boots++}
        else if(token ~ /^(resume=|resume_offset=)/)continue
        output=output (output==""?"":" ") token
      }}
      END {
        if(lines!=1 || roots!=1 || types>1 || minors>1 || boots>1)exit 42
        if(types==0)output=output " rootfstype=ext4"
        if(minors==0)output=output " mmcblk.perdev_minors=64"
        if(buildroot=="generic-v1" && boots==0)output=output " hbpinn.boot=" first
        print output
      }
    ' "$file" > "$temporary" || { rm -f "$temporary"; fail 'Unexpected firmware cmdline'; }
    replace_preserving_inode "$file" "$temporary"
}
disable_growth() {
    prefix=hackberrypi-$OS_ID-image-grow
    for rel in "usr/local/sbin/$prefix" "usr/local/bin/$prefix" \
        "etc/hackberrypi/$OS_ID-image-first-boot" \
        "etc/hackberrypi/$OS_ID-image-growth-state.json" \
        etc/hackberrypi/image-layout.json; do
        parent=$ROOT/$(dirname "$rel")
        [ -d "$parent" ] || continue
        remove_file "$ROOT/$rel"
    done
    for unit in "$prefix.service" resize2fs_once.service resize2fs.service growroot.service; do
        for target in multi-user.target.wants sysinit.target.wants local-fs.target.wants; do
            path=$ROOT/etc/systemd/system/$target/$unit
            [ -e "$path" ] || [ -L "$path" ] || continue
            remove_file "$path"
        done
        path=$ROOT/etc/systemd/system/$unit
        [ -e "$path" ] || [ -L "$path" ] || continue
        inside_parent "$path"
        if [ -L "$path" ]; then
            # A mask remains a mask. Any other symlink is replaced by a mask.
            remove_file "$path"
            ln -s /dev/null "$path"
        else
            [ -f "$path" ] || fail 'Unexpected resize unit type'
            printf '[Unit]\nDescription=Partition sizing belongs to PINN\n[Service]\nType=oneshot\nExecStart=/bin/true\n' > "$path"
        fi
    done
    if [ -d "$ROOT/etc/init.d" ]; then
        for rel in etc/init.d/resize2fs_once etc/init.d/S01resize etc/init.d/S01resize2fs; do
            [ -e "$ROOT/$rel" ] || [ -L "$ROOT/$rel" ] || continue
            remove_file "$ROOT/$rel"
        done
    fi
    # Ubuntu's native growroot module respects this existing image marker.
    if [ "$OS_ID" = ubuntu ]; then
        [ -f "$ROOT/etc/growroot-disabled" ] || fail 'Ubuntu native growroot must already be disabled'
        [ -f "$ROOT/etc/cloud/cloud-init.disabled" ] || fail 'Ubuntu cloud account provisioning must remain disabled'
    fi
}
check_fresh_identity() {
    if [ -e "$ROOT/etc/machine-id" ] || [ -L "$ROOT/etc/machine-id" ]; then
        [ -f "$ROOT/etc/machine-id" ] && [ ! -L "$ROOT/etc/machine-id" ] && [ ! -s "$ROOT/etc/machine-id" ] || fail 'Published machine identity is not empty'
    fi
    for path in "$ROOT"/etc/ssh/ssh_host_* "$ROOT"/var/lib/systemd/random-seed; do
        [ ! -e "$path" ] && [ ! -L "$path" ] || fail 'Private host identity unexpectedly present'
    done
    # Keep native identity-only units/markers and Arch package-trust timer.
    # They contain no block resize operation and run only after actual boot.
}
check_and_expand_ext4() {
    target=$1; expected=$2
    [ "$(blkid -s TYPE -o value "$target")" = ext4 ] || fail 'Expected ext4 raw filesystem'
    [ "$(blkid -s UUID -o value "$target")" = "$expected" ] || fail 'Raw filesystem UUID differs from measured source'
    set +e
    e2fsck -f -y "$target"
    status=$?
    set -e
    case "$status" in 0|1) ;; *) fail "Filesystem check failed: $status";; esac
    # Resize only this existing filesystem within its PINN-allocated partition.
    # No sfdisk/parted/growpart/blockdev partition-table mutation is permitted.
    resize2fs "$target" || fail 'Allocated filesystem expansion failed'
}

# END_FUNCTIONS: fixtures source only the functions above, never this main.
: "${PINN_BOOT_MOUNT:?PINN FAT mount missing}"
: "${part1:?PINN FAT partition missing}"
case "$ROOT_SLOT" in 2) ROOT_DEVICE=${part2:?};; 3) ROOT_DEVICE=${part3:?};; *) fail 'Unexpected root slot';; esac
FAT_ID=$(actual_id "$part1") || fail 'Cannot read allocated FAT PARTUUID'
ROOT_ID=$(actual_id "$ROOT_DEVICE") || fail 'Cannot read allocated root PARTUUID'
AUX_ID=
if [ "$ROOT_SLOT" = 3 ]; then
    AUX_ID=$(actual_id "${part2:?}") || fail 'Cannot read Fedora /boot PARTUUID'
    check_and_expand_ext4 "$part2" "$SOURCE_AUX_UUID"
fi
check_and_expand_ext4 "$ROOT_DEVICE" "$SOURCE_ROOT_UUID"
ROOT=$(mktemp -d /tmp/hbpinn-linuxroot.XXXXXX)
mounted=0
cleanup() { if [ "$mounted" = 1 ]; then umount "$ROOT" || true; fi; rmdir "$ROOT" 2>/dev/null || true; }
trap cleanup EXIT HUP INT TERM
mount -t ext4 -o rw,noatime,nodev,nosuid,noexec "$ROOT_DEVICE" "$ROOT" || fail 'Allocated root mount failed'
mounted=1
if [ "$BUILDROOT_INITRD" = generic-v1 ]; then
    [ "$(cat "$PINN_BOOT_MOUNT/pinn/buildroot-initrd-mode")" = generic-v1 ] || fail 'Buildroot relocatable initramfs proof missing'
fi
check_fresh_identity
patch_fstab
find "$PINN_BOOT_MOUNT" -type f -name cmdline.txt > "$ROOT/.pinn-cmdlines"
[ -s "$ROOT/.pinn-cmdlines" ] || fail 'No firmware cmdline found'
while IFS= read -r file; do patch_cmdline "$file"; done < "$ROOT/.pinn-cmdlines"
rm -f "$ROOT/.pinn-cmdlines"
disable_growth
inside_parent "$ROOT/etc/hackberrypi/pinn-installed"
printf '%s\n' "$OS_ID native PINN payload installed; partition allocation remains owned by PINN." > "$ROOT/etc/hackberrypi/pinn-installed"
sync
umount "$ROOT" || fail 'Allocated root failed to unmount'
mounted=0
rmdir "$ROOT"
trap - EXIT HUP INT TERM
printf 'HackberryPi %s PINN: relocation complete.\n' "$OS_ID"
