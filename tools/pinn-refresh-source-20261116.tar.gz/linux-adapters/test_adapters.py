#!/usr/bin/env python3
"""Disposable files only: integrity, cleanup and relocation rejection fixtures."""
import gzip
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
SHELL = shlex.split(os.environ.get('HBPINN_TEST_SHELL', '/bin/sh'))


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


gen = load('payload_generator', 'generate_payload.py')
post = load('post_generator', 'render_linux_post.py')
buildroot_init = load('buildroot_init', 'patch_buildroot_initramfs.py')


def sha(value):
    return hashlib.sha256(value).hexdigest()


class ReceiverFixtures(unittest.TestCase):
    def run_receiver(self, codec='xz', corruption=None):
        with tempfile.TemporaryDirectory(prefix='hbpinn-fixture-') as directory:
            root = Path(directory)
            package = root / 'package'; package.mkdir()
            download = root / 'download'; download.mkdir()
            stream = root / 'stream'; stream.mkdir()
            sink = root / 'allocated-partition.fixture'; sink.touch()
            marker = root / 'installed.fixture'
            raw = bytes(range(256)) * 128
            compressed = lzma.compress(raw, preset=0) if codec == 'xz' else gzip.compress(raw, mtime=0)
            if corruption == 'truncated-decoder':
                compressed = compressed[:-9]
            chunks = [compressed[i:i+61] for i in range(0, len(compressed), 61)]
            lines = []
            for i, data in enumerate(chunks, 1):
                name = f'root.img.{codec}.part{i:02}'
                (package / name).write_bytes(data)
                lines.append(f'{sha(data)} {len(data)} {name}\n')
            if corruption == 'chunk':
                first = package / lines[0].split()[2]
                first.write_bytes(b'X' + first.read_bytes()[1:])
            if corruption == 'path-traversal':
                lines[0] = lines[0].replace(lines[0].split()[2], '../../outside')
            manifest = root / 'payload.sha256'
            manifest.write_text(''.join(lines))
            args = [str(sink), 'root', codec, str(len(raw)),
                    '0'*64 if corruption == 'raw-sha' else sha(raw),
                    '0'*64 if corruption == 'compressed-sha' else sha(compressed),
                    'https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/fixture',
                    str(manifest), sha(manifest.read_bytes()), str(package)]
            script = ('set -eu\n. ' + shlex.quote(str(HERE/'raw-payload-common.sh')) + '\n'
                      # Override only the device guard inside this disposable
                      # test process. Production source contains no test mode.
                      + 'hb_check_target() { test -f "$1"; case "$1" in '
                      + shlex.quote(directory) + '/*) ;; *) return 1;; esac; }\n'
                      + 'HB_BOOT_DEVICE=/dev/disposable-fixture\n'
                      + 'HB_DOWNLOAD_PARENT=' + shlex.quote(str(download)) + '\n'
                      + 'TMPDIR=' + shlex.quote(str(stream)) + '; export TMPDIR\n'
                      + 'hb_write_raw ' + ' '.join(map(shlex.quote, args)) + '\n'
                      + 'touch ' + shlex.quote(str(marker)) + '\n')
            result = subprocess.run(SHELL + ['-c', script], capture_output=True, text=True, timeout=20)
            self.assertEqual(list(stream.iterdir()), [], result.stderr)
            self.assertEqual(list(download.iterdir()), [], result.stderr)
            if corruption:
                self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertFalse(marker.exists())
                if corruption in ('chunk', 'path-traversal'):
                    self.assertEqual(sink.read_bytes(), b'')
            else:
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertEqual(sink.read_bytes(), raw)
                self.assertTrue(marker.exists())

    def test_valid_xz_multichunk(self): self.run_receiver()
    def test_valid_gzip_multichunk(self): self.run_receiver('gzip')
    def test_bad_first_chunk_writes_nothing(self): self.run_receiver(corruption='chunk')
    def test_path_traversal_rejected(self): self.run_receiver(corruption='path-traversal')
    def test_xz_end_truncation_not_masked_by_writer(self): self.run_receiver(corruption='truncated-decoder')
    def test_full_raw_sha_required(self): self.run_receiver(corruption='raw-sha')
    def test_full_compressed_sha_required(self): self.run_receiver(corruption='compressed-sha')


class GeneratorFixtures(unittest.TestCase):
    def plan(self):
        return {'schema': 1, 'os_id': 'fixture', 'os_name': 'Disposable fixture',
                'source': {'sha256': 'a'*64}, 'partitions': [{'slot': 2, 'label': 'root',
                'filesystem': 'ext4', 'raw_bytes': 32768, 'raw_sha256': 'b'*64,
                'compressed_sha256': 'c'*64, 'codec': 'xz', 'parts': [{'name': 'root.xz.part01',
                'url': gen.BASE+'fixture/root.xz.part01', 'bytes': 123, 'sha256': 'd'*64}]}]}

    def test_strict_render_is_syntax_valid(self):
        result = gen.render(self.plan(), b'#!/bin/sh\nexit 0\n')
        for name in ['partition_setup.sh', 'payload-vars.sh']:
            subprocess.run(SHELL + ['-n'], input=result[name], check=True)
        self.assertIn(b'hb_payload_rows()', result['payload-vars.sh'])
        self.assertNotIn(b'GENERATOR_INSERT_COMMON', result['partition_setup.sh'])

    def test_unsafe_inputs_rejected(self):
        for field, value in [('name', '../escape'), ('url', gen.BASE+'fixture/root.xz.part01?evil=1'),
                             ('bytes', 149000001), ('sha256', 'not-a-sha')]:
            plan = self.plan(); plan['partitions'][0]['parts'][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): gen.validate(plan)
        plan = self.plan(); plan['partitions'][0]['slot'] = 3
        with self.assertRaises(ValueError): gen.validate(plan)


class RelocationFixtures(unittest.TestCase):
    def run_post_functions(self, os_id, setup, command):
        profiles = json.loads((HERE/'profiles.json').read_text())['profiles']
        profile = next(p for p in profiles if p['os_id'] == os_id)
        functions = post.render(profile).split('# END_FUNCTIONS:')[0]
        with tempfile.TemporaryDirectory(prefix='hbpinn-relocation-') as directory:
            root = Path(directory)/'root'; boot = Path(directory)/'boot'
            root.mkdir(); boot.mkdir(); (root/'etc').mkdir()
            setup(root, boot)
            env = ('ROOT='+shlex.quote(str(root))+'\nROOT_ID=PARTUUID=12345678-07\n'
                   +'FAT_ID=PARTUUID=12345678-06\nAUX_ID='+('PARTUUID=12345678-08' if os_id=='fedora' else "''")+'\n')
            result = subprocess.run(SHELL + ['-c', functions+'\n'+env+command], capture_output=True,
                                    text=True, timeout=10)
            return result, {p.relative_to(directory).as_posix(): p.read_text() for p in Path(directory).rglob('*') if p.is_file()}

    def test_fstab_uuid_relocation_preserves_inode(self):
        def setup(root, boot):
            (root/'etc/fstab').write_text('UUID=oldroot / ext4 defaults 0 1\nUUID=oldboot /boot/firmware vfat defaults 0 2\nproc /proc proc defaults 0 0\n')
        result, files = self.run_post_functions('ubuntu', setup,
            'old=$(stat -c %i "$ROOT/etc/fstab"); patch_fstab; test "$old" = "$(stat -c %i "$ROOT/etc/fstab")"\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('PARTUUID=12345678-07\t/\text4', files['root/etc/fstab'])

    def test_duplicate_root_does_not_replace_fstab(self):
        value='UUID=old / ext4 defaults 0 1\nUUID=other / ext4 defaults 0 1\nUUID=boot /boot/firmware vfat defaults 0 2\n'
        result, files = self.run_post_functions('ubuntu', lambda r,b:(r/'etc/fstab').write_text(value), 'patch_fstab\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(files['root/etc/fstab'], value)

    def test_cmdline_mapping_adds_logical_minor_support(self):
        def setup(root, boot): (boot/'cmdline.txt').write_text('console=tty1 root=UUID=old rootfstype=ext4 rw rootwait\n')
        result, files = self.run_post_functions('twister', setup, 'patch_cmdline "'+str('')+'$ROOT/../boot/cmdline.txt"\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('root=PARTUUID=12345678-07', files['boot/cmdline.txt'])
        self.assertIn('mmcblk.perdev_minors=64', files['boot/cmdline.txt'])

    def test_custom_init_is_refused_without_rewriting(self):
        value='root=UUID=old init=/bad/custom-init\n'
        result, files = self.run_post_functions('ubuntu', lambda r,b:(b/'cmdline.txt').write_text(value), 'patch_cmdline "$ROOT/../boot/cmdline.txt"\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(files['boot/cmdline.txt'], value)


class BuildrootInitFixtures(unittest.TestCase):
    def parse(self, cmdline):
        script = buildroot_init.CMDLINE + '\nvalid_cmdline ' + shlex.quote(cmdline) + '\n'
        script = 'set -eu\n' + script + 'printf "%s %s %s\\n" "$PINN_BOOT_PART" "$PINN_ROOT_PART" "$PINN_MBR_LE"\n'
        return subprocess.run(SHELL + ['-c', script], capture_output=True, text=True, timeout=5)

    def test_logical_partition_numbers_are_not_source_positions(self):
        r = self.parse('root=PARTUUID=12345678-11 hbpinn.boot=PARTUUID=12345678-10 rootfstype=ext4')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(r.stdout.strip(), '16 17 78563412')

    def test_primary_crossdisk_duplicate_and_device_roots_rejected(self):
        for value in ['root=PARTUUID=12345678-02 hbpinn.boot=PARTUUID=12345678-06',
                      'root=PARTUUID=aaaaaaaa-07 hbpinn.boot=PARTUUID=12345678-06',
                      'root=PARTUUID=12345678-07 root=PARTUUID=12345678-07 hbpinn.boot=PARTUUID=12345678-06',
                      'root=/dev/mmcblk0p7 hbpinn.boot=PARTUUID=12345678-06',
                      'root=PARTUUID=12345678-07',
                      'root=PARTUUID=12345678-40 hbpinn.boot=PARTUUID=12345678-06']:
            with self.subTest(value=value): self.assertNotEqual(self.parse(value).returncode, 0)

    def test_patch_only_changes_known_public_init(self):
        source = HERE/'fixtures/buildroot-init.public'
        patched = buildroot_init.patch_init(source.read_bytes())
        subprocess.run(SHELL + ['-n'], input=patched, check=True)
        self.assertIn(b'PINN_ROOT_PART', patched)
        self.assertNotIn(b'root=PARTUUID=aadddfcb-02', patched)
        with self.assertRaises(RuntimeError): buildroot_init.patch_init(source.read_bytes()+b'\n')

    def test_discovery_accepts_relocated_pair_and_refuses_ambiguity(self):
        for duplicate in [False, True]:
            with self.subTest(duplicate=duplicate), tempfile.TemporaryDirectory(prefix='hbpinn-init-') as temp:
                base = Path(temp); blocks=base/'class'; devices=base/'devices'; dev=base/'dev'
                blocks.mkdir();devices.mkdir();dev.mkdir()
                for disk in ['mmcblk0'] + (['mmcblk1'] if duplicate else []):
                    parent=devices/disk;parent.mkdir()
                    mbr=bytearray(512);mbr[440:444]=bytes.fromhex('78563412');(dev/disk).write_bytes(mbr)
                    for number in [6,7]:
                        name=disk+'p'+str(number);part=parent/name;part.mkdir()
                        (part/'partition').write_text(str(number)+'\n')
                        (part/'size').write_text(('524288' if number==6 else '6291456')+'\n')
                        (blocks/name).symlink_to(part);(dev/name).touch()
                discovery=buildroot_init.DISCOVERY.replace('/sys/class/block/',str(blocks)+'/').replace('/dev/',str(dev)+'/')
                script='set -eu\nROOT_UUID=source-root\nROOT_SECTORS=4194304\n'+buildroot_init.CMDLINE+'\n'
                script+='operation() { :; }\nblkid() { case "$1" in *p6) printf \'TYPE="vfat"\\n\';; *p7) printf \'UUID="source-root" TYPE="ext4"\\n\';; esac; }\n'
                script+='probe_uuid() { blkid "$1" | grep -F "UUID=\\\"$2\\\"" >/dev/null; }\n'+discovery
                script+="valid_cmdline 'root=PARTUUID=12345678-07 hbpinn.boot=PARTUUID=12345678-06'\ndiscover_boot\ndiscover_root\n"
                r=subprocess.run(SHELL + ['-c',script],capture_output=True,text=True,timeout=10)
                self.assertEqual(r.returncode==0,not duplicate,r.stderr)


if __name__ == '__main__': unittest.main(verbosity=2)
