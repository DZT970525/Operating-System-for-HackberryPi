#!/usr/bin/env python3
"""Enrich measured build facts and stage public metadata; no network or token."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess

def need(x,msg):
    if not x:raise RuntimeError(msg)
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-bundle',type=Path,required=True)
    p.add_argument('--tool-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();need(not os.environ.get('GH_TOKEN') and not os.environ.get('GITHUB_TOKEN'),'no publisher credentials here')
    need(not a.output.exists(),'fresh metadata stage required');a.output.mkdir(parents=True)
    root=Path('/mnt/hackberrypi-ubuntu-firefox-20261122')
    facts=json.loads((root/'facts.json').read_text());assets=root/'assets'
    need(facts['asset_directory']==str(assets) and facts['release_tag']=='ubuntu-firefox-hackberrypi-2026-11-22','unexpected facts')
    expected=os.environ['SOURCE_BUNDLE_SHA256'];need(re.fullmatch('[0-9a-f]{64}',expected) and sha(a.source_bundle)==expected,'source archive differs')
    name='Ubuntu-Firefox-Fix-Sources-20261122.tar.gz'
    dest=assets/name;need(not dest.exists(),'source output collision');shutil.copyfile(a.source_bundle,dest)
    facts['patch_source']={'name':name,'bytes':dest.stat().st_size,'sha256':sha(dest),
                          'url':facts['download_base_url']+'/'+name}
    runtime=json.loads((a.tool_root/'input/runtime-validation.json').read_text())
    need(runtime['source_card_firefox_owner_confirmed'] is True and runtime['native_firefox_headless_passed'] is True,
         'runtime evidence not accepted')
    facts['verification'].update(native_firefox_headless_passed=True,source_card_firefox_owner_confirmed=True)
    facts['restore_ubuntu_feed']=True
    for source,target in [(a.tool_root/'input/runtime-validation.json','Ubuntu-Firefox-Runtime-Validation-20261122.json'),
                          (root/'evidence/patch-proof.json','Ubuntu-Firefox-Patch-Proof-20261122.json')]:
        need(source.is_file() and not source.is_symlink() and not (assets/target).exists(),'public evidence collision')
        shutil.copyfile(source,assets/target)
    final=a.output/'publication-facts.json';final.write_text(json.dumps(facts,indent=2)+'\n')
    docs=a.output/'docs'
    subprocess.run(['python3','-B',str(a.tool_root/'docs/build_docs.py'),'--facts',str(final),
                    '--baseline',str(a.tool_root/'input/repository'),'--assets-dir',str(assets),'--output',str(docs)],check=True)
    # New helper names are intentionally separate from native builder evidence.
    for path in sorted((docs/'assets').iterdir()):
        need(path.is_file() and not path.is_symlink(),'ordinary metadata asset required')
        target=assets/path.name
        if target.exists():need(path.name=='SHA256SUMS' or path.read_bytes()==target.read_bytes(),'conflicting public asset '+path.name)
        shutil.copyfile(path,target)
    report=json.loads((docs/'docs-verification.json').read_text())
    need(report['status']=='passed' and report['other_pinn_entries_unchanged'] and report['imager_catalog_byte_exact'],
         'metadata scope checks failed')
    print(json.dumps({'ready':True,'assets':str(assets),'facts':str(final),
                      'repository_files':str(docs/'repository'),'notes':str(docs/'release-notes.md')},indent=2))

if __name__=='__main__':main()
