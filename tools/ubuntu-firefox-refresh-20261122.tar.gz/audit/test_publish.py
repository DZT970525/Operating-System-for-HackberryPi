#!/usr/bin/env python3
"""Offline publication failure/retry tests: fake GitHub, tiny files, no card/network."""
from copy import deepcopy
from contextlib import redirect_stdout
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / 'input/repository'
if not BASELINE.is_dir():
    BASELINE = ROOT / 'audit/repository'
EXPECTED = 'a' * 40


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_publisher():
    spec = importlib.util.spec_from_file_location('publisher_under_test', ROOT / 'publish.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FakeGitHub:
    """Model persisted release/assets/objects/ref across injected client failures."""
    def __init__(self, module, baseline):
        self.module = module
        self.head = EXPECTED
        self.calls = []
        self.uploads = []
        self.contents = {EXPECTED: deepcopy(baseline)}
        self.commits = {EXPECTED: {'sha': EXPECTED, 'tree': {'sha': 'b' * 40},
                                  'parents': [], 'message': 'source build commit'}}
        self.trees = {'b' * 40: deepcopy(baseline)}
        self.blobs = {}
        self.release = None
        self.old_release = {'id': 443992940, 'tag_name': module.OLD_TAG,
                            'draft': False, 'body': 'Original historical notes'}
        self.old_assets = [{'id': 9, 'name': 'historical.img.xz', 'size': 17}]
        self.server_assets = {}
        self.uploaded_bytes = {}
        self.fail_after_ref_once = False
        self.lost_draft_tag = False
        self.extra_drafts = []
        self.next_id = 1000

    def record_asset(self, name, data):
        self.next_id += 1
        asset = {'id': self.next_id, 'name': name, 'size': len(data),
                 'state': 'uploaded', 'digest': 'sha256:' + sha(data)}
        self.server_assets[name] = asset
        self.uploaded_bytes[name] = data
        return deepcopy(asset)

    def make_draft(self, lost_tag=False):
        self.release = {'id': 77, 'tag_name': 'untagged-synthetic' if lost_tag else self.module.TAG,
                        'target_commitish': EXPECTED, 'draft': True,
                        'body': self.module.MARKER + '\nOwned interrupted draft'}
        self.lost_draft_tag = lost_tag

    def upload(self, release_id, path):
        if not self.release or self.release['id'] != release_id:
            raise AssertionError('Upload was not bound to validated numeric release ID')
        if path.name in self.server_assets:
            raise AssertionError('Publisher tried to overwrite an existing asset')
        self.uploads.append((release_id, path.name))
        return self.record_asset(path.name, path.read_bytes())

    def public_json(self, url):
        if not self.release or self.release['draft'] or not url.startswith(self.module.PREFIX):
            raise AssertionError('Catalog probe occurred before fixed release publication')
        return json.loads(self.uploaded_bytes[url.removeprefix(self.module.PREFIX)])

    def api(self, method, path, data=None, allow404=False):
        self.calls.append((method, path, deepcopy(data)))
        if method == 'GET' and path == 'git/ref/heads/main':
            return {'object': {'sha': self.head}}
        if method == 'GET' and path == 'releases/tags/' + self.module.OLD_TAG:
            return deepcopy(self.old_release)
        if method == 'GET' and path == 'releases/tags/' + self.module.TAG:
            if self.release and not (self.release['draft'] and self.lost_draft_tag):
                return deepcopy(self.release)
            if allow404:
                return None
            raise RuntimeError('fake HTTP 404')
        if method == 'GET' and path.startswith('releases?'):
            return ([deepcopy(self.release)] if self.release else []) + deepcopy(self.extra_drafts)
        if method == 'POST' and path == 'releases':
            if self.release:
                raise AssertionError('Duplicate draft creation')
            self.release = {'id': 77, **deepcopy(data)}
            return deepcopy(self.release)
        if method == 'GET' and path.startswith('releases/77/assets?'):
            return list(deepcopy(self.server_assets).values())
        if method == 'PATCH' and path == 'releases/77':
            if data.get('draft') is False:
                if data.get('tag_name') != self.module.TAG or data.get('target_commitish') != EXPECTED:
                    raise AssertionError('Pending tag omitted during publish PATCH')
            self.release.update(deepcopy(data))
            self.lost_draft_tag = False
            return deepcopy(self.release)
        if method == 'PATCH' and path == 'releases/443992940':
            if set(data) != {'body'}:
                raise AssertionError('Historical release mutation exceeded notice body')
            self.old_release.update(deepcopy(data))
            return deepcopy(self.old_release)
        if method == 'DELETE' and path.startswith('releases/assets/'):
            wanted = int(path.rsplit('/', 1)[1])
            found = next(a for a in self.server_assets.values() if a['id'] == wanted)
            if found['state'] == 'uploaded' or found['size'] != 0:
                raise AssertionError('Nonempty or uploaded asset deletion attempted')
            del self.server_assets[found['name']]
            self.uploaded_bytes.pop(found['name'], None)
            return None
        if method == 'GET' and path.startswith('git/commits/'):
            return deepcopy(self.commits[path.rsplit('/', 1)[1]])
        if method == 'GET' and path.startswith('contents/'):
            name, ref = path[len('contents/'):].split('?ref=', 1)
            return {'sha': self.module.blobsha(self.contents[ref][name])}
        if method == 'GET' and path.startswith('compare/'):
            left, right = path[len('compare/'):].split('...', 1)
            return {'files': [{'filename': name} for name in self.contents[right]
                              if self.contents[left].get(name) != self.contents[right][name]]}
        if method == 'POST' and path == 'git/blobs':
            content = base64.b64decode(data['content'])
            identity = self.module.blobsha(content)
            self.blobs[identity] = content
            return {'sha': identity}
        if method == 'POST' and path == 'git/trees':
            result = deepcopy(self.trees[data['base_tree']])
            for row in data['tree']:
                if row['mode'] != '100644' or row['type'] != 'blob':
                    raise AssertionError('Unexpected tree operation')
                result[row['path']] = self.blobs[row['sha']]
            identity = hashlib.sha1(repr(sorted((k, sha(v)) for k, v in result.items())).encode()).hexdigest()
            self.trees[identity] = result
            return {'sha': identity}
        if method == 'POST' and path == 'git/commits':
            identity = hashlib.sha1(json.dumps(data, sort_keys=True).encode()).hexdigest()
            value = {'sha': identity, 'message': data['message'],
                     'tree': {'sha': data['tree']}, 'parents': [{'sha': x} for x in data['parents']]}
            self.commits[identity] = value
            self.contents[identity] = deepcopy(self.trees[data['tree']])
            return deepcopy(value)
        if method == 'PATCH' and path == 'git/refs/heads/main':
            if data['force'] is not False or self.commits[data['sha']]['parents'] != [{'sha': self.head}]:
                raise AssertionError('Non-fast-forward or forced branch update')
            self.head = data['sha']
            if self.fail_after_ref_once:
                self.fail_after_ref_once = False
                raise RuntimeError('Injected lost response after successful main commit')
            return {'object': {'sha': self.head}}
        raise AssertionError('Unexpected fake GitHub request: ' + method + ' ' + path)


class PublisherTests(unittest.TestCase):
    def setUp(self):
        self.module = load_publisher()
        self.tmp = tempfile.TemporaryDirectory(prefix='ubuntu-publisher-offline-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.assets = self.root / 'assets'; self.assets.mkdir()
        self.baseline = self.root / 'baseline'; self.baseline.mkdir()
        self.files = self.root / 'repository'; self.files.mkdir()
        self.receipt = self.root / 'completion.json'
        names = ['README.md', 'Ubuntu/README.md', 'Imager/Ubuntu.md', 'os_list_v3.json', 'os_list_imager.json']
        baseline = {name: (BASELINE / name).read_bytes() for name in names}
        for name, data in baseline.items():
            target = self.baseline / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
        feed = json.loads(baseline['os_list_v3.json'])
        entry = next(row for row in feed['os_list'] if row['os_name'] == 'Ubuntu for HackberryPi')
        for key, filename in [('os_info','ubuntu-os.json'), ('partitions_info','ubuntu-partitions.json'),
                              ('partition_setup','ubuntu-partition_setup.sh')]:
            entry[key] = self.module.PREFIX + filename
        entry['release_date'] = '2026-11-22'
        entry['tarballs'] = [self.module.PREFIX + 'ubuntu-boot.tar.xz', self.module.PREFIX + 'ubuntu-slot2-stub.img.gz']
        self.entry = deepcopy(entry)
        replacement = {name: (b'Ubuntu publication fixture\n' if name.endswith('.md') else data)
                       for name, data in baseline.items()}
        replacement['os_list_v3.json'] = (json.dumps(feed, indent=2) + '\n').encode()
        for name, data in replacement.items():
            target = self.files / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
        contents = {
            'Ubuntu-fixture.img.xz.part01': b'tiny standalone part fixture',
            'ubuntu-boot.tar.xz': b'tiny boot archive fixture',
            'ubuntu-slot2-stub.img.gz': b'tiny raw stub fixture',
            'ubuntu-slot2.img.xz.part01': b'tiny raw partition fixture',
            'ubuntu-partitions.json': b'{"partitions": []}\n',
            'ubuntu-partition_setup.sh': b'#!/bin/sh\nexit 0\n',
            'ubuntu-os.json': json.dumps({'name': 'Ubuntu for HackberryPi'}).encode(),
            'Ubuntu-Imager-Download-Tools-20261122.zip': b'tiny helper fixture',
            'Ubuntu-Firefox-Fix-Sources-20261122.tar.gz': b'tiny source archive fixture',
        }
        def record(name, data):
            return {'name': name, 'bytes': len(data), 'sha256': sha(data), 'url': self.module.PREFIX + name}
        part = record('Ubuntu-fixture.img.xz.part01', contents['Ubuntu-fixture.img.xz.part01'])
        image = {'name': 'Ubuntu-fixture.img.xz', 'bytes': part['bytes'], 'sha256': part['sha256'],
                 'extract_size': 9318694912, 'extract_sha256': 'c' * 64, 'parts': [part]}
        package = {'passed': True, 'feed_entry': self.entry,
                   'payload': {'source': {'sha256': image['sha256'], 'extract_sha256': image['extract_sha256']}},
                   'all_partition_full_xz_to_raw_hash_checks_passed': True,
                   'assets': [record(n, v) for n, v in contents.items() if n.startswith('ubuntu-')]}
        contents['ubuntu-PINN-package.json'] = (json.dumps(package, indent=2) + '\n').encode()
        for name, data in contents.items():
            (self.assets / name).write_bytes(data)
        required = ['two_paths_only','raw_image_length_preserved','boot_partition_unchanged','geometry_unchanged',
                    'all_bytes_outside_root_unchanged','filesystem_check_passed','full_xz_decode_verified',
                    'all_parts_verified','public_source_only','original_source_compressed_and_raw_verified',
                    'generated_security_and_cookies_absent']
        facts = {'release_tag': self.module.TAG, 'provenance': {'build_commit': EXPECTED},
                 'original_source': {'source': {'sha256': 'afdd7664a3fc3c6ea389d429fcf5a4f45a1e335b30d13f8d3d485043b5cf9a7b'}},
                 'image': image, 'pinn': {'feed_entry': self.entry},
                 'verification': {**{k: True for k in required}, 'source_contains_private_card_data': False,
                                  'final_image_physical_boot_tested': False}}
        self.facts = self.root / 'facts.json'; self.facts.write_text(json.dumps(facts))
        self.notes = self.root / 'notes.md'; self.notes.write_text('Fixed Ubuntu release fixture\n')
        self.fake = FakeGitHub(self.module, baseline)
        self.argv = ['publish.py', '--assets', str(self.assets), '--repository-files', str(self.files),
                     '--baseline', str(self.baseline), '--notes', str(self.notes), '--facts', str(self.facts),
                     '--receipt', str(self.receipt)]

    def invoke(self):
        env = {'GITHUB_ACTIONS': 'true', 'GITHUB_REPOSITORY': self.module.REPO,
               'RUNNER_ENVIRONMENT': 'github-hosted', 'GITHUB_EVENT_NAME': 'workflow_dispatch',
               'GITHUB_REF': 'refs/heads/main', 'GITHUB_SHA': EXPECTED, 'GH_TOKEN': 'offline-fixture-token'}
        with patch.dict(os.environ, env), patch('sys.argv', self.argv), \
             patch.object(self.module, 'api', self.fake.api), \
             patch.object(self.module, 'upload', self.fake.upload), \
             patch.object(self.module, 'public_json', self.fake.public_json), \
             patch.object(self.module.subprocess, 'run', side_effect=AssertionError('No subprocess/network allowed')), \
             patch.object(self.module.urllib.request, 'urlopen', side_effect=AssertionError('No network allowed')), \
             redirect_stdout(io.StringIO()):
            self.module.main()

    def test_normal_success_preserves_other_os_and_old_assets(self):
        historical = deepcopy(self.fake.old_assets)
        self.invoke()
        self.assertFalse(self.fake.release['draft'])
        self.assertEqual(self.fake.release['tag_name'], self.module.TAG)
        self.assertNotEqual(self.fake.head, EXPECTED)
        self.assertEqual(self.fake.old_assets, historical)
        before = json.loads(self.fake.contents[EXPECTED]['os_list_v3.json'])['os_list']
        after = json.loads(self.fake.contents[self.fake.head]['os_list_v3.json'])['os_list']
        self.assertEqual([x for x in before if x['os_name'] != self.entry['os_name']],
                         [x for x in after if x['os_name'] != self.entry['os_name']])
        self.assertEqual(self.fake.contents[EXPECTED]['os_list_imager.json'],
                         self.fake.contents[self.fake.head]['os_list_imager.json'])
        self.assertEqual(len(before) - 1, 11)
        rec = self.fake.server_assets[self.receipt.name]
        self.assertEqual(rec['digest'], 'sha256:' + sha(self.receipt.read_bytes()))

    def test_lost_tag_owned_draft_is_recovered_without_duplicate(self):
        self.fake.make_draft(lost_tag=True)
        self.invoke()
        self.assertEqual(self.fake.release['id'], 77)
        self.assertEqual(self.fake.release['tag_name'], self.module.TAG)
        self.assertFalse(any(m == 'POST' and p == 'releases' for m, p, _ in self.fake.calls))
        self.assertTrue(all(rid == 77 for rid, _ in self.fake.uploads))

    def test_failure_after_main_commit_then_resume_and_complete_rerun(self):
        self.fake.fail_after_ref_once = True
        with self.assertRaisesRegex(RuntimeError, 'Injected lost response'):
            self.invoke()
        committed = self.fake.head
        self.assertNotEqual(committed, EXPECTED)
        self.assertNotIn(self.receipt.name, self.fake.server_assets)
        self.invoke()
        self.assertEqual(self.fake.head, committed)
        uploads_after_resume = len(self.fake.uploads)
        self.invoke()
        self.assertEqual(self.fake.head, committed)
        self.assertEqual(len(self.fake.uploads), uploads_after_resume)
        self.assertEqual(sum(m == 'POST' and p == 'git/commits' for m, p, _ in self.fake.calls), 1)
        self.assertEqual(self.fake.old_release['body'].count('**Superseded by'), 1)

    def test_mismatched_existing_asset_refused_before_publication(self):
        self.fake.make_draft()
        self.fake.record_asset('ubuntu-boot.tar.xz', b'different complete bytes')
        with self.assertRaisesRegex(RuntimeError, 'existing asset differs'):
            self.invoke()
        self.assertEqual(self.fake.head, EXPECTED)
        self.assertTrue(self.fake.release['draft'])
        self.assertEqual(self.fake.uploaded_bytes['ubuntu-boot.tar.xz'], b'different complete bytes')
        self.assertFalse(any(m == 'DELETE' for m, _, _ in self.fake.calls))

    def test_other_os_drift_refused_before_any_remote_operation(self):
        path = self.files / 'os_list_v3.json'
        value = json.loads(path.read_text()); value['os_list'][0]['description'] += ' accidental drift'
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(RuntimeError, 'another system changed'):
            self.invoke()
        self.assertEqual(self.fake.calls, [])

    def test_imager_catalog_drift_refused_before_any_remote_operation(self):
        path = self.files / 'os_list_imager.json'; path.write_bytes(path.read_bytes() + b'\n')
        with self.assertRaisesRegex(RuntimeError, 'other Imager catalog data changed'):
            self.invoke()
        self.assertEqual(self.fake.calls, [])

    def test_ambiguous_owned_drafts_refused(self):
        self.fake.make_draft(lost_tag=True)
        self.fake.extra_drafts = [{'id': 78, 'draft': True, 'tag_name': 'untagged-other', 'body': self.module.MARKER}]
        with self.assertRaisesRegex(RuntimeError, 'multiple owned drafts'):
            self.invoke()
        self.assertEqual(self.fake.head, EXPECTED)
        self.assertEqual(self.fake.uploads, [])

    def test_empty_failed_placeholder_replaced_only_in_owned_new_release(self):
        self.fake.make_draft()
        self.fake.server_assets['ubuntu-boot.tar.xz'] = {'id': 444, 'name': 'ubuntu-boot.tar.xz',
                                                       'size': 0, 'state': 'starter', 'digest': None}
        historical = deepcopy(self.fake.old_assets)
        self.invoke()
        self.assertEqual(self.fake.old_assets, historical)
        deletes = [(m,p) for m,p,_ in self.fake.calls if m == 'DELETE']
        self.assertEqual(deletes, [('DELETE', 'releases/assets/444')])
        self.assertEqual(self.fake.server_assets['ubuntu-boot.tar.xz']['state'], 'uploaded')

    def test_empty_failed_completion_receipt_can_resume(self):
        self.invoke()
        self.fake.server_assets[self.receipt.name] = {'id': 445, 'name': self.receipt.name,
                                                     'size': 0, 'state': 'starter', 'digest': None}
        self.fake.uploaded_bytes.pop(self.receipt.name)
        self.invoke()
        self.assertEqual(self.fake.server_assets[self.receipt.name]['state'], 'uploaded')
        self.assertEqual(self.fake.server_assets[self.receipt.name]['digest'], 'sha256:' + sha(self.receipt.read_bytes()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
