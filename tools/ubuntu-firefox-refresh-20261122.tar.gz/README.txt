HackberryPi Ubuntu Firefox correction, 2026-11-22

This archive contains the public-only hosted builder, regression fixtures, download-helper/document generator, scoped publisher, and exact prior public metadata baseline. No private card data, system credentials or network profiles are included.

The builder accepts only the hash-pinned previously published clean Ubuntu image. It adds the public generic/generic-classic Snap model identity and restores one empty native Mesa content source directory, leaving generated security caches absent for native rebuilding. All other root content/attributes and every disk byte outside the root partition are verified unchanged.

The fixed manual GitHub workflow is .github/workflows/ubuntu-firefox-refresh-20261122.yml in DZT970525/Operating-System-for-HackberryPi. It verifies this archive hash, runs offline fixtures, builds without credentials on a disposable hosted runner, then gives the publisher its normal scoped GITHUB_TOKEN only after image verification. See build/README.txt and docs/README.txt. Existing native package/kernel source notices and archives remain linked on the original release.

A physical test of the separately repaired owner card succeeded. The new clean factory image is not claimed to have a separate physical first-boot test. Headless Firefox binary rendering and native content-mount generation were tested separately within the scope recorded in input/runtime-validation.json.
