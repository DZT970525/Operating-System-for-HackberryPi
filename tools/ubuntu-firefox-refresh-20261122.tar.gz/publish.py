#!/usr/bin/env python3
"""Publish only the fixed Ubuntu release and its matching repository metadata."""
from pathlib import Path
import argparse,base64,hashlib,json,os,re,subprocess,time,urllib.request

REPO='DZT970525/Operating-System-for-HackberryPi'
TAG='ubuntu-firefox-hackberrypi-2026-11-22'
OLD_TAG='ubuntu-displayscale-hackberrypi-2026-11-13'
MARKER='<!-- hackberrypi-ubuntu-firefox-20261122 -->'
COMMIT_MESSAGE='[ubuntu-firefox-20261122] Refresh Ubuntu image and PINN / Raspberry Pi Imager downloads'
PREFIX=f'https://github.com/{REPO}/releases/download/{TAG}/'
ALLOWED={'README.md','os_list_v3.json','os_list_imager.json','Imager/Ubuntu.md',
         'Ubuntu/README.md','Ubuntu/os_list_v3.json','Ubuntu/SHA256SUMS',
         'Ubuntu/image-verification.json','Ubuntu/factory-status.json','Ubuntu/SOURCE-NOTICES.md'}

def need(x,msg):
    if not x:raise RuntimeError(msg)
def api(method,path,data=None,allow404=False):
    cmd=['gh','api','--method',method,'repos/'+REPO+'/'+path]
    if data is not None:cmd+=['--input','-']
    p=subprocess.run(cmd,input=json.dumps(data) if data is not None else None,
                     capture_output=True,text=True)
    if p.returncode:
        if allow404 and '(HTTP 404)' in p.stderr:return None
        # Error output contains no request credentials; gh handles auth internally.
        raise RuntimeError(f'GitHub {method} {path}: '+p.stderr[-1200:])
    return json.loads(p.stdout) if p.stdout.strip() else None
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def assets(release_id):
    all=[]
    for page in range(1,20):
        rows=api('GET',f'releases/{release_id}/assets?per_page=100&page={page}')
        all+=rows
        if len(rows)<100:return all
    raise RuntimeError('Unexpected release asset count')
def blobsha(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def resolve_release():
    found=api('GET','releases/tags/'+TAG,allow404=True)
    if found is not None:return found
    matches=[]
    for page in range(1,20):
        rows=api('GET',f'releases?per_page=100&page={page}')
        matches += [x for x in rows if x.get('draft') and MARKER in x.get('body','')]
        if len(rows)<100:break
    need(len(matches)<=1,'multiple owned drafts; refusing ambiguous publication')
    return matches[0] if matches else None
def upload(release_id,path):
    url=f'https://uploads.github.com/repos/{REPO}/releases/{release_id}/assets?name={path.name}'
    p=subprocess.run(['gh','api','--method','POST',url,'-H','Content-Type: application/octet-stream',
                      '--input',str(path)],capture_output=True,text=True)
    need(p.returncode==0,'numeric-ID release upload failed: '+path.name+' '+p.stderr[-800:])
    return json.loads(p.stdout)
def public_json(url):
    need(url.startswith('https://github.com/'+REPO+'/releases/download/'+TAG+'/'),'unexpected public JSON URL')
    with urllib.request.urlopen(url,timeout=60) as r:return json.load(r)

def main():
    p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,required=True)
    p.add_argument('--repository-files',type=Path,required=True)
    p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--notes',type=Path,required=True)
    p.add_argument('--facts',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True);a=p.parse_args()
    need(os.environ.get('GITHUB_ACTIONS')=='true' and os.environ.get('GITHUB_REPOSITORY')==REPO,
         'fixed repository Actions context required')
    need(os.environ.get('RUNNER_ENVIRONMENT')=='github-hosted' and os.environ.get('GITHUB_EVENT_NAME')=='workflow_dispatch',
         'manual hosted publication only')
    need(os.environ.get('GITHUB_REF')=='refs/heads/main','main branch required')
    need(bool(os.environ.get('GH_TOKEN')),'publisher token required')
    expected=os.environ['GITHUB_SHA'];need(re.fullmatch('[0-9a-f]{40}',expected),'invalid commit')
    facts=json.loads(a.facts.read_text())
    need(facts['release_tag']==TAG and facts['provenance']['build_commit']==expected,'build facts belong to another source')
    need(facts['original_source']['source']['sha256']=='afdd7664a3fc3c6ea389d429fcf5a4f45a1e335b30d13f8d3d485043b5cf9a7b',
         'wrong original public image')
    need(facts['image']['extract_size']==9318694912,'raw image size changed')
    required=['two_paths_only','raw_image_length_preserved','boot_partition_unchanged','geometry_unchanged',
              'all_bytes_outside_root_unchanged','filesystem_check_passed','full_xz_decode_verified',
              'all_parts_verified','public_source_only','original_source_compressed_and_raw_verified',
              'generated_security_and_cookies_absent']
    need(all(facts['verification'].get(k) is True for k in required),'image verification gate failed')
    need(facts['verification']['source_contains_private_card_data'] is False and
         facts['verification']['final_image_physical_boot_tested'] is False,'invalid privacy/physical-test status')
    files=sorted(a.assets.iterdir());need(files and all(x.is_file() and not x.is_symlink() for x in files),'flat asset files required')
    records=[]
    for f in files:
        need(re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,180}',f.name),'unsafe asset name')
        need(0<f.stat().st_size<2147483648,'asset exceeds GitHub limit')
        records.append({'name':f.name,'bytes':f.stat().st_size,'sha256':digest(f)})
    need(any(x['name'].endswith('.img.xz.part01') for x in records),'full image parts missing')
    need(any(x['name']=='ubuntu-boot.tar.xz' for x in records),'native PINN boot archive missing')
    need(any(x['name']=='Ubuntu-Imager-Download-Tools-20261122.zip' for x in records),'Imager helper missing')
    need(any(x['name']=='Ubuntu-Firefox-Fix-Sources-20261122.tar.gz' for x in records),'reproducible sources missing')
    record_by_name={x['name']:x for x in records}
    for row in facts['image']['parts']:
        need(record_by_name.get(row['name'])=={k:row[k] for k in ['name','bytes','sha256']} and row['url']==PREFIX+row['name'],
             'full image part differs from build facts')
    package=json.loads((a.assets/'ubuntu-PINN-package.json').read_text())
    need(package['passed'] is True and package['feed_entry']==facts['pinn']['feed_entry'] and
         package['payload']['source']['sha256']==facts['image']['sha256'] and
         package['payload']['source']['extract_sha256']==facts['image']['extract_sha256'] and
         package['all_partition_full_xz_to_raw_hash_checks_passed'] is True,'PINN differs from fixed full image')
    for row in package['assets']:
        need(record_by_name.get(row['name'])=={k:row[k] for k in ['name','bytes','sha256']} and row['url']==PREFIX+row['name'],
             'PINN asset differs from verified package')
    replacements={str(f.relative_to(a.repository_files)):f.read_bytes() for f in a.repository_files.rglob('*') if f.is_file()}
    need(set(replacements)<=ALLOWED and {'README.md','os_list_v3.json','Imager/Ubuntu.md','Ubuntu/README.md'}<=set(replacements),
         'unexpected repository scope')
    need(all(not f.is_symlink() for f in a.repository_files.rglob('*')),'symlinked publication tree')
    oldfeed=json.loads((a.baseline/'os_list_v3.json').read_text())
    newfeed=json.loads(replacements['os_list_v3.json'])
    def entries(x):
        need(isinstance(x.get('os_list'),list),'unexpected feed schema');return x['os_list']
    before=entries(oldfeed);after=entries(newfeed)
    need(len(before)==len(after),'OS catalog count changed')
    affected=[]
    for old,new in zip(before,after):
        if old!=new:
            need(old.get('os_name')=='Ubuntu for HackberryPi' and new.get('os_name')==old['os_name'],'another system changed')
            affected.append(new)
    need(len(affected)==1 and affected[0]==facts['pinn']['feed_entry'] and affected[0]['os_info'].startswith(PREFIX),'Ubuntu feed update missing')
    if 'os_list_imager.json' in replacements:
        need(replacements['os_list_imager.json']==(a.baseline/'os_list_imager.json').read_bytes(),'other Imager catalog data changed')
    notes=MARKER+'\n'+a.notes.read_text()
    # Reject a changed main branch before making any release mutation.
    head=api('GET','git/ref/heads/main')['object']['sha']
    resumed_commit=None
    if head!=expected:
        prior=api('GET','git/commits/'+head)
        need(prior['message']==COMMIT_MESSAGE and [x['sha'] for x in prior['parents']]==[expected],
             'main changed since dispatch; publication stopped')
        for path,data in replacements.items():
            need(api('GET','contents/'+path+'?ref='+head)['sha']==blobsha(data),'owned resume content differs')
        changes=api('GET','compare/'+expected+'...'+head)['files']
        intended={path for path,data in replacements.items() if data!=(a.baseline/path).read_bytes()}
        need({x['filename'] for x in changes}==intended,'owned resume changed unexpected files')
        resumed_commit=prior
    release=resolve_release()
    if release is None:
        release=api('POST','releases',{'tag_name':TAG,'target_commitish':expected,
                    'name':'Ubuntu 24.04.5 GNOME for HackberryPi CM5 — Firefox fix',
                    'body':notes,'draft':True,'prerelease':False,'make_latest':'false'})
    else:
        need((release['tag_name']==TAG or release['draft']) and MARKER in release.get('body',''),'unrelated existing release')
    rid=release['id'];existing={x['name']:x for x in assets(rid)}
    need(set(existing)<=set(x['name'] for x in records)|{a.receipt.name},'unexpected pre-existing assets')
    for record,f in zip(records,files):
        prev=existing.get(f.name)
        if prev and prev['state']!='uploaded' and prev['size']==0:
            # Only an empty failed placeholder in this owned new release; every
            # complete local/public input and previous release is retained.
            api('DELETE',f"releases/assets/{prev['id']}");prev=None
        if prev:
            need(prev['state']=='uploaded' and prev['size']==record['bytes'] and prev.get('digest')=='sha256:'+record['sha256'],
                 'existing asset differs; refusing to overwrite: '+f.name)
        else:
            upload(rid,f)
        print('Verified upload',record['name'],record['bytes'],flush=True)
    remote={x['name']:x for x in assets(rid)}
    need(set(remote)-{a.receipt.name}==set(x['name'] for x in records),'remote asset inventory differs')
    for rec in records:
        x=remote[rec['name']]
        need(x['state']=='uploaded' and x['size']==rec['bytes'] and x.get('digest')=='sha256:'+rec['sha256'],
             'server asset digest mismatch: '+rec['name'])
    published=api('PATCH',f'releases/{rid}',{'tag_name':TAG,'target_commitish':expected,
                   'body':notes,'draft':False,'prerelease':False,'make_latest':'false'})
    need(published['id']==rid and published['tag_name']==TAG and published['draft'] is False,'release tag/publication differs')
    need(api('GET','releases/tags/'+TAG)['id']==rid,'published fixed tag does not resolve')
    # Catalog remains unchanged until the new published downloads are reachable.
    need(public_json(affected[0]['os_info'])['name']=='Ubuntu for HackberryPi','public OS metadata differs')
    need(public_json(PREFIX+'ubuntu-PINN-package.json')['feed_entry']==affected[0], 'public PINN entry differs')
    need(api('GET','git/ref/heads/main')['object']['sha']==(resumed_commit['sha'] if resumed_commit else expected),
         'main changed during upload; release preserved, catalog not overwritten')
    parent=api('GET','git/commits/'+expected)
    edits=[];unchanged=[]
    for path,data in sorted(replacements.items()):
        baseline=a.baseline/path
        need(baseline.is_file(),'missing reviewed baseline '+path)
        old=api('GET','contents/'+path+'?ref='+expected)
        need(old['sha']==blobsha(baseline.read_bytes()),'unreviewed baseline drift: '+path)
        if data==baseline.read_bytes():unchanged.append(path);continue
        made=api('POST','git/blobs',{'content':base64.b64encode(data).decode(),'encoding':'base64'})
        edits.append({'path':path,'mode':'100644','type':'blob','sha':made['sha']})
    need(edits,'no repository updates')
    if resumed_commit:commit=resumed_commit
    else:
        tree=api('POST','git/trees',{'base_tree':parent['tree']['sha'],'tree':edits})
        commit=api('POST','git/commits',{'message':COMMIT_MESSAGE,'tree':tree['sha'],'parents':[expected]})
        api('PATCH','git/refs/heads/main',{'sha':commit['sha'],'force':False})
    for path,data in replacements.items():
        got=api('GET','contents/'+path+'?ref='+commit['sha'])
        need(got['sha']==blobsha(data),'published repository file differs: '+path)
    old=api('GET','releases/tags/'+OLD_TAG)
    need(old['id']==443992940,'unexpected legacy release')
    notice=f'**Superseded by the [2026-11-22 Firefox-fixed Ubuntu release](https://github.com/{REPO}/releases/tag/{TAG}).** New PINN and Raspberry Pi Imager installations should use that release. Historical assets and source archives remain available below.\n\n'
    if notice not in old.get('body',''):
        api('PATCH',f"releases/{old['id']}",{'body':notice+old.get('body','')})
    receipt={'complete':True,'repository':REPO,'release_id':rid,'release_tag':TAG,
             'release_url':f'https://github.com/{REPO}/releases/tag/{TAG}',
             'repository_commit':commit['sha'],'assets':records,'old_assets_deleted':False,
             'other_pinn_entries_unchanged':len(after)-1,'imager_catalog_unchanged':True,
             'repository_files_changed':[x['path'] for x in edits],
             'repaired_source_card_owner_tested':True,'rebuilt_factory_physical_test_pending':True}
    a.receipt.parent.mkdir(parents=True,exist_ok=True);a.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
    previous={x['name']:x for x in assets(rid)}.get(a.receipt.name)
    if previous and previous['state']!='uploaded' and previous['size']==0:
        api('DELETE',f"releases/assets/{previous['id']}");previous=None
    receipt_sha=digest(a.receipt)
    if previous:
        need(previous['size']==a.receipt.stat().st_size and previous.get('digest')=='sha256:'+receipt_sha,
             'existing completion receipt differs')
    else:upload(rid,a.receipt)
    stored={x['name']:x for x in assets(rid)}[a.receipt.name]
    need(stored['state']=='uploaded' and stored['size']==a.receipt.stat().st_size and stored.get('digest')=='sha256:'+receipt_sha,
         'completion receipt server digest differs')
    print(json.dumps({k:v for k,v in receipt.items() if k!='assets'},indent=2))

if __name__=='__main__':main()
