#!/usr/bin/python3
"""Prepare Ubuntu-only repository replacements and public helper/metadata assets.

No network, credentials, card access or remote writes. All input facts are
measured by the separate image builder. Baseline files are exact public blobs.
"""
import argparse
import copy
import difflib
import hashlib
import json
import math
from pathlib import Path
import re
import shutil

from render_helpers import (BASE, HERE, IMAGE, OLD_BASE, OLD_IMAGE, SITE, TAG, ZIP,
                            dump, need, package_helper, render_helper, sha, valid_hash,
                            validate_image)

RAW = 'https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/'
OLD_ZIP = 'Ubuntu-Imager-Download-Tools-20261113.zip'
NATIVE_NOTICE_NAMES = (
    'Ubuntu-HackberryPi-Integration-Source-20261113.tar.gz',
    'Ubuntu-HackberryPi-Source-Notices-20261113.tar.gz',
    'linux-raspi_6.8.0.orig.tar.gz', 'linux-raspi_6.8.0-1064.68.diff.gz',
    'linux-raspi_6.8.0-1064.68.dsc')
REQUIRED_TRUE = (
    'two_paths_only', 'raw_image_length_preserved', 'boot_partition_unchanged',
    'geometry_unchanged', 'filesystem_check_passed', 'full_xz_decode_verified',
    'all_parts_verified', 'native_firefox_headless_passed',
    'source_card_firefox_owner_confirmed')


def read(path):
    return json.loads(path.read_text())


def asset_record(value, *, base=BASE):
    need(set(('name', 'bytes', 'sha256', 'url')) <= set(value), 'Incomplete public asset facts')
    name = value['name']
    need(isinstance(name, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name)
         and '..' not in name and '/' not in name, 'Unsafe asset name')
    need(value['bytes'] > 0 and valid_hash(value['sha256']), 'Invalid asset measurement')
    need(value['url'] == base + '/' + name, 'Unexpected public asset URL')
    return {key: value[key] for key in ('name', 'bytes', 'sha256', 'url')}


def replace_section(text, heading, replacement, *, next_level='## '):
    start = text.index(heading)
    end = text.find('\n' + next_level, start + len(heading))
    if end < 0:
        end = len(text)
    return text[:start] + replacement.rstrip() + '\n' + text[end:]


def common_update(text, image, info):
    for old, new in ((OLD_BASE, BASE), (OLD_IMAGE, IMAGE), (OLD_ZIP, ZIP),
                     ('3017984912', str(image['bytes'])),
                     ('afdd7664a3fc3c6ea389d429fcf5a4f45a1e335b30d13f8d3d485043b5cf9a7b', image['sha256']),
                     ('56dadec8025ee6026f6feec66da7d40245e5ceb03e4d0ec7bc5a8f579d78b1d9', image['extract_sha256']),
                     ('9318694912', str(image['extract_size'])),
                     ('**6 parts**', f"**{info['part_count']} parts**"),
                     ('at least 7 GB free', f"at least {info['first_download_recommended_free_gb']} GB free")):
        text = text.replace(old, new)
    return text


def root_readme(baseline, image, info):
    text = baseline
    # Only the Ubuntu table URL and Ubuntu section may change in this shared file.
    text = text.replace(OLD_BASE + '/' + OLD_ZIP, BASE + '/' + ZIP)
    heading = '### Ubuntu: automatic download and merge'
    start = text.index(heading)
    end = text.find('\n### ', start + len(heading))
    need(end > start, 'Ubuntu README section boundary missing')
    original = baseline[baseline.index(heading):baseline.find('\n### ', baseline.index(heading) + len(heading))]
    section = common_update(original, image, info)
    old = 'This standalone release replaces the old Ubuntu PINN preview. The new PINN multiboot adapter is linked above; Ubuntu uses the download helper for Imager.'
    new = ('The 2026-11-22 refresh fixes Firefox startup while keeping the native Ubuntu packages and hardware integration. '
           'The owner confirmed Firefox on the repaired PINN card. Ubuntu is available through the combined PINN catalog '
           'and this standalone download helper; the newly rebuilt clean image still awaits a separate physical first-boot test.')
    need(old in section, 'Ubuntu historical README wording changed')
    section = section.replace(old, new)
    result = text[:start] + section + text[end:]
    # Restore the edited section/links and prove every other byte is unchanged.
    reversed_text = result[:start] + original + result[start + len(section):]
    reversed_text = reversed_text.replace(BASE + '/' + ZIP, OLD_BASE + '/' + OLD_ZIP)
    need(reversed_text == baseline, 'Non-Ubuntu root README bytes changed')
    return result


def patch_catalog(raw, entry):
    old = json.loads(raw)
    rows = old['os_list']
    matches = [i for i, row in enumerate(rows) if row.get('os_name') == 'Ubuntu for HackberryPi']
    need(len(matches) == 1 and entry['os_name'] == 'Ubuntu for HackberryPi', 'Expected one Ubuntu PINN entry')
    index = matches[0]
    need(entry['release_date'] == '2026-11-22', 'Stale PINN release date')
    for key in ('os_info', 'partitions_info', 'partition_setup'):
        need(entry[key].startswith(BASE + '/ubuntu-'), 'Unexpected PINN recipe URL')
    need(all(value.startswith(BASE + '/ubuntu-') for value in entry['tarballs']), 'Unexpected PINN tarball URL')
    # Replace the one JSON object, leaving unrelated catalog bytes untouched.
    decoder = json.JSONDecoder()
    position = raw.index('[', raw.index('"os_list"')) + 1
    spans = []
    while True:
        while raw[position].isspace() or raw[position] == ',':
            position += 1
        if raw[position] == ']':
            break
        _, end = decoder.raw_decode(raw, position)
        spans.append((position, end))
        position = end
    need(len(spans) == len(rows), 'Unexpected catalog encoding')
    start, end = spans[index]
    replacement = json.dumps(entry, indent=2).replace('\n', '\n    ')
    result = raw[:start] + replacement + raw[end:]
    changed = json.loads(result)
    expected = copy.deepcopy(old)
    expected['os_list'][index] = entry
    need(changed == expected, 'Unrelated PINN entry changed')
    need(result[:start] == raw[:start] and result[start + len(replacement):] == raw[end:], 'Unrelated PINN catalog bytes changed')
    return result


def build(facts, baseline, output, asset_dirs):
    validate_image(facts)
    v = facts['verification']
    for key in REQUIRED_TRUE:
        need(v.get(key) is True, 'Required verification fact missing: ' + key)
    need(v['source_contains_private_card_data'] is False, 'Public clean-source proof required')
    need(v['final_image_physical_boot_tested'] is False, 'Review physical-test claims explicitly before changing this build')
    patch = asset_record(facts['patch_source'])
    need(patch['name'] == 'Ubuntu-Firefox-Fix-Sources-20261122.tar.gz', 'Unexpected reproducible source archive')
    image = facts['image']
    repo = output / 'repository'
    assets = output / 'assets'
    assets.mkdir(parents=True, exist_ok=True)
    helper_dir = output / 'helper'
    info = render_helper(facts, helper_dir)
    fixtures = read(HERE / 'helper-fixture-report.json')
    package_helper(helper_dir, info, fixtures)
    shutil.copy2(helper_dir / ZIP, assets / ZIP)
    for name in ('ubuntu-parts.json', 'ubuntu-parts.sha256'):
        shutil.copy2(helper_dir / 'Ubuntu-Download-Tools' / name, assets / name)

    original_status = read(baseline / 'Ubuntu/factory-status.json')
    original_verification = read(baseline / 'Ubuntu/image-verification.json')
    need(tuple(item['name'] for item in original_status['source_assets']) == NATIVE_NOTICE_NAMES, 'Historical source notices changed')
    source_assets = copy.deepcopy(original_status['source_assets'])
    for item in source_assets:
        item['url'] = OLD_BASE + '/' + item['name']
    image_public = {key: image[key] for key in ('name', 'bytes', 'sha256', 'extract_size', 'extract_sha256')}
    download_parts = [{'filename': p['name'], 'size': p['bytes'], 'sha256': p['sha256']} for p in image['parts']]
    helper_public = {key: value for key, value in info.items() if key != 'fixture_only'}
    fix_public = {
        'release_date': '2026-11-22', 'clean_published_image_used': True,
        'private_card_data_copied': False,
        'change': ['retain public Snap model identity without source device credentials',
                   'restore the empty native Mesa kernel-gpu-2404 content source directory'],
        'native_content_mount_profile_regeneration_test_passed': True,
        'owner_confirmed_firefox_on_repaired_card': True,
        'native_headless_firefox_render_test_passed': True,
        'isolated_browser_test_scope': 'Direct native GPU wrapper, GNOME libraries and Firefox binary; GNOME desktop wrapper and full Snap confinement were not exercised in isolation',
        'new_clean_release_image_physical_boot_tested': False,
        'reproducible_source': patch}
    status = copy.deepcopy(original_status)
    status.update(release_tag=TAG, image=image_public, download_helper=helper_public,
                  download_parts=download_parts, source_assets=source_assets,
                  pinn_supported_in_this_release=True, old_ubuntu_pinn_preview_withdrawn=True,
                  old_preview_withdrawal_scope='Historical pre-multiboot preview only; the current corrected PINN multiboot package is supported',
                  current_pinn_feed=RAW + 'os_list_v3.json', firefox_startup_fix=fix_public,
                  source_card_modified_by_publication=False,
                  physical_boot_of_final_factory_image_tested=False)
    verification = copy.deepcopy(original_verification)
    verification.update(image=image_public, release_tag=TAG, download_helper=helper_public,
                        download_parts=download_parts, source_assets=source_assets,
                        firefox_startup_fix=fix_public,
                        complete_decompressed_stream_verified=True,
                        clean_source_patch_delta_verified=True,
                        boot_partition_and_geometry_unchanged=True,
                        physical_boot_of_final_factory_image_tested=False,
                        pinn_supported_in_this_release=True)
    # Preserve source and native integration facts; attach this new correction.
    need(status['native_kernel_release'] == original_status['native_kernel_release'], 'Native kernel changed')
    need(verification['kernel_source_authentication'] == original_verification['kernel_source_authentication'], 'Kernel source evidence changed')

    validation = '''## Validation

The owner confirmed Firefox starts on the repaired Ubuntu PINN card. This release is rebuilt from the previously published clean factory image; no files or personal data were copied from that card. The patch retains only public Snap model identity and restores an empty native Mesa content directory. Native content-mount profile regeneration and headless Firefox rendering passed in disposable tests. The isolated browser test exercised the native GPU wrapper, GNOME libraries and Firefox binary directly; it did not exercise the GNOME desktop wrapper or full Snap confinement. The clean-source file delta, unchanged boot partition and geometry, filesystem checks, complete XZ decode and all delivery-part hashes passed.

The newly rebuilt clean release image still awaits a separate physical flash and first-boot test. The repaired-card result and isolated browser checks do not establish a complete physical test of this new image. Native hardware integration, package versions and factory identity/root-growth setup are retained. Prior isolated root-growth checks remain applicable to the unchanged helper.
'''
    pinn = '''## PINN multiboot

The corrected Ubuntu package is also available as **Ubuntu for HackberryPi** in the prepared HackberryPi CM5 PINN combined catalog:

```
alt_image_source=https://raw.githubusercontent.com/DZT970525/Operating-System-for-HackberryPi/main/os_list_v3.json
```

Keep the network connected while PINN installs its verified supplemental payload. Use the prepared HackberryPi PINN edition and select the systems that fit the card. Read the [PINN installation guide](../Imager/PINN.md). The refreshed Ubuntu recipe affects new installations; it does not update an Ubuntu installation already on a card. All other systems' entries and payloads remain unchanged by this Ubuntu refresh.

The standalone Imager file is a complete disk image. Writing it replaces the selected card and its existing PINN layout; choose the PINN package for multiboot installation. Never use an individual `.partNN` or the helper ZIP as an Imager image.
'''
    supplement = (f'The [2026-11-22 Firefox correction source]({patch["url"]}) contains the reproducible clean-image patch, '
                  'publication tools and verification support. Native packages, kernel and previous integration binaries are unchanged; '
                  'the original matching source archives and notices linked below remain available.\n\n')
    # Keep historical source URLs pointing to the retained historical assets.
    ubuntu = (baseline / 'Ubuntu/README.md').read_text()
    start = ubuntu.index('## Sources and notices')
    head, original_sources = ubuntu[:start], ubuntu[start:]
    head = common_update(head, image, info)
    head = replace_section(head, '## Validation', validation)
    head = replace_section(head, '## PINN migration', pinn)
    head = head.replace('ubuntu-displayscale-hackberrypi-2026-11-13', TAG)
    ubuntu = head.rstrip() + '\n\n' + original_sources.replace('## Sources and notices\n\n', '## Sources and notices\n\n' + supplement, 1)
    need(all(OLD_BASE + '/' + name in ubuntu for name in NATIVE_NOTICE_NAMES), 'Original source archive links lost')
    imager = common_update((baseline / 'Imager/Ubuntu.md').read_text(), image, info)
    imager = imager.replace('The owner tested and accepted the configured source card.',
                            'The owner confirmed Firefox on the repaired Ubuntu PINN card. This new artifact is built from the clean published factory image.')
    old_validation = imager[imager.index('The owner confirmed Firefox'):imager.index('\nHelper validation:')]
    imager = imager.replace(old_validation, validation.split('\n\n', 1)[1] +
                            '\nRead the [Ubuntu system notes](../Ubuntu/README.md) for the corrected PINN multiboot package, retained hardware integration and source notices.\n')
    sources = (baseline / 'Ubuntu/SOURCE-NOTICES.md').read_text()
    sources = sources.replace('# Ubuntu source and notices\n\n', '# Ubuntu source and notices\n\n' + supplement, 1)
    root = root_readme((baseline / 'README.md').read_text(), image, info)
    entries = facts['pinn']['feed_entry']
    root_catalog = patch_catalog((baseline / 'os_list_v3.json').read_text(), entries)
    imager_bytes = (baseline / 'os_list_imager.json').read_bytes()
    need('ubuntu' not in json.dumps(json.loads(imager_bytes)).lower(), 'Existing Ubuntu Imager entry requires an explicit update strategy')

    def write_repo(name, value):
        p = repo / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(value if isinstance(value, bytes) else value.encode())

    write_repo('README.md', root)
    write_repo('Ubuntu/README.md', ubuntu)
    write_repo('Imager/Ubuntu.md', imager)
    write_repo('Ubuntu/SOURCE-NOTICES.md', sources)
    write_repo('os_list_v3.json', root_catalog)
    write_repo('os_list_imager.json', imager_bytes)
    if facts.get('restore_ubuntu_feed', False):
        write_repo('Ubuntu/os_list_v3.json', json.dumps({'os_list': [entries]}, indent=2) + '\n')
    else:
        write_repo('Ubuntu/os_list_v3.json', (baseline / 'Ubuntu/os_list_v3.json').read_bytes())
    for name, value in [('factory-status.json', status), ('image-verification.json', verification)]:
        dump(assets / name, value)
        shutil.copy2(assets / name, repo / 'Ubuntu' / name)
    (assets / 'README.md').write_text(ubuntu)
    (assets / 'SOURCE-NOTICES.md').write_text(sources)
    (output / 'release-notes.md').write_text(f'''Ubuntu 24.04.5 LTS GNOME for HackberryPi CM5: Firefox startup correction, 2026-11-22.

The owner confirmed Firefox on the repaired Ubuntu PINN card. New standalone and PINN artifacts apply the same minimal correction to the previously published clean factory image: retain public Snap model identity and restore the empty native Mesa GPU content directory. Native Snap confinement remains enabled. Kernel, installed native packages, Display Scale and hardware integration are retained; no private card data was copied.

For Raspberry Pi Imager, download [the automatic Windows/macOS/Linux helper ZIP]({BASE}/{ZIP}), let it download and merge {info['part_count']} verified parts, then choose **Use custom** and select `{IMAGE}`. Use a 16 GB or larger SD card and keep Imager OS customisation disabled. The helper needs at least {info['first_download_recommended_free_gb']} GB free and never writes a card. Login: **pi / pi**.

For PINN multiboot, use **Ubuntu for HackberryPi** from the [combined catalog]({RAW}os_list_v3.json). Keep the network connected during installation. The catalog refresh affects new installs and preserves all other systems' entries. It does not update an installed Ubuntu automatically.

Clean-source delta, unchanged boot/geometry, filesystem, native content-mount profile regeneration, headless Firefox rendering, complete decompression and part-integrity checks passed. The isolated browser test exercised the native GPU wrapper, GNOME libraries and Firefox binary directly, without the GNOME desktop wrapper or full Snap confinement. The newly rebuilt clean image has not yet received a separate physical flash/first-boot test. The owner's repaired-card test remains distinct from that pending validation.

Read [Ubuntu notes]({SITE}/blob/main/Ubuntu/README.md), [Imager steps]({SITE}/blob/main/Imager/Ubuntu.md) and `factory-status.json`. [Reproducible correction source]({patch['url']}); original matching native sources and license notices remain linked in `SOURCE-NOTICES.md`.
''')

    index = {}

    def add_asset(name, size, digest):
        need(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name) is not None and '..' not in name, 'Unsafe checksum filename')
        need(size > 0 and valid_hash(digest), 'Invalid checksum record')
        need(name not in index or index[name] == (size, digest), 'Different bytes share asset filename: ' + name)
        index[name] = (size, digest)

    add_asset(IMAGE, image['bytes'], image['sha256'])
    for part in image['parts']:
        add_asset(part['name'], part['bytes'], part['sha256'])
    add_asset(patch['name'], patch['bytes'], patch['sha256'])
    for directory in [*asset_dirs, assets]:
        need(directory.is_dir() and not directory.is_symlink(), 'Ordinary public asset directory required')
        for path in directory.iterdir():
            if path.name == 'SHA256SUMS' or not path.is_file():
                continue
            need(not path.is_symlink(), 'Symlinked public asset refused')
            add_asset(path.name, path.stat().st_size, sha(path.read_bytes()))
    checksums = ''.join(f'{index[name][1]}  {name}\n' for name in sorted(index))
    (assets / 'SHA256SUMS').write_text(checksums)
    write_repo('Ubuntu/SHA256SUMS', checksums)
    # Final guard reports are local build records, not release assets.
    changed_paths, baseline_sha, replacements = [], {}, []
    for path in sorted(repo.rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(repo).as_posix()
        old = (baseline / rel).read_bytes()
        new = path.read_bytes()
        baseline_sha[rel] = sha(old)
        if old != new:
            changed_paths.append(rel)
        replacements.append({'path': rel, 'bytes': len(new), 'sha256': sha(new), 'changed': old != new})
        if old != new and path.suffix in ('.md', '.json'):
            diff = ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                               fromfile='a/' + rel, tofile='b/' + rel))
            target = output / 'diffs' / (rel.replace('/', '_') + '.diff')
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(diff)
    need((repo / 'os_list_imager.json').read_bytes() == imager_bytes, 'Imager catalog changed')
    need(read(repo / 'Ubuntu/factory-status.json')['source_assets'] == source_assets, 'Native notices altered')
    report = {'status': 'passed', 'remote_mutations': False, 'card_accessed': False,
              'other_pinn_entries_unchanged': True, 'unrelated_pinn_catalog_bytes_unchanged': True,
              'imager_catalog_byte_exact': True, 'other_root_readme_bytes_unchanged': True,
              'historical_native_source_links_preserved': True,
              'new_image_physical_first_boot_tested': False,
              'baseline_file_sha256': baseline_sha, 'changed_repository_paths': changed_paths,
              'repository_replacements': replacements,
              'helper': info, 'release_checksum_records': len(index)}
    dump(output / 'docs-verification.json', report)
    dump(output / 'release-asset-index.json', [{'name': name, 'bytes': size, 'sha256': digest,
                                              'assembled_image_only': name == IMAGE}
                                             for name, (size, digest) in sorted(index.items())])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--facts', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--assets-dir', type=Path, action='append', default=[])
    args = parser.parse_args()
    need(not args.output.exists(), 'Use a fresh output directory')
    facts = read(args.facts)
    report = build(facts, args.baseline, args.output, args.assets_dir)
    print(json.dumps({key: report[key] for key in ('status', 'changed_repository_paths', 'helper', 'release_checksum_records')}, indent=2))


if __name__ == '__main__':
    main()
