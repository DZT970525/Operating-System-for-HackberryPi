Ubuntu Firefox refresh: public docs and automatic download helpers

This folder performs no network request, remote write, card access or image
mutation. It consumes the image builder's measured public facts and exact public
repository baseline blobs. It emits a reviewable staging tree for the parent
publisher; it never commits or uploads anything.

Files:
  build_docs.py       Public metadata/docs/helper ZIP and Ubuntu-only catalogs
  render_helpers.py  Fixed-release manifest validation and trusted helper renderer
  templates/         Exact previously published Ubuntu download helper templates
  test_docs.py       Offline integrity/refusal fixtures and other-system guards

Verify before packaging:
  python3 docs/test_docs.py --baseline input/repository

Build after image/part/source measurements exist:
  python3 docs/build_docs.py --facts /absolute/path/final-facts.json \
    --baseline input/repository --assets-dir /absolute/path/builder-assets \
    --output /absolute/path/fresh-doc-output

--output must not exist. --assets-dir may be repeated for public asset folders;
their ordinary files are measured into SHA256SUMS. Do not pass private folders.
All baseline files must be the exact observed public repository blobs:
  README.md, os_list_v3.json, os_list_imager.json
  Ubuntu/README.md, Ubuntu/factory-status.json,
  Ubuntu/image-verification.json, Ubuntu/SHA256SUMS,
  Ubuntu/os_list_v3.json, Ubuntu/SOURCE-NOTICES.md, Imager/Ubuntu.md

Required facts (extra builder fields are not copied into public documents):
  release_tag: ubuntu-firefox-hackberrypi-2026-11-22
  download_base_url: fixed GitHub repository release/download URL for that tag
  image:
    name: Ubuntu-24.04.5-GNOME-HackberryPi-CM5-DisplayScale-Neofetch-20261122.img.xz
    bytes, sha256, extract_size, extract_sha256
    parts: [{name, bytes, sha256, url}, ...] in numbered order, 500 MiB each
           except the final part; URLs must use the fixed release above
  patch_source:
    name: Ubuntu-Firefox-Fix-Sources-20261122.tar.gz
    bytes, sha256, url (same fixed release)
  verification:
    two_paths_only: true
    raw_image_length_preserved: true
    boot_partition_unchanged: true
    geometry_unchanged: true
    filesystem_check_passed: true
    full_xz_decode_verified: true
    all_parts_verified: true
    native_firefox_headless_passed: true
    source_card_firefox_owner_confirmed: true
    source_contains_private_card_data: false
    final_image_physical_boot_tested: false
  pinn:
    feed_entry: complete new measured Ubuntu PINN catalog entry
  restore_ubuntu_feed: true (restore Ubuntu/os_list_v3.json as a one-entry feed)

Outputs:
  assets/      New helper ZIP, ubuntu-parts manifests, Ubuntu README, source
               notices, factory-status, image-verification and SHA256SUMS
  repository/  Exact replacement file bytes, ready for a single parent commit
  release-notes.md
  diffs/       Review diffs for changed Markdown/JSON repository files
  docs-verification.json and release-asset-index.json
  helper/      Expanded helper ZIP contents and ZIP itself

The checksum index includes the assembled whole-image hash even though GitHub
hosts its split parts. release-asset-index.json marks that virtual full-image
record with assembled_image_only=true; it is not an upload requirement.

The shared root README changes only the Ubuntu section and helper table link.
The root PINN catalog changes only its Ubuntu object; surrounding bytes and the
other eleven entries are preserved. The Imager catalog is byte-identical because
the current public catalog has no direct Ubuntu entry. Original native source
archive, license and matching kernel links remain on their historical release.

Native Linux/POSIX fixture execution is covered. Windows and macOS receive static
launcher/manifest checks; no native runtime or full network-resume claim is made.
Repaired-card browser acceptance is kept separate from the new clean image's
pending physical flash/first boot. The source archive hash is supplied at build
time, outside this source package, to avoid a circular package checksum.
