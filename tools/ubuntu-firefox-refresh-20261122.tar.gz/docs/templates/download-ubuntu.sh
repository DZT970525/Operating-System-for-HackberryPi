#!/bin/sh
# Downloads data files only. No administrator access or extra packages required.
set -eu
umask 077
IMAGE='Ubuntu-24.04.5-GNOME-HackberryPi-CM5-DisplayScale-Neofetch-20261113.img.xz'
IMAGE_BYTES=3017984912
IMAGE_SHA='afdd7664a3fc3c6ea389d429fcf5a4f45a1e335b30d13f8d3d485043b5cf9a7b'
PART_BYTES=524288000
LAST_BYTES=396544912
BASE='https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/ubuntu-displayscale-hackberrypi-2026-11-13'
RESERVE=268435456
HERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
OUT=${1:-$HERE}
LOCKED=0
PLAN=''
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
safe_file() { [ ! -L "$1" ] && { [ ! -e "$1" ] || [ -f "$1" ]; }; }
bytes() { LC_ALL=C wc -c < "$1" | tr -d '[:space:]'; }
if command -v sha256sum >/dev/null 2>&1; then
    hash() { result=$(sha256sum "$1") || return 1; printf '%s\n' "$result" | awk '{print $1}'; }
elif command -v shasum >/dev/null 2>&1; then
    hash() { result=$(shasum -a 256 "$1") || return 1; printf '%s\n' "$result" | awk '{print $1}'; }
else
    die 'SHA256 tool missing: this helper needs the system sha256sum or shasum command.'
fi
verified() { [ -f "$1" ] && [ "$(bytes "$1")" = "$2" ] && [ "$(hash "$1")" = "$3" ]; }
cleanup() {
    [ -z "$PLAN" ] || rm -f "$PLAN"
    [ "$LOCKED" != 1 ] || rmdir "$CACHE/.lock" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT TERM HUP
mkdir -p "$OUT" || die 'Cannot create the output folder. Choose a writable folder.'
OUT=$(CDPATH= cd -P "$OUT" && pwd)
FINAL="$OUT/$IMAGE"
MERGE="$FINAL.partial"
CACHE="$OUT/.ubuntu-download-parts"
safe_file "$FINAL" || die 'The output filename is occupied by a link or directory.'
if [ -e "$FINAL" ]; then
    printf 'Verifying existing image...\n'
    verified "$FINAL" "$IMAGE_BYTES" "$IMAGE_SHA" || die 'A different file already has the final filename. Move or rename it before retrying; it was not changed.'
    printf 'Already complete: the existing image passed SHA256 verification.\n'
else
    [ ! -L "$CACHE" ] || die 'The download cache must not be a symbolic link.'
    mkdir -p "$CACHE" || die 'Cannot create the download cache.'
    mkdir "$CACHE/.lock" 2>/dev/null || die 'Another helper may be running. If none is running, remove only .ubuntu-download-parts/.lock and retry.'
    LOCKED=1
    PLAN=$(mktemp "$CACHE/plan.XXXXXX")
    awk -v image="$IMAGE" -v total="$IMAGE_BYTES" -v whole="$IMAGE_SHA" \
        -v part="$PART_BYTES" -v last="$LAST_BYTES" -v base="$BASE" '
      function bad() {failed=1;exit 1}
      /^#/ || NF==0 {next}
      $1=="VERSION" {if(NF!=2||$2!="1"||version++)bad();next}
      $1=="READY" {if(NF!=2||$2!="true"||ready++)bad();next}
      $1=="BASE" {if(NF!=2||$2!=base||bases++)bad();next}
      $1=="IMAGE" {if(NF!=4||$2!=image||$3!=total||$4!=whole||images++)bad();next}
      $1=="PART" {n++;expected=sprintf("%s.part%02d",image,n);
        if(NF!=4||n>6||$2!=expected||$3!=(n==6?last:part)||length($4)!=64||$4~/[^0-9a-f]/)bad();
        print $2 "\t" $3 "\t" $4;next}
      {bad()}
      END {if(failed||version!=1||ready!=1||bases!=1||images!=1||n!=6)exit 1}
    ' "$HERE/ubuntu-parts.sha256" > "$PLAN" || die 'The bundled manifest is not ready or is invalid. Download and extract the complete published helper ZIP.'
    safe_file "$MERGE" || die 'The merge filename is occupied by a link or directory.'
    old_merge=0
    [ ! -f "$MERGE" ] || old_merge=$(bytes "$MERGE")
    [ "$old_merge" -le "$IMAGE_BYTES" ] || old_merge=$IMAGE_BYTES
    need=$((IMAGE_BYTES - old_merge + RESERVE))
    TAB=$(printf '\t')
    while IFS="$TAB" read -r name size expected; do
        target="$CACHE/$name"; partial="$target.partial"
        safe_file "$target" && safe_file "$partial" || die 'An unsafe path was found inside the download cache.'
        if [ -f "$target" ]; then
            if verified "$target" "$size" "$expected"; then continue; fi
            printf 'Discarding a failed cached chunk: %s\n' "$name"
            rm -f "$target"
        fi
        have=0
        [ ! -f "$partial" ] || have=$(bytes "$partial")
        if [ "$have" -gt "$size" ]; then rm -f "$partial"; have=0; fi
        need=$((need + size - have))
    done < "$PLAN"
    free_kb=$(LC_ALL=C df -Pk "$OUT" | awk 'END {print $4}')
    case "$free_kb" in ''|*[!0-9]*) die 'Cannot determine free space. Choose a normal local disk folder.';; esac
    [ "$((free_kb * 1024))" -ge "$need" ] || die "Not enough free space. Free at least $need bytes in this folder and run again. A first download needs about 7 GB free."
    while IFS="$TAB" read -r name size expected; do
        target="$CACHE/$name"; partial="$target.partial"
        if verified "$target" "$size" "$expected"; then
            printf 'Reusing verified chunk: %s\n' "$name"
            continue
        fi
        if verified "$partial" "$size" "$expected"; then
            mv "$partial" "$target"
            continue
        fi
        if [ -f "$partial" ] && [ "$(bytes "$partial")" -eq "$size" ]; then
            printf 'Discarding a failed complete partial chunk: %s\n' "$name"
            rm -f "$partial"
        fi
        [ "${UBUNTU_HELPER_LOCAL_ONLY:-0}" != 1 ] || die "Offline mode: a verified chunk is missing: $name"
        command -v curl >/dev/null 2>&1 || die 'The system curl command is unavailable.'
        printf '\nDownloading %s\n' "$name"
        curl --fail --location --proto '=https' --proto-redir '=https' \
            --retry 3 --retry-delay 3 --connect-timeout 20 --speed-time 60 --speed-limit 1024 \
            --continue-at - --output "$partial" "$BASE/$name" \
            || die 'Download interrupted. Keep this folder and run the helper again to resume.'
        if ! verified "$partial" "$size" "$expected"; then
            rm -f "$partial"
            die "Chunk verification failed: $name. Run again to download that chunk again."
        fi
        mv "$partial" "$target"
    done < "$PLAN"
    printf '\nAll 6 chunks verified. Combining the image...\n'
    : > "$MERGE" || die 'Cannot create the merged file. Use a writable filesystem supporting the completed image size.'
    while IFS="$TAB" read -r name size expected; do
        cat "$CACHE/$name" >> "$MERGE" || die 'Merge failed. Free space or use exFAT/APFS/ext4/NTFS rather than FAT32, then run again. Verified chunks were kept.'
    done < "$PLAN"
    verified "$MERGE" "$IMAGE_BYTES" "$IMAGE_SHA" || die 'Whole-image verification failed. No final image was created; verified chunks were kept.'
    [ ! -e "$FINAL" ] && [ ! -L "$FINAL" ] || die 'The final filename appeared during the download; it was not replaced.'
    mv -n "$MERGE" "$FINAL" || die 'Cannot place the final verified image.'
    [ ! -e "$MERGE" ] || die 'The final filename could not be used; no existing file was replaced.'
    printf '\nSUCCESS: whole image SHA256 verified.\n'
fi
printf '\nOpen Raspberry Pi Imager, choose OS -> Use custom, and select:\n%s\n' "$FINAL"
printf '\nKeep the .img.xz compressed. Select the correct SD card and confirm Write in Imager.\n'
printf 'This helper only downloads files; it never writes to a memory card.\n'
printf 'The hidden .ubuntu-download-parts cache is kept for recovery and can be removed after you finish.\n'
