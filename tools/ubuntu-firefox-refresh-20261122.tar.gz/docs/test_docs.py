#!/usr/bin/python3
"""Offline downloader integrity/refusal fixtures and Ubuntu-only document guards."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile

import build_docs
import render_helpers as helper

HERE = Path(__file__).resolve().parent


def fixture_facts(parts):
    whole = b''.join(parts)
    return {'release_tag': helper.TAG, 'download_base_url': helper.BASE,
            'image': {'name': helper.IMAGE, 'bytes': len(whole), 'sha256': helper.sha(whole),
                      'extract_size': len(whole) + 1, 'extract_sha256': helper.sha(whole + b'x'),
                      'parts': [{'name': helper.IMAGE + f'.part{i:02d}', 'bytes': len(data),
                                 'sha256': helper.sha(data),
                                 'url': helper.BASE + '/' + helper.IMAGE + f'.part{i:02d}'}
                                for i, data in enumerate(parts, 1)]}}


def helper_fixtures():
    checks = []
    parts = [bytes([i]) * size for i, size in ((1, 17), (2, 17), (3, 5))]
    whole = b''.join(parts)
    facts = fixture_facts(parts)
    with tempfile.TemporaryDirectory(prefix='ubuntu-helper-20261122-') as temporary:
        root = Path(temporary)

        def setup(name):
            dest = root / name
            info = helper.render_helper(facts, dest, fixture=True, chunk=17)
            folder = dest / 'Ubuntu-Download-Tools'
            cache = folder / '.ubuntu-download-parts'
            cache.mkdir()
            for part, content in zip(facts['image']['parts'], parts):
                (cache / part['name']).write_bytes(content)
            fake_bin = folder / 'test-bin'
            fake_bin.mkdir()
            (fake_bin / 'curl').write_text('#!/bin/sh\nprintf called > "' + str(folder / 'unexpected-network') + '"\nexit 98\n')
            (fake_bin / 'curl').chmod(0o755)
            return folder, cache, info

        def run(folder):
            env = dict(os.environ, UBUNTU_HELPER_LOCAL_ONLY='1', UBUNTU_HELPER_NO_PAUSE='1',
                       PATH=str(folder / 'test-bin') + ':/usr/bin:/bin')
            result = subprocess.run(['sh', str(folder / 'download-ubuntu.sh')], env=env,
                                    capture_output=True, text=True)
            assert not (folder / 'unexpected-network').exists()
            return result

        folder, cache, info = setup('valid')
        result = run(folder)
        assert result.returncode == 0, result.stdout + result.stderr
        assert (folder / helper.IMAGE).read_bytes() == whole
        checks.append('Cached verified chunks merge in order and pass whole-image SHA-256')
        assert run(folder).returncode == 0
        checks.append('Completed verified image is reused without network')
        (folder / helper.IMAGE).write_bytes(b'preserve-existing-user-file')
        assert run(folder).returncode != 0 and (folder / helper.IMAGE).read_bytes() == b'preserve-existing-user-file'
        checks.append('Conflicting existing final file is preserved')
        folder, cache, _ = setup('partial')
        p = cache / facts['image']['parts'][0]['name']
        p.rename(p.with_name(p.name + '.partial'))
        assert run(folder).returncode == 0 and (folder / helper.IMAGE).read_bytes() == whole
        checks.append('Complete verified partial is reused')
        folder, cache, _ = setup('bad-partial')
        p = cache / facts['image']['parts'][0]['name']
        p.unlink()
        p.with_name(p.name + '.partial').write_bytes(b'X' * 17)
        assert run(folder).returncode != 0 and not (folder / helper.IMAGE).exists()
        assert not p.with_name(p.name + '.partial').exists() and not (cache / '.lock').exists()
        checks.append('Corrupt complete partial is rejected and lock released')
        folder, cache, _ = setup('whole-mismatch')
        p = cache / facts['image']['parts'][-1]['name']
        changed = b'Z' * 5
        p.write_bytes(changed)
        table = folder / 'ubuntu-parts.sha256'
        table.write_text(table.read_text().replace(helper.sha(parts[-1]), helper.sha(changed)))
        result = run(folder)
        assert result.returncode != 0 and 'Whole-image verification failed' in result.stderr
        checks.append('Whole hash rejects individually valid altered content')
        for name, before, after in [('not-ready', 'READY true', 'READY false'),
                                     ('wrong-origin', helper.BASE, 'https://example.invalid/release'),
                                     ('unsafe-name', helper.IMAGE + '.part01', '../unsafe')]:
            folder, _, _ = setup(name)
            table = folder / 'ubuntu-parts.sha256'
            table.write_text(table.read_text().replace(before, after))
            assert run(folder).returncode != 0 and not (folder / helper.IMAGE).exists()
            checks.append('Manifest refuses ' + name)
        folder, _, _ = setup('symlink-final')
        target = root / 'untouched'
        target.write_bytes(b'keep')
        (folder / helper.IMAGE).symlink_to(target)
        assert run(folder).returncode != 0 and target.read_bytes() == b'keep'
        checks.append('Symlink final target is refused and preserved')
        folder, _, _ = setup('locked')
        (folder / '.ubuntu-download-parts/.lock').mkdir()
        assert run(folder).returncode != 0
        checks.append('Concurrent-download lock is respected')
        for name in ('download-ubuntu.sh', 'download-ubuntu.command'):
            subprocess.run(['sh', '-n', str(folder / name)], check=True)
        ps = (folder / 'windows-powershell-source.txt').read_text()
        assert '$m.parts.Count -ne 3' in ps and '$i -lt 3' in ps and '$i -eq 2' in ps
        assert helper.BASE in ps and helper.OLD_BASE not in ps
        assert "-and $total -gt 4294967295" in ps
        assert all(s not in ps for s in ('ExecutionPolicy', 'Start-Process', 'Invoke-Expression'))
        assert info['windows_command_characters'] < 7900
        checks.append('macOS/POSIX syntax and Windows fixed URL/count/hash/length guards pass')
        for mutate in [lambda f: f['image']['parts'][0].__setitem__('name', '../unsafe'),
                       lambda f: f['image']['parts'][0].__setitem__('url', 'https://example.invalid/file'),
                       lambda f: f['image']['parts'][0].__setitem__('bytes', 18),
                       lambda f: f.__setitem__('release_tag', 'other-release')]:
            bad = copy.deepcopy(facts)
            mutate(bad)
            try:
                helper.validate_image(bad, fixture=True, chunk=17)
            except RuntimeError:
                pass
            else:
                raise AssertionError('Invalid helper facts accepted')
        checks.append('Generator rejects wrong release/origin/filename/size before rendering')
    report = {'status': 'passed', 'checks': checks, 'network_requests': 0,
              'production_image_read_or_modified': False, 'sd_accessed': False,
              'posix_runtime_tested': True, 'windows_runtime_tested': False,
              'macos_runtime_tested': False,
              'scope': 'Small offline helper integrity, reuse, manifest and refusal fixtures; no native Windows/macOS runtime claim'}
    helper.dump(HERE / 'helper-fixture-report.json', report)
    return report


def document_fixtures(baseline):
    old_status = build_docs.read(baseline / 'Ubuntu/factory-status.json')
    old_parts = old_status['download_parts']
    image = copy.deepcopy(old_status['image'])
    image.update(name=helper.IMAGE, sha256=helper.sha(b'new compressed fixture facts'),
                 extract_sha256=helper.sha(b'new raw fixture facts'))
    image['parts'] = [{'name': p['filename'].replace('20261113', '20261122'), 'bytes': p['size'],
                       'sha256': helper.sha(('part' + str(i)).encode()),
                       'url': helper.BASE + '/' + p['filename'].replace('20261113', '20261122')}
                      for i, p in enumerate(old_parts)]
    entry = copy.deepcopy(build_docs.read(baseline / 'os_list_v3.json')['os_list'][1])
    old_base = 'https://github.com/DZT970525/Operating-System-for-HackberryPi/releases/download/pinn-multiboot-hackberrypi-2026-11-16'
    entry = json.loads(json.dumps(entry).replace(old_base, helper.BASE))
    entry['release_date'] = '2026-11-22'
    facts = {'release_tag': helper.TAG, 'download_base_url': helper.BASE, 'image': image,
             'patch_source': {'name': 'Ubuntu-Firefox-Fix-Sources-20261122.tar.gz', 'bytes': 123,
                              'sha256': helper.sha(b'source fixture'),
                              'url': helper.BASE + '/Ubuntu-Firefox-Fix-Sources-20261122.tar.gz'},
             'verification': {key: True for key in build_docs.REQUIRED_TRUE},
             'pinn': {'feed_entry': entry}, 'restore_ubuntu_feed': True}
    facts['verification'].update(source_contains_private_card_data=False, final_image_physical_boot_tested=False)
    with tempfile.TemporaryDirectory(prefix='ubuntu-doc-fixture-') as temp:
        out = Path(temp) / 'output'
        result = build_docs.build(facts, baseline, out, [])
        assert result['status'] == 'passed' and result['imager_catalog_byte_exact']
        assert len(build_docs.read(out / 'repository/Ubuntu/os_list_v3.json')['os_list']) == 1
        assert len(build_docs.read(out / 'repository/os_list_v3.json')['os_list']) == 12
        assert (out / 'repository/os_list_imager.json').read_bytes() == (baseline / 'os_list_imager.json').read_bytes()
        assert 'This release is **standalone for Raspberry Pi Imager**' not in (out / 'repository/Ubuntu/README.md').read_text()
        assert '## PINN multiboot' in (out / 'repository/Ubuntu/README.md').read_text()
        assert 'it is not a replacement PINN filesystem package' not in (out / 'repository/Imager/Ubuntu.md').read_text()
        assert helper.OLD_BASE + '/linux-raspi_6.8.0.orig.tar.gz' in (out / 'repository/Ubuntu/README.md').read_text()
        checksums = dict(line.split('  ', 1)[::-1] for line in (out / 'assets/SHA256SUMS').read_text().splitlines())
        for path in (out / 'assets').iterdir():
            if path.name != 'SHA256SUMS':
                assert checksums[path.name] == helper.sha(path.read_bytes())
        with zipfile.ZipFile(out / 'assets' / helper.ZIP) as archive:
            manifest = json.loads(archive.read('Ubuntu-Download-Tools/ubuntu-parts.json'))
            assert manifest == build_docs.read(out / 'assets/ubuntu-parts.json')
            assert archive.read('Ubuntu-Download-Tools/ubuntu-parts.sha256') == (out / 'assets/ubuntu-parts.sha256').read_bytes()
            assert all(not n.startswith('/') and '..' not in n for n in archive.namelist())
    return {'status': 'passed', 'synthetic_measured_facts_only': True,
            'checks': ['Only Ubuntu root README section/table link changed',
                       'Only one Ubuntu PINN object changed; other 11 entries and surrounding bytes preserved',
                       'Entire Imager catalog preserved byte-for-byte',
                       'Ubuntu-only optional catalog restored with one current entry',
                       'Original native sources/notices links preserved',
                       'No unsupported PINN/physical-firstboot claims retained',
                       'Helper ZIP internal/external manifests agree',
                       'Every locally emitted release asset has an exact checksum index entry']}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, required=True)
    args = parser.parse_args()
    h = helper_fixtures()
    d = document_fixtures(args.baseline)
    helper.dump(HERE / 'docs-fixture-report.json', d)
    print(json.dumps({'helper': h, 'documents': d}, indent=2))
