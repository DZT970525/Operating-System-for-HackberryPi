#!/usr/bin/python3
"""Render fixed-release download-only helpers from measured public image facts."""
import hashlib
import json
import math
from pathlib import Path
import re
import zipfile

HERE = Path(__file__).resolve().parent
SITE = 'https://github.com/DZT970525/Operating-System-for-HackberryPi'
TAG = 'ubuntu-firefox-hackberrypi-2026-11-22'
BASE = SITE + '/releases/download/' + TAG
IMAGE = 'Ubuntu-24.04.5-GNOME-HackberryPi-CM5-DisplayScale-Neofetch-20261122.img.xz'
ZIP = 'Ubuntu-Imager-Download-Tools-20261122.zip'
CHUNK = 524288000
RESERVE = 268435456
OLD_IMAGE = IMAGE.replace('20261122', '20261113')
OLD_BASE = SITE + '/releases/download/ubuntu-displayscale-hackberrypi-2026-11-13'
OLD_SHA = 'afdd7664a3fc3c6ea389d429fcf5a4f45a1e335b30d13f8d3d485043b5cf9a7b'
TEMPLATES = {
    'download-ubuntu.sh': '1b14356e5a2ca9407cbd5d32aa5c66045d03fe08e8c87e40ff5b13b88544454d',
    'windows-powershell-source.txt': '7763540b3bd91ec87886dee8182b999ab21e4c484007fed15ccbaca645d215bf'
}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def valid_hash(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{64}', value) is not None


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def validate_image(facts, *, fixture=False, chunk=CHUNK):
    need(facts['release_tag'] == TAG and facts['download_base_url'] == BASE, 'Unexpected immutable release URL')
    image = facts['image']
    need(image['name'] == IMAGE, 'Unexpected image filename')
    need(isinstance(image['bytes'], int) and image['bytes'] > 0 and valid_hash(image['sha256']), 'Invalid image measurement')
    need(isinstance(image['extract_size'], int) and image['extract_size'] > image['bytes']
         and valid_hash(image['extract_sha256']), 'Invalid expanded image measurement')
    parts = image['parts']
    count = math.ceil(image['bytes'] / chunk)
    need(len(parts) == count and 2 <= count <= 99, 'Invalid measured part count')
    if not fixture:
        need(chunk == CHUNK and image['bytes'] >= 2 * 1024**3, 'Production split-image sizing required')
        v = facts['verification']
        need(v['full_xz_decode_verified'] and v['all_parts_verified'], 'Verified image and parts required')
    for index, part in enumerate(parts, 1):
        name = IMAGE + f'.part{index:02d}'
        size = min(chunk, image['bytes'] - (index - 1) * chunk)
        need(part['name'] == name and part['bytes'] == size and valid_hash(part['sha256']), 'Invalid part name, size or hash')
        need(part['url'] == BASE + '/' + name, 'Unexpected part URL')
    need(sum(p['bytes'] for p in parts) == image['bytes'], 'Part size sum differs')
    return count


def render_helper(facts, output, *, fixture=False, chunk=CHUNK):
    count = validate_image(facts, fixture=fixture, chunk=chunk)
    image = facts['image']
    last = image['parts'][-1]['bytes']
    free_gb = math.ceil((2 * image['bytes'] + RESERVE) / 1_000_000_000)
    folder = output / 'Ubuntu-Download-Tools'
    folder.mkdir(parents=True, exist_ok=True)
    for name, expected in TEMPLATES.items():
        need(sha((HERE / 'templates' / name).read_bytes()) == expected, 'Trusted helper template changed: ' + name)

    def adapt(source):
        pairs = ((OLD_IMAGE, IMAGE), (OLD_BASE, BASE), (OLD_SHA, image['sha256']),
                 ('3017984912', str(image['bytes'])), ('524288000', str(chunk)),
                 ('396544912', str(last)), ('n>6', 'n>' + str(count)),
                 ('n==6?', 'n==' + str(count) + '?'), ('n!=6', 'n!=' + str(count)),
                 ('All 6 chunks', 'All ' + str(count) + ' chunks'),
                 ('$m.parts.Count -ne 6', '$m.parts.Count -ne ' + str(count)),
                 ('$i -lt 6', '$i -lt ' + str(count)), ('$i -eq 5', '$i -eq ' + str(count - 1)),
                 ('about 7 GB free', 'about ' + str(free_gb) + ' GB free'))
        for old, new in pairs:
            source = source.replace(old, new)
        need(OLD_IMAGE not in source and OLD_BASE not in source and OLD_SHA not in source, 'Stale template constants')
        return source

    shell = adapt((HERE / 'templates/download-ubuntu.sh').read_text())
    (folder / 'download-ubuntu.sh').write_text(shell)
    (folder / 'download-ubuntu.command').write_text(shell + '''
if [ -t 0 ] && [ "${UBUNTU_HELPER_NO_PAUSE:-0}" != 1 ]; then
    printf '\\nPress Return to close...'; IFS= read -r ubuntu_close_reply || true
fi
''')
    ps = adapt((HERE / 'templates/windows-powershell-source.txt').read_text())
    (folder / 'windows-powershell-source.txt').write_text(ps)
    flat = ' '.join(line.strip() for line in ps.splitlines() if line.strip())
    need('"' not in flat and '%' not in flat, 'Unsafe Windows command embedding')
    launch = 'powershell.exe -NoProfile -Command "& { ' + flat + ' }"'
    need(len(launch) < 7900, 'Windows command exceeds safe length')
    cmd = '\r\n'.join([
        '@echo off', 'setlocal DisableDelayedExpansion',
        'set "UBUNTU_HELPER_DIR=%~dp0"', 'set "UBUNTU_HELPER_OUT=%~dp0"',
        'if not "%~1"=="" set "UBUNTU_HELPER_OUT=%~1"',
        'where powershell.exe >nul 2>nul || (echo ERROR: Windows PowerShell is unavailable. & pause & exit /b 1)',
        'where curl.exe >nul 2>nul || (echo ERROR: The system curl.exe is unavailable. & pause & exit /b 1)',
        launch, 'set "UBUNTU_HELPER_RESULT=%ERRORLEVEL%"',
        'if not defined UBUNTU_HELPER_NO_PAUSE pause', 'exit /b %UBUNTU_HELPER_RESULT%', ''])
    (folder / 'download-ubuntu.cmd').write_bytes(cmd.encode('ascii'))
    manifest = {'version': 1, 'ready': True, 'release_tag': TAG, 'download_base_url': BASE,
                'image': {'filename': IMAGE, 'size': image['bytes'], 'sha256': image['sha256'],
                          'uncompressed_size': image['extract_size'], 'uncompressed_sha256': image['extract_sha256']},
                'parts': [{'filename': p['name'], 'size': p['bytes'], 'sha256': p['sha256'], 'url': p['url']}
                          for p in image['parts']]}
    dump(folder / 'ubuntu-parts.json', manifest)
    rows = ['# Ubuntu download manifest. Data only; not a shell script.', 'VERSION 1', 'READY true',
            'BASE ' + BASE, f"IMAGE {IMAGE} {image['bytes']} {image['sha256']}"]
    rows += [f"PART {p['name']} {p['bytes']} {p['sha256']}" for p in image['parts']]
    (folder / 'ubuntu-parts.sha256').write_text('\n'.join(rows) + '\n')
    dump(folder / 'helper-provenance.json', {
        'based_on_published_zip_url': OLD_BASE + '/Ubuntu-Imager-Download-Tools-20261113.zip',
        'based_on_published_zip_sha256': 'c4295fec2067f6d552bfbd71ba855c9a69166c1c20136e1a4e0a4485e19d7a1c',
        'template_sha256': TEMPLATES,
        'changes': 'New immutable Ubuntu release URL, filenames and measured image/part sizes and hashes',
        'no_administrator_rights_required': True, 'sd_card_writes_performed': False})
    (folder / 'README.txt').write_text(f'''Ubuntu automatic download and merge for Raspberry Pi Imager

1. Extract this entire ZIP into a computer folder with at least {free_gb} GB free.
   Keep all launcher and manifest files together. Administrator access is not
   required. Windows needs built-in PowerShell and curl.exe; macOS/Linux need
   curl and shasum or sha256sum.
2. Windows: double-click download-ubuntu.cmd.
   macOS: open download-ubuntu.command.
   Linux: run sh ./download-ubuntu.sh.
3. Wait for all {count} parts to download, pass individual SHA-256 checks and merge
   automatically. Rerun the same launcher to resume and reuse verified parts.
   The helper checks the complete compressed image before reporting success.
4. In Raspberry Pi Imager choose Use custom and select:
   {IMAGE}
   Select the .img.xz directly. Do not choose the ZIP or an individual part.
5. Keep Imager OS customisation disabled. Select the intended 16 GB or larger
   SD card, then finish writing and verification in Imager.

The helper only downloads and combines computer files; it never selects or
writes an SD card. The hidden .ubuntu-download-parts cache can be removed after
successful writing. Keep the completed compressed image.

Compressed bytes: {image['bytes']}
Compressed SHA-256: {image['sha256']}
Expanded bytes: {image['extract_size']}
Expanded SHA-256: {image['extract_sha256']}

System and validation notes:
{SITE}/blob/main/Imager/Ubuntu.md

Based on the previously published Ubuntu helper. Linux/POSIX cached-part,
integrity and refusal fixtures passed. Windows/macOS launchers have static
checks; native Windows/macOS runtime and public-network resume checks remain
separate. These helper checks do not establish a physical first boot.
''')
    for name in ('download-ubuntu.sh', 'download-ubuntu.command'):
        (folder / name).chmod(0o755)
    return {'zip_name': ZIP, 'part_count': count,
            'first_download_working_space_bytes': 2 * image['bytes'] + RESERVE,
            'first_download_recommended_free_gb': free_gb,
            'windows_command_characters': len(launch), 'windows_runtime_tested': False,
            'macos_runtime_tested': False, 'fixture_only': fixture}


def package_helper(output, info, fixture_report):
    need(fixture_report['status'] == 'passed' and fixture_report['network_requests'] == 0,
         'Passing offline helper fixture report required')
    folder = output / 'Ubuntu-Download-Tools'
    dump(folder / 'offline-fixture-report.json', fixture_report)
    asset = output / ZIP
    with zipfile.ZipFile(asset, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(folder.iterdir()):
            need(path.is_file() and not path.is_symlink(), 'Unsafe helper artifact')
            entry = zipfile.ZipInfo('Ubuntu-Download-Tools/' + path.name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = (0o100755 if path.suffix in ('.sh', '.command') else 0o100644) << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, path.read_bytes())
    info.update(zip_bytes=asset.stat().st_size, zip_sha256=sha(asset.read_bytes()))
    return info
