#!/usr/bin/env python3
"""Run shipped maintainer scripts unchanged in an empty, private user namespace.

The fake DKMS records arguments; actual module compilation is verified separately
on the target image. No host/card /lib/modules, /usr/src or DKMS tree is exposed.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

BASE = Path(__file__).resolve().parent
PAYLOAD = BASE / "root"
RELEASES = [f"{v}+rpt-rpi-{flavour}" for v in ("6.6.51", "6.12.115")
            for flavour in ("2712", "v8")]
MODULE = "hackberrypi-max17048"
VERSION = "1.2-present"
results = []

def fixture(registered=False, mismatch=False, fail=None):
    temp = tempfile.TemporaryDirectory(prefix=".lifecycle-", dir=BASE)
    root = Path(temp.name)
    for directory in ("bin", "scripts", "lib/modules", "var/lib/dkms", "usr/src"):
        (root / directory).mkdir(parents=True, exist_ok=True)
    shutil.copy2("/usr/bin/busybox", root / "bin/busybox")
    for command in ("sh", "cat", "mkdir", "ln", "rm"):
        (root / "bin" / command).symlink_to("busybox")
    for script in ("postinst", "prerm", "postrm"):
        shutil.copy2(PAYLOAD / "DEBIAN" / script, root / "scripts" / script)
    shutil.copytree(PAYLOAD / "usr/src" / f"{MODULE}-{VERSION}",
                    root / "usr/src" / f"{MODULE}-{VERSION}")
    for release in RELEASES + ["6.99-unrelated"]:
        header = root / "lib/modules" / release / "build/include/config"
        header.mkdir(parents=True)
        (header / "kernel.release").write_text(
            "wrong-release\n" if mismatch and release == RELEASES[2] else release + "\n")
    (root / "lib/modules/6.77+rpt-rpi-v8").mkdir()
    if registered:
        state = root / "var/lib/dkms" / MODULE / VERSION
        state.mkdir(parents=True)
        (state / "source").symlink_to(f"/usr/src/{MODULE}-{VERSION}")
    (root / "calls").write_text("")
    if fail:
        (root / "fail").write_text(fail)
    (root / "bin/dkms").write_text('''#!/bin/sh
set -eu
printf '%s\\n' "$*" >> /calls
if [ -f /fail ] && [ "$1" = "$(cat /fail)" ]; then exit 17; fi
case "$1" in
add)
 mkdir -p /var/lib/dkms/hackberrypi-max17048/1.2-present
 ln -s /usr/src/hackberrypi-max17048-1.2-present /var/lib/dkms/hackberrypi-max17048/1.2-present/source
 ;;
remove) rm -rf /var/lib/dkms/hackberrypi-max17048/1.2-present ;;
esac
''')
    (root / "bin/dkms").chmod(0o755)
    return temp, root

def run(root, script, action):
    result = subprocess.run([
        "bwrap", "--unshare-all", "--die-with-parent", "--clearenv",
        "--setenv", "PATH", "/bin", "--bind", str(root), "/", "--dev", "/dev", "--chdir", "/",
        "--", "/bin/sh", f"/scripts/{script}", action,
    ], text=True, capture_output=True)
    return result, (root / "calls").read_text().splitlines()

def record(name, passed, detail):
    results.append({"name": name, "passed": passed, "detail": detail})
    if not passed:
        raise AssertionError((name, detail))

expected = []
for release in sorted(RELEASES):
    expected.extend([
        f"build -m {MODULE} -v {VERSION} -k {release} -j 1 --force",
        f"install -m {MODULE} -v {VERSION} -k {release} --force",
    ])

for registered in (False, True):
    temp, root = fixture(registered=registered)
    try:
        result, calls = run(root, "postinst", "configure")
        wanted = ([] if registered else [f"add -m {MODULE} -v {VERSION}"]) + expected
        record("configure-registered" if registered else "configure-new",
               result.returncode == 0 and calls == wanted,
               {"returncode": result.returncode, "calls": calls, "stderr": result.stderr})
    finally:
        temp.cleanup()

for script, action, remove in (
    ("prerm", "upgrade", True), ("prerm", "remove", True),
    ("prerm", "failed-upgrade", False), ("postrm", "upgrade", False),
    ("postrm", "remove", True), ("postrm", "purge", True),
):
    temp, root = fixture(registered=True)
    try:
        result, calls = run(root, script, action)
        wanted = [f"remove -m {MODULE} -v {VERSION} --all"] if remove else []
        record(f"{script}-{action}", result.returncode == 0 and calls == wanted,
               {"returncode": result.returncode, "calls": calls})
    finally:
        temp.cleanup()

for kind, options in (("header-mismatch", {"mismatch": True}),
                      ("build-failure", {"fail": "build"})):
    temp, root = fixture(registered=True, **options)
    try:
        result, calls = run(root, "postinst", "configure")
        record(kind, result.returncode != 0 and not any(c.startswith("install ") for c in calls),
               {"returncode": result.returncode, "calls": calls, "stderr": result.stderr})
    finally:
        temp.cleanup()

artifact = BASE / "hackberrypi-battery-dkms_1.2+hbpi2_all.deb"
report = {"passed": all(r["passed"] for r in results),
          "package_sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
          "isolation": "empty bubblewrap user/mount/network namespace; static busybox and fake DKMS only",
          "checks": results}
(BASE / "lifecycle-test-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"passed": report["passed"], "checks": len(results),
                  "package_sha256": report["package_sha256"]}))
