#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
export SOURCE_DATE_EPOCH=1794873600
find root -type d -exec chmod 0755 {} +
find root -type f -exec chmod 0644 {} +
chmod 0755 root/DEBIAN/postinst root/DEBIAN/prerm root/DEBIAN/postrm
sh -n root/DEBIAN/postinst
sh -n root/DEBIAN/prerm
sh -n root/DEBIAN/postrm
dpkg-deb --root-owner-group --build root hackberrypi-battery-dkms_1.2+hbpi2_all.deb
dpkg-deb --info hackberrypi-battery-dkms_1.2+hbpi2_all.deb
dpkg-deb --contents hackberrypi-battery-dkms_1.2+hbpi2_all.deb
sha256sum hackberrypi-battery-dkms_1.2+hbpi2_all.deb
